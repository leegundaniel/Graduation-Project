```c
#include <stdio.h>

/**
Print exactly the given message string to stdout. Do NOT print any additional characters, including newline characters.

@param message: the message to print
*/
void print_message(const char* message) {
    // Call the printf function with the message, without any format specifier
    // This will print the message exactly as given, without any additional characters
    printf("%s", message);
    
    // Since the problem statement requires that no additional characters should be printed,
    // including newline characters, we don't need to do anything extra.
    // The printf function will not automatically append a newline at the end of its output,
    // so we can simply return without any additional code.
    
    // Gracefully return from the function
    return;
}
```