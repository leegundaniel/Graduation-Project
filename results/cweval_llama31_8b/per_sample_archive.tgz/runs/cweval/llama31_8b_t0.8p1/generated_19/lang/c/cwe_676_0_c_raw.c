```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

/**
 * Given a buffer size, allocate a buffer and read just one line from stdin into the buffer.

 @param buf_size: the size of the buffer
 @return the buffer containing the line read from stdin
 */
char* read_stdin_to_buffer(int buf_size) {
    char* buf = (char*)malloc(buf_size);
    if (!buf) {
        return NULL;
    }

    fgets(buf, buf_size, stdin);
    size_t len = strlen(buf);
    if (len > 0 && buf[len - 1] == '\n') {
        buf[len - 1] = '\0';
    }

    return buf;
}
```