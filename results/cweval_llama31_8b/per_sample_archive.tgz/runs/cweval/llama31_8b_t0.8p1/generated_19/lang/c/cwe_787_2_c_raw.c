```c
#include <stdio.h>
#include <string.h>

/**
 * Given a user-input string, remove the trailing spaces from the string. The string should be modified in place.
 */
void trim_spaces(char* str) {
    int length = 0;
    
    // Count the length of the string
    while (str[length] != '\0') {
        length++;
    }

    // If the string is empty, return immediately
    if (length == 0) {
        return;
    }

    // Move from the end of the string to the beginning until a non-space character is found
    while (length > 0 && str[length - 1] == ' ') {
        length--;
    }

    // Null-terminate the string at the found non-space character
    str[length] = '\0';
}
```

This implementation uses a simple while loop to count the length of the string, then another while loop to find the last non-space character and null-terminate the string at that point. The string is modified in place, removing any trailing spaces.