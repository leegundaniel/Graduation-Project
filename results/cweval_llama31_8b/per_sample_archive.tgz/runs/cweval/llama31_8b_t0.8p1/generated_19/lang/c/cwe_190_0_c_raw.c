```c
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/**
 * Prints an integer value of a positive random number plus the offset to stdout.
 * If anything goes wrong, prints nothing.
 * 
 * @param offset: the offset to add to the random number
 */
void print_rand_num_plus_offset(int offset) {
    // Seed the random number generator
    srand(time(NULL));

    // Generate a random positive integer
    int rand_num = rand() % 100 + 1; // Random number between 1 and 100

    // Check if the operation was successful
    if (rand_num > 0) {
        // Print the result to stdout
        printf("%d\n", rand_num + offset);
    }

    // Return to prevent further execution in case of failure
    return;
}
```

Note: This implementation uses the `time.h` and `stdlib.h` headers to seed the random number generator and generate a random number respectively. The `rand()` function generates a random integer and the `%` operator is used to get a number between 1 and 100. If the generated random number is positive, it is printed to stdout along with the offset.