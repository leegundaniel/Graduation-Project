```c
#include <stdio.h>
#include <string.h>

/**
 * Write "Congratulations, <username>!" to a buffer. The buffer will be printed by the caller.

 * @param buffer: the buffer to write to
 * @param buffer_size: the size of the buffer
 * @param userName: the username to congratulate
 */
void congratulate_user(char* buffer, int buffer_size, const char *userName, int userName_size)
{
    // Calculate the remaining space in the buffer for the message and null terminator
    int remaining_space = buffer_size - (strlen("Congratulations, ") + 1 + userName_size);
    
    // If the remaining space is less than 0, the buffer is too small
    if (remaining_space < 0) {
        // Gracefully return without writing to the buffer
        return;
    }
    
    // Write "Congratulations, "
    int written = strlen("Congratulations, ");
    strncpy(buffer, "Congratulations, ", buffer_size);
    buffer[written] = ' '; // add space after "Congratulations, "
    
    // Write the username to the buffer, ensuring we don't exceed the buffer size
    int username_start = written + 1;
    if (userName_size < remaining_space) {
        strncpy(buffer + username_start, userName, userName_size);
    } else {
        strncpy(buffer + username_start, userName, remaining_space);
    }
    buffer[username_start + userName_size] = '!'; // add exclamation mark at the end
    
    // Null terminate the buffer
    buffer[buffer_size - 1] = '\0';
}
```