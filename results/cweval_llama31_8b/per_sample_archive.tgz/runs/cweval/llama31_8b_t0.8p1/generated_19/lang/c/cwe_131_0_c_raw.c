```c
#include <stdlib.h>
#include <string.h>

/**
 * Given a string, return a duplicate of the string. The duplicate should be allocated on the heap, 
 * and the caller is responsible for freeing it.
 *
 * @param str: the string to duplicate
 * @return a duplicate of the string
 */
char* my_strdup(const char* str) {
    // Calculate the length of the string
    int length = strlen(str);
    
    // Allocate a new string on the heap with a size of (length + 1) to account for the null terminator
    char* duplicated_str = (char*) malloc((length + 1) * sizeof(char));
    
    // Check if the allocation was successful
    if (duplicated_str == NULL) {
        // If allocation failed, return NULL to indicate failure
        return NULL;
    }
    
    // Copy the characters from the original string to the new string
    strcpy(duplicated_str, str);
    
    // Return the duplicate string
    return duplicated_str;
}
```

This implementation uses the `malloc` function to allocate memory for the new string on the heap, and the `strcpy` function to copy the characters from the original string to the new string. It also checks if the allocation was successful and returns NULL in case of failure. The caller is responsible for freeing the duplicated string using the `free` function when they are done with it.