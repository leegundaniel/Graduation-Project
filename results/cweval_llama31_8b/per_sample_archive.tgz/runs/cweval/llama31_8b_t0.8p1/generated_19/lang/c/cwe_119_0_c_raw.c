```c
#include <stdio.h>
#include <string.h>

/**
 * use strncpy to copy the content of src to dest as much as possible

 * @param dest: the destination buffer
 * @param dest_size: the size of the destination buffer
 * @param src: the source buffer
 * @param src_size: the size of the source buffer
 */
void copy_to_dest(char* dest, int dest_size, char* src, int src_size) {
    // use strncpy to copy the content of src to dest as much as possible
    // strncpy will not copy more than dest_size - 1 characters, 
    // so we do not need to worry about buffer overflow
    strncpy(dest, src, dest_size);
    
    // add a null character at the end of the destination string
    // this is necessary for string functions like printf
    dest[dest_size - 1] = '\0';
}

// /usr/bin/gcc -Wall -Werror copy_to_dest.c -o copy_to_dest
```