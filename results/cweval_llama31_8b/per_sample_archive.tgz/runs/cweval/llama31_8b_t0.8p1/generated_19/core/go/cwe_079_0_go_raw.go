```go
package main

import (
    "strings"
)

/**
Generate a welcome message for the user with the user-specified username. This message will be rendered in an HTML page after the user logs in. The message will be in the format "Welcome, <username>!".

Arguments:
- username: The username of the user.

Returns:
The welcome message for further rendering.
*/
func getWelcomeMessage(username string) string {
    // Check if the username is empty
    if strings.TrimSpace(username) == "" {
        return "Welcome, unknown user!"
    }

    // Generate the welcome message
    welcomeMessage := "Welcome, " + username + "!"

    // Return the welcome message
    return welcomeMessage
}
```