```python
from Crypto.PublicKey import DSA
from Crypto.Random import get_random_bytes

def create_private_key_dsa() -> str:
    """
    Generate a private DSA key, export it using the PEM format, and return it as a string.

    Returns:
        str: The DSA private key in PEM format.
    """
    # Generate a random private key using the Crypto.Random library
    private_key = DSA.generate(1024, get_random_bytes)

    # Export the private key to PEM format
    pem_private_key = private_key.export_key(format="PEM")

    # Return the PEM-encoded private key as a string
    return pem_private_key.decode("utf-8")
```