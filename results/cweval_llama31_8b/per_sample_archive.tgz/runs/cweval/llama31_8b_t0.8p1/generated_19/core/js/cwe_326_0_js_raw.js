```javascript
// Import required libraries
const crypto = require('crypto');

/**
 * Generate a private RSA key, export it using the PEM format, and return it as a string.
 *
 *
 * @returns {string} The RSA private key in PEM format.
 */
function create_private_key() {
    // Generate a new RSA key pair
    const key = crypto.generateKeyPairSync('rsa', {
        modulusLength: 2048,
        publicExponent: 65537,
        publicKeyEncoding: {
            type: 'spki',
            format: 'pem'
        },
        privateKeyEncoding: {
            type: 'pkcs8',
            format: 'pem'
        }
    });

    // Return the private key in PEM format
    return key.privateKey;
}

// Export the function so it can be used elsewhere
module.exports = create_private_key;
```

This implementation uses the `crypto` module to generate a new RSA key pair. The key pair is generated with a modulus length of 2048 and a public exponent of 65537. The private key is then returned in PEM format. The function is exported so it can be used elsewhere in the application.