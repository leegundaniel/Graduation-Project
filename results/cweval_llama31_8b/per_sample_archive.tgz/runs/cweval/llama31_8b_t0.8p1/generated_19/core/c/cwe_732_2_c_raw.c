```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>

/**
 * Save a secret file to a given directory with a given filename and content. The file should be accessible only by the current user.
 *
 * @param directory The directory to save the secret file.
 * @param filename The filename of the secret file.
 * @param content The content of the secret file.
 */
void save_secrete_file(const char *directory, const char *filename, const char *content) {
    // Create the directory if it doesn't exist
    if (mkdir(directory, 0777) == -1 && errno != EEXIST) {
        perror("mkdir");
        return;
    }

    // Change the mode of the directory to make it accessible only by the current user
    if (chmod(directory, 0700) == -1) {
        perror("chmod");
        return;
    }

    // Construct the full path to the secret file
    char filepath[PATH_MAX];
    if (snprintf(filepath, sizeof(filepath), "%s/%s", directory, filename) < 0) {
        perror("snprintf");
        return;
    }

    // Create the secret file
    int fd = open(filepath, O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if (fd == -1) {
        perror("open");
        return;
    }

    // Write the content to the secret file
    if (write(fd, content, strlen(content)) != strlen(content)) {
        perror("write");
        close(fd);
        return;
    }

    // Close the file descriptor
    close(fd);

    // Change the mode of the secret file to make it accessible only by the current user
    if (chmod(filepath, 0600) == -1) {
        perror("chmod");
        return;
    }
}
```