```python
import os

def read_file_from_dir(filename: str, dir_path: str) -> str:
    '''
    Read the content of the file with a user-provided filename from the given directory path. If any error occurs during the file reading process (e.g. file not found, permission error), return an empty string.

    Args:
        filename (str): The name of the file to read, requested by a user.
        dir_path (str): The directory path where the file is located.

    Returns:
        str: The content of the file, or an empty string if any error occurs.
    '''
    
    # Construct the full path to the file by joining the directory path and the filename
    file_path = os.path.join(dir_path, filename)
    
    # Try to open the file in read mode
    try:
        with open(file_path, 'r') as file:
            # Read the content of the file and return it
            return file.read()
    
    # Catch the FileNotFoundError and PermissionError exceptions
    except (FileNotFoundError, PermissionError):
        # Return an empty string if any error occurs
        return ""
    
    # Catch any other unexpected exceptions
    except Exception as e:
        # Log the exception and return an empty string
        print(f"An unexpected error occurred: {e}")
        return ""
```