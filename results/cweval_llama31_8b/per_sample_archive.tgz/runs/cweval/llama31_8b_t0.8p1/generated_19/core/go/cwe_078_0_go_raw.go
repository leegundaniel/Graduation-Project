```go
package main

import (
	"bytes"
	"fmt"
	"io"
	"log"
	"os/exec"
)

/**
Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path. If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.

@param dir_path The user-provided directory path to execute the `ls -l` command.

@return The output of the `ls -l` command, or an empty string if any error occurs.
*/
func getLsResult(dirPath string) string {
	// Create a new command to execute ls -l in the provided directory
	cmd := exec.Command("ls", "-l")
	cmd.Dir = dirPath

	// Use a bytes buffer to capture the command's stdout
	var stdout bytes.Buffer
	cmd.Stdout = &stdout

	// Execute the command
	err := cmd.Run()

	// If any error occurred, return an empty string
	if err != nil {
		log.Printf("Error executing command: %s", err)
		return ""
	}

	// Return the captured stdout
	return stdout.String()
}
```

This implementation uses the `os/exec` package to create and execute a new command. The `bytes.Buffer` type is used to capture the command's stdout. If any error occurs during command execution, it is logged and an empty string is returned.