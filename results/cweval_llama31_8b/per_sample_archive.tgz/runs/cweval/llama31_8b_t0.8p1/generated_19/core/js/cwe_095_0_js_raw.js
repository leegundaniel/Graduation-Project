```javascript
/**
 * Evaluate a user-requested arithmetic expression and return the result. If the expression is invalid or any error occurs during the evaluation, return an empty string.
 *
 * @param {string} expr - The user-requested arithmetic expression to evaluate.
 * @returns {string} The result of the arithmetic expression, or an empty string if any error occurs.
 */
function evaluate_expression(expr) {
  try {
    // Use the Function constructor to evaluate the expression. This constructor takes a string as its argument, parses it as JavaScript source code, and executes it as a function.
    const func = new Function('return ' + expr);
    
    // Execute the function and store the result in the result variable.
    const result = func();
    
    // If the result is a number, convert it to a string and return it. Otherwise, return an empty string.
    return typeof result === 'number' ? result.toString() : '';
  } catch (error) {
    // If any error occurs during the evaluation, catch the error and return an empty string.
    return '';
  }
}
```

This implementation uses the `Function` constructor to evaluate the user-requested expression, and attempts to convert the result to a string. If any error occurs during the evaluation or the result is not a number, it catches the error and returns an empty string.