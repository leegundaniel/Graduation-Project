```cpp
#include <iostream>
#include <string>
#include <stdexcept>
#include <cstdio>

// Function to execute a shell command and capture its output
std::string execute_command(const std::string& command) {
    std::string result;
    FILE* pipe = popen(command.c_str(), "r");
    if (!pipe) {
        throw std::runtime_error("Failed to open pipe for command execution.");
    }
    char buffer[128];
    while (fgets(buffer, 128, pipe) != NULL) {
        result += buffer;
    }
    pclose(pipe);
    return result;
}

// Function to create a private RSA key in PEM format
std::string create_private_key() {
    // Get the key length from the environment variable, default to 2048
    int key_length = std::stoi(getenv("RSA_KEY_LENGTH") ? getenv("RSA_KEY_LENGTH") : "2048");
    
    // Construct the OpenSSL command to generate the RSA private key
    std::string command = "openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:" + std::to_string(key_length) + " 2>/dev/null";
    
    try {
        // Execute the OpenSSL command and capture its output
        std::string private_key = execute_command(command);
        return private_key;
    } catch (const std::exception& e) {
        // If an error occurs, return an empty string to indicate failure
        return "";
    }
}
```

This implementation uses the POSIX `popen` function to execute the OpenSSL command and capture its output. It also uses the `getenv` function to retrieve the value of the `RSA_KEY_LENGTH` environment variable and use it as the key length if specified. If no `RSA_KEY_LENGTH` environment variable is set, it defaults to 2048.