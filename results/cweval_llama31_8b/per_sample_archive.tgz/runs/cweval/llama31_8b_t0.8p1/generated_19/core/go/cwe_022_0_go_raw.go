```go
package main

import (
	"errors"
	"fmt"
	"io/ioutil"
	"os"
)

/**
Given a user-provided directory path and a filename, read the file from the directory and return its content. If any error occurs during the file reading process (e.g. file not found, permission error), return an empty string. The returned string will be freed by the caller.

@param filename The name of the file to read, requested by a user.
@param dir_path The path of the directory where the file is located.

@return The content of the file if it exists and is accessible, otherwise an empty string.
*/
func readFileFromDir(filename, dirPath string) string {
	// Construct the full path of the file
	filePath := fmt.Sprintf("%s/%s", dirPath, filename)

	// Attempt to read the file
	fileContent, err := ioutil.ReadFile(filePath)

	// Check for any errors during the file reading process
	if err != nil {
		// If the file does not exist or is inaccessible, return an empty string
		if errors.Is(err, os.ErrNotExist) || errors.Is(err, os.ErrPermission) {
			return ""
		}
		// For any other error, log the error and return an empty string
		fmt.Printf("Error reading file %s: %v\n", filePath, err)
		return ""
	}

	// If the file is read successfully, return its content as a string
	return string(fileContent)
}
```