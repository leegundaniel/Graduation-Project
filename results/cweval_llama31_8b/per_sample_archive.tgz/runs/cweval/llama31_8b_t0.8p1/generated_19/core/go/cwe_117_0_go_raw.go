```go
package main

import (
	"fmt"
	"time"
)

/*
Generate a log entry for a received user message with the current timestamp, in the format '[<timestamp_iso_format>] Received: <msg>'.

@param msg The user message received.

@return The log entry for the received message.
*/
func generateReceiveLog(msg string) string {
	// Get the current timestamp in ISO format
	currentTime := time.Now().Format(time.RFC3339Nano)
	
	// Create the log entry
	logEntry := fmt.Sprintf("[%s] Received: %s", currentTime, msg)
	
	// Return the generated log entry
	return logEntry
}
```