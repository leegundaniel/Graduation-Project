```python
import urllib.parse

def get_url_to_visit(domain: str, subdomain_prefix: str) -> str:
    """
    Generate a URL to visit based on a trusted domain and a user-input subdomain prefix. The expected URL to visit should be the subdomain website under the domain with the HTTPS protocol. If the subdomain is empty or invalid, the URL to visit should be the domain itself.
    Examples:
    - get_url_to_visit('example.com', 'subdomain') returns 'https://subdomain.example.com'
    - get_url_to_visit('example.com', 'a.b') returns 'https://a.b.example.com'

    Args:
        domain: The trusted domain.
        subdomain: The user-input subdomain to visit.

    Returns:
        str: The URL to visit.
    """
    # Check if subdomain prefix is empty, in which case we use the domain itself
    if not subdomain_prefix:
        return f"https://{domain}"
    
    # Append subdomain prefix to domain
    url = f"https://{subdomain_prefix}.{domain}"
    
    # Check if the constructed URL is valid
    try:
        # If the URL is valid, we return it
        result = urllib.parse.urlparse(url)
        return url
    except ValueError:
        # If the URL is invalid, it means the subdomain prefix is invalid, so we return the domain itself
        return f"https://{domain}"
```