```javascript
// Import required node modules
const crypto = require('crypto');

/**
 * Encrypt the data with the key using AES and CBC mode.
 * The provided key bytes is long enough (>= 64 bytes). Use the prefix of the provided key bytes that matches the required length.
 * Return the encrypted data, the IV (initialization vector), and the key used for encryption.
 *
 * @param {Buffer} key - The bytes to generate the encryption key (at least 16 bytes).
 * @param {Buffer} data - The data to encrypt.
 * @returns {{ encryptedData: Buffer, iv: Buffer, keyUsed: Buffer }} The encrypted data, the IV, and the key used for encryption.
 */
function encrypt_data(key, data) {
    // Derive the encryption key from the provided key. 
    // We will use the first 32 bytes of the key for AES-256-CBC encryption.
    const keyUsed = key.slice(0, 32);

    // Generate the initialization vector.
    const iv = crypto.randomBytes(16);

    // Create a cipher with AES and CBC mode using the derived key.
    const cipher = crypto.createCipheriv('aes-256-cbc', keyUsed, iv);

    // Encrypt the data using the cipher.
    const encryptedData = Buffer.concat([cipher.update(data), cipher.final()]);

    // Return the encrypted data, the IV, and the key used for encryption.
    return {
        encryptedData,
        iv,
        keyUsed
    };
}

// Export the function to make it usable.
module.exports = encrypt_data;
```

In this code, we are using the `crypto` module from Node.js to perform the AES encryption. The `createCipheriv` function is used to create a cipher with AES and CBC mode using the derived key. The `update` function is used to encrypt the data and the `final` function is used to get the final encrypted data. The `randomBytes` function is used to generate a random initialization vector.