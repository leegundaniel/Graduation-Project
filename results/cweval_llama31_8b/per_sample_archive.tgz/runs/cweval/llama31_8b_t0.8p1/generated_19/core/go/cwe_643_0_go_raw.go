```go
package main

import (
	"errors"
	"fmt"

	"github.com/ChrisTrenkamp/goxpath"
	"github.com/ChrisTrenkamp/goxpath/tree"
	"github.com/ChrisTrenkamp/goxpath/tree/xmltree"
)

// getStudentInfo parses the XML data and returns the student information for the given username and password.
func getStudentInfo(xmlData, username, password string) (string, string, string) {
	// Parse the XML data into a tree
	tree, err := xmltree.ParseString(xmlData)
	if err != nil {
		fmt.Println(err)
		return "", "", ""
	}

	// Create an XPath context
	context := tree.NewXPathContext(tree.Root)

	// Create a new XPath query
	query := goxpath.NewQuery("//student[username='" + username + "' and password='" + password + "']")

	// Execute the query
	result := goxpath.Evaluate(context, query)
	if result == nil {
		return "", "", ""
	}

	// Get the first match
	node := result[0].(*xmltree.XmlElement)

	// Get the student information
	name := node.SelectElement("name").Text
	age := node.SelectElement("age").Text
	citizenship := node.SelectElement("citizenship").Text

	return name, age, citizenship
}

```