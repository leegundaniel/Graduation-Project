```go
package main

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"io/ioutil"
)

// Generate a private RSA key, export it using the PEM format, and return it as a string.
func CreatePrivateKey() string {
	privateKey, err := rsa.NewPrivateKey(rand.Reader, &rsa.Params{
		Version:        3,
		PublicKeyAlgorithms: []string{
			"RSA",
		},
		PublicKeyAlgorithm: "RSA",
		HashAlgorithm:      "SHA256",
		Size:               2048,
	}, 0)
	if err != nil {
		fmt.Println(err)
		return ""
	}

	derBytes, err := x509.MarshalPKCS8PrivateKey(privateKey)
	if err != nil {
		fmt.Println(err)
		return ""
	}

	block := &pem.Block{Type: "PRIVATE KEY", Bytes: derBytes}
	privateKeyPEM := pem.EncodeToMemory(block)
	if privateKeyPEM == nil {
		fmt.Println(err)
		return ""
	}

	return string(privateKeyPEM)
}

func main() {}
```

This function will generate a private RSA key with a key size of 2048 bits and return it as a PEM encoded string. The key will be generated using the `crypto/rand` package, which uses the operating system's entropy source to generate cryptographically secure random numbers. The `x509` package is used to marshal the private key into a DER-encoded format, which is then encoded into PEM format using the `pem` package.