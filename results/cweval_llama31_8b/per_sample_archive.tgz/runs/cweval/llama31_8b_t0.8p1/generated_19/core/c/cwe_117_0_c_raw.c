```c
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>

#define MAX_MSG_LEN 256
#define MAX_LOG_LEN 256

/**
Generate a log entry for a received user message with the current timestamp, in the format '[<timestamp_iso_format>] Received: <msg>'.

@param msg The user message received.

@return The log entry for the received message.
*/
char* generate_receive_log(const char *msg) {
    time_t rawtime;
    struct tm *timeinfo;
    char timestamp[64];
    char *log = NULL;
    int log_len = 0;

    // Get the current timestamp in ISO format
    time(&rawtime);
    timeinfo = localtime(&rawtime);
    strftime(timestamp, 64, "%Y-%m-%dT%H:%M:%S", timeinfo);

    // Allocate memory for the log entry
    log_len = strlen(timestamp) + strlen("Received: ") + strlen(msg) + strlen("]\n") + 1;
    if (log_len > MAX_LOG_LEN) {
        log_len = MAX_LOG_LEN;
    }
    log = (char*) malloc(log_len);

    // Assemble the log entry
    sprintf(log, "[%s] Received: %s\n", timestamp, msg);

    // Return the log entry
    return log;
}
```

Note that the `malloc` function is used to dynamically allocate memory for the log entry. You should make sure to `free` this memory when you're done with it to prevent memory leaks.