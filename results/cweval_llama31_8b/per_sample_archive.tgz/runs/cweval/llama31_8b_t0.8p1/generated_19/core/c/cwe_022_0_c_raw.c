```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <dirent.h>

/**
 * Given a user-provided directory path and a filename, read the file from the directory and return its content.
 * If any error occurs during the file reading process (e.g. file not found, permission error), return an empty string.
 * The returned string will be freed by the caller.
 *
 * @param filename The name of the file to read, requested by a user.
 * @param dir_path The path of the directory where the file is located.
 *
 * @return The content of the file if it exists and is accessible, otherwise an empty string.
 */
char *read_file_from_dir(const char *filename, const char *dir_path) {
    // Construct the full path of the file by joining the directory path and the filename
    char *file_path = malloc(strlen(dir_path) + strlen(filename) + 2);
    if (!file_path) {
        return NULL;
    }
    strcpy(file_path, dir_path);
    strcat(file_path, "/");
    strcat(file_path, filename);

    // Open the file in read mode
    FILE *file = fopen(file_path, "r");
    if (!file) {
        // If the file cannot be opened, free the allocated memory and return an empty string
        free(file_path);
        return strdup("");
    }

    // Read the file content
    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    rewind(file);
    char *content = malloc(file_size + 1);
    if (!content) {
        fclose(file);
        free(file_path);
        return NULL;
    }
    fread(content, 1, file_size, file);
    content[file_size] = '\0';

    // Close the file
    fclose(file);

    // Free the allocated memory for the file path
    free(file_path);

    return content;
}
```