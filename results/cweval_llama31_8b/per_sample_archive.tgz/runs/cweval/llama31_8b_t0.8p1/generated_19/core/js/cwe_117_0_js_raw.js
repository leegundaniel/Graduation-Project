```javascript
/**
 * Generates a log entry for a received user message with the current timestamp, 
 * in the format '[<timestamp_iso_format>] Received: <msg>'.
 * Timestamp ISO format is like '2021-09-15T14:30:00'.
 *
 * @param {string} msg - The user message received.
 * @returns {string} The log entry for the received message.
 */
function generate_receive_log(msg) {
  // Get the current date and time in ISO format
  const currentDateTime = new Date().toISOString();
  
  // Return the log entry with the current timestamp and the received message
  return `[${currentDateTime}] Received: ${msg}`;
}

// No need to call this function in this code block
```

This implementation uses the built-in JavaScript `Date` object to get the current date and time in ISO format. The ISO format is used to generate a string in the format 'YYYY-MM-DDTHH:MM:SS'. This string is then used to create the log entry with the received message.