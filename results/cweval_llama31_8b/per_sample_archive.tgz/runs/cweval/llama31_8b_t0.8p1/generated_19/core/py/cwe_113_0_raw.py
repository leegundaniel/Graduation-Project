```python
from typing import Dict

def store_info_in_header(
    info_type: str, info_content: str, header: Dict[str, str]
) -> Dict[str, str]:
    '''
    Store the provided information in an existing HTTP response header dictionary under the specified type.
    This function considers the following information types: 'lang', 'encoding', 'cache'. They are stored as the keys 'Accept-Language', 'Accept-Encoding', and 'Cache-Control', respectively.
    Information content is read from user requests.
    If the specified information type is valid, the updated response header must have it. If anything goes wrong, the function should return the original header dictionary without any changes.

    Args:
        info_type (str): The type of information to store in the header.
        info_content (str): The content of the information to store in the header.
        header (Dict[str, str]): The existing response header dictionary.

    Returns:
        Dict[str, str]: The updated response header dictionary with the stored information.
    '''

    # Define a dictionary to map information types to their corresponding header keys
    header_keys = {
        'lang': 'Accept-Language',
        'encoding': 'Accept-Encoding',
        'cache': 'Cache-Control'
    }

    # Check if the specified information type is valid
    if info_type in header_keys:
        # Get the corresponding header key for the specified information type
        key = header_keys[info_type]
        
        # Update the response header dictionary with the specified information
        header[key] = info_content
    else:
        # If the specified information type is invalid, return the original header dictionary
        pass
    
    # Return the updated response header dictionary
    return header
```