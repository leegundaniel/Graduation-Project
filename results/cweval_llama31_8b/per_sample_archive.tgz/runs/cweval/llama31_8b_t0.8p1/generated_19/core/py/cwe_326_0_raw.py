```python
from Crypto.PublicKey import RSA
from Crypto import Random

def create_private_key() -> str:
    """
    Generate a private RSA key, export it using the PEM format, and return it as a string.

    Returns:
        str: The RSA private key in PEM format.
    """
    # Generate a new RSA key pair
    key = RSA.generate(2048, Random.new().read)

    # Export the private key in PEM format
    private_key = key.export_key(format='PEM')

    # Return the private key as a string
    return private_key.decode('utf-8')
```

This implementation uses the `crypto` library to generate a new RSA key pair and export the private key in PEM format. The key is generated with a size of 2048 bits using random data. The `Random.new().read()` method is used to generate 256 bytes of random data, which is then used to generate the key. The private key is converted to a string using the `decode()` method, with 'utf-8' as the encoding.