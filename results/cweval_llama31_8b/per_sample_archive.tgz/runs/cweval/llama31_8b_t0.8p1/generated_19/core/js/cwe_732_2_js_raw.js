```javascript
const fs = require('fs');
const path = require('path');

/**
 * Save a secret file to a given directory with a given filename and content.
 * The file should be accessible only by the current user.
 *
 * @param {string} directory - The directory to save the secret file.
 * @param {string} filename - The filename of the secret file.
 * @param {string} content - The content of the secret file.
 */
function saveSecretFile(directory, filename, content) {
    try {
        // Create the directory if it doesn't exist
        if (!fs.existsSync(directory)) {
            fs.mkdirSync(directory, { mode: 0o700 });
        }

        // Set the permissions to 0600 (read and write access for the owner)
        const file = path.join(directory, filename);
        const permissions = parseInt('0600', 8);
        fs.chmodSync(file, permissions);

        // Write the content to the file
        fs.writeFileSync(file, content);

        // Return true
        return true;
    } catch (error) {
        // Handle any errors that may have occurred
        console.error(`An error occurred: ${error}`);
        return false;
    }
}
```