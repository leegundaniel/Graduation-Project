```cpp
#include <iostream>
#include <fstream>
#include <string>

/**
 * Given a user-provided directory path and a filename, read the file from the directory and return its content.
 * If any error occurs during the file reading process (e.g. file not found, permission error), return an empty string.

@param filename The name of the file to read, requested by a user.
@param dir_path The path of the directory where the file is located.

@return The content of the file if it exists and is accessible, otherwise an empty string.
*/
std::string read_file_from_dir(const std::string &filename, const std::string &dir_path) {
    try {
        // Construct the full path of the file by joining the directory path and filename
        std::string file_path = dir_path + "/" + filename;
        
        // Open the file in read mode
        std::ifstream file(file_path);
        if (!file.is_open()) {
            // If the file cannot be opened, return an empty string
            return "";
        }
        
        // Read the file content
        std::string content((std::istreambuf_iterator<char>(file)), (std::istreambuf_iterator<char>()));
        return content;
    } catch (const std::exception &e) {
        // Catch any exception that occurs during file reading and return an empty string
        return "";
    }
}
```
This function will attempt to read a file from a specified directory and return its content as a string. If the file does not exist, cannot be accessed due to permission issues, or any other error occurs during file reading, it will catch the exception and return an empty string.