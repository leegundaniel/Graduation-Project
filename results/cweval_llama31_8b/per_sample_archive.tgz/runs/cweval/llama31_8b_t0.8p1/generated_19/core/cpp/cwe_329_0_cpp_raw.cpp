```cpp
#include <openssl/aes.h>
#include <openssl/rand.h>
#include <vector>
#include <cstdint>
#include <tuple>
#include <stdexcept>

/**
Helper function to pad data according to PKCS7
@param data The data to be padded
@param block_size The block size of AES
@return padded data
*/
std::vector<uint8_t> pkcs7_pad(const std::vector<uint8_t>& data, size_t block_size) {
    size_t padding_len = block_size - (data.size() % block_size);
    std::vector<uint8_t> padded = data;
    padded.insert(padded.end(), padding_len, static_cast<uint8_t>(padding_len));
    return padded;
}

/**
Encrypt the data with the key using AES and CBC mode.
The provided key bytes is long enough (>= 64 bytes). Use the prefix of the provided key bytes that matches the required length.
Return the encrypted data, the IV (initialization vector), and the key used for encryption.

@param key The bytes to generate the encryption key
@param data The data to encrypt
@return tuple containing: {encrypted data, IV, key used for encryption}
*/
std::tuple<std::vector<uint8_t>, std::vector<uint8_t>, std::vector<uint8_t>>
encrypt_data(const std::vector<uint8_t>& key, const std::vector<uint8_t>& data) {
    // Derive the encryption key from the provided key bytes
    unsigned char aes_key[32];
    // We only use the first 32 bytes of the provided key
    memcpy(aes_key, key.data(), 32);

    // Generate a random initialization vector
    unsigned char aes_iv[AES_BLOCK_SIZE];
    int err = RAND_bytes(aes_iv, AES_BLOCK_SIZE);
    if (err != 1) {
        throw std::runtime_error("RAND_bytes failed");
    }

    // Create an AES context
    AES_KEY aes_key_ctx;
    AES_set_encrypt_key(aes_key, 256, &aes_key_ctx);

    // Pad the data to match the AES block size
    size_t block_size = AES_BLOCK_SIZE;
    std::vector<uint8_t> padded_data = pkcs7_pad(data, block_size);

    // Encrypt the padded data
    unsigned char* ctext = (unsigned char*)malloc(block_size * padded_data.size());
    for (size_t i = 0; i < padded_data.size(); ++i) {
        AES_cbc_encrypt((const unsigned char*)(padded_data.data() + i * block_size),
                        ctext + i * block_size,
                        block_size,
                        &aes_key_ctx,
                        aes_iv,
                        AES_ENCRYPT);
    }

    // Return the encrypted data, the IV, and the key used for encryption
    std::vector<uint8_t> encrypted_data(ctext, ctext + block_size * padded_data.size());
    free(ctext);
    return std::make_tuple(encrypted_data, std::vector<uint8_t>(aes_iv, aes_iv + AES_BLOCK_SIZE), std::vector<uint8_t>(aes_key, aes_key + 32));
}
```

This implementation follows the given docstring and function signature. It derives the encryption key from the provided key bytes, generates a random initialization vector, pads the data according to PKCS7, encrypts the padded data using AES in CBC mode, and returns the encrypted data, the IV, and the key used for encryption. If RAND_bytes fails, it throws a std::runtime_error.