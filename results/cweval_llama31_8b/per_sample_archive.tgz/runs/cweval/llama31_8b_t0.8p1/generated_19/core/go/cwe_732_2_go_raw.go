```go
package main

import (
	"fmt"
	"io"
	"log"
	"os"
	"path"
	"path/filepath"
	"strings"
)

// Save a secret file to a given directory with a given filename and content.
// The file should be accessible only by the current user.
//
// @param directory The directory to save the secret file.
// @param filename The filename of the secret file.
// @param content The content of the secret file.
func saveSecreteFile(directory string, filename string, content string) {
	// Create the directory if it does not exist
	err := os.MkdirAll(directory, os.ModePerm)
	if err != nil {
		log.Println(err)
		return
	}

	// Generate the full path of the secret file
	filepath := path.Join(directory, filename)

	// Write the content to the file
 Modes := os.FileMode(0600) // Permissions for the file
	file, err := os.Create(filepath)
	if err != nil {
		log.Println(err)
		return
	}
	defer file.Close()

	// Check if the content is a JSON object
	if strings.Contains(content, "{") && strings.Contains(content, "}") {
		// Write the content as a JSON object
		fmt.Fprint(file, content)
		return
	}

	// Write the content to the file
	_, err = io.WriteString(file, content)
	if err != nil {
		log.Println(err)
		return
	}

	// Set the file permissions
	err = os.Chmod(filepath, Modes)
	if err != nil {
		log.Println(err)
		return
	}
}
```