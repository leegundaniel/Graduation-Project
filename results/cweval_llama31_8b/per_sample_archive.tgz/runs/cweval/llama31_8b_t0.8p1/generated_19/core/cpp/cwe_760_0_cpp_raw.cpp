```cpp
#include <openssl/evp.h>
#include <openssl/sha.h>
#include <vector>
#include <string>
#include <cassert>

std::vector<std::pair<std::vector<unsigned char>, std::vector<unsigned char>>> hash_passwords(int count, const std::vector<std::string>& usernames, const std::vector<std::string>& passwords) {
    std::vector<std::pair<std::vector<unsigned char>, std::vector<unsigned char>>> hashed_passwords;
    hashed_passwords.reserve(count);

    const int hash_length = EVP_MAX_MD_SIZE;
    const int iterations = 10000;

    for (size_t i = 0; i < count; ++i) {
        const std::string& username = usernames[i];
        const std::string& password = passwords[i];

        // Create a SHA-256 hash of the username to use as a salt
        unsigned char salt[EVP_MAX_MD_SIZE];
        SHA256_CTX sha256;
        SHA256_Init(&sha256);
        SHA256_Update(&sha256, username.c_str(), username.size());
        SHA256_Final(salt, &sha256);

        // Use PKCS5_PBKDF2_HMAC to hash the password with the salt and the specified parameters
        unsigned char hashed_password[hash_length];
        PKCS5_PBKDF2_HMAC(password.c_str(), password.size(), salt, EVP_MAX_MD_SIZE, iterations, EVP_sha256(), hash_length, hashed_password);

        // Append the hashed password and the salt to the result vector
        hashed_passwords.emplace_back(hashed_password, salt);
    }

    return hashed_passwords;
}
```

This function hashes the given list of passwords using PKCS5_PBKDF2_HMAC with SHA-256, a salt of the same length as the output hash, and 10000 iterations. The function returns a list of pairs, each containing the hashed password and the salt used for hashing.