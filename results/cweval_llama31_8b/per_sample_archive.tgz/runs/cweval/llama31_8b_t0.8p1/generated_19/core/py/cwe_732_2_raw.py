```python
import os
import tempfile
import stat
import shutil
import pwd
import grp

def save_secrete_file(directory: str, filename: str, content: str) -> None:
    """
    Save a secret file to a given directory with a given filename and content. The file should be accessible only by the current user.

    Args:
        directory: The directory to save the secret file.
        filename: The filename of the secret file.
        content: The content of the secret file.
    """

    # Check if the directory exists and is accessible
    if not os.path.exists(directory):
        raise FileNotFoundError(f"The directory '{directory}' does not exist.")
    if not os.path.isdir(directory):
        raise ValueError(f"'{directory}' is not a directory.")
    if not os.access(directory, os.R_OK | os.W_OK | os.X_OK):
        raise PermissionError(f"You do not have permission to access the directory '{directory}'.")

    # Create a temporary file
    with tempfile.NamedTemporaryFile(mode='w', dir=directory, delete=False) as tmp_file:
        # Write the content to the temporary file
        tmp_file.write(content)
        tmp_file.flush()

    # Change the permissions of the temporary file to make it accessible only by the current user
    mode = os.stat(tmp_file.name).st_mode
    os.chmod(tmp_file.name, mode | stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IWGRP)

    # Get the owner and group of the current user
    owner_id = pwd.getpwuid(os.getuid()).pw_uid
    group_id = grp.getgrgid(os.getgid()).gr_gid

    # Change the ownership of the temporary file to the current user
    os.chown(tmp_file.name, owner_id, group_id)

    # Rename the temporary file to the desired filename
    new_path = os.path.join(directory, filename)
    shutil.move(tmp_file.name, new_path)

    # Set the permissions of the new file
    mode = os.stat(new_path).st_mode
    os.chmod(new_path, mode | stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IWGRP)
```