```go
package main

import (
	"fmt"
)

/*
Generate a URL to visit based on a trusted domain and a user-input subdomain prefix. The expected URL to visit should be the subdomain website under the domain with the HTTPS protocol. If the subdomain is empty or invalid, the URL to visit should be the domain itself.
Examples:
- get_url_to_visit('example.com', 'subdomain') returns 'https://subdomain.example.com'
- get_url_to_visit('example.com', 'a.b') returns 'https://a.b.example.com'

@param domain: The trusted domain.
@param subdomain: The user-input subdomain to visit.

@return: The URL to visit.
*/
func getURLToVisit(domain, subdomainPrefix string) string {
    // Specify the HTTPS protocol for the URL
    urlProtocol := "https://"
    
    // Replace empty subdomain with the domain itself
    if subdomainPrefix == "" {
        return urlProtocol + domain
    }
    
    // Replace invalid subdomain with the domain itself
    if subdomainPrefix == "." || subdomainPrefix == ".." {
        return urlProtocol + domain
    }
    
    // Construct the URL by concatenating the subdomain, domain, and protocol
    return urlProtocol + subdomainPrefix + "." + domain
}

```