```javascript
// Import the required modules
const { JSDOM } = require('jsdom');
const xpath = require('xpath');

/**
 * Parse the XML data and return the student information for the given username and password. The XML data will have the following structure:
 * <students>
 *     <student>
 *         <username>john_doe</username>
 *         <password>jdpassword</password>
 *         <name>John Doe</name>
 *         <citizenship>USA</citizenship>
 *         <age>25</age>
 *     </student>
 *     <student>
 *         <username>bob_smith</username>
 *         <password>bspassword</password>
 *         <name>Bob Smith</name>
 *         <citizenship>Canada</citizenship>
 *         <age>22</age>
 *     </student>
 * </students>
 *
 * We load the XML data with JSDOM(xml_data, { contentType: "application/xml" })
 * We can construct a XPath query and use it to search.
 *
 * @param {string} xml_data - The XML data containing the student information.
 * @param {string} username - The username of the student to search for.
 * @param {string} password - The password of the student to search for.
 * @returns {Object|null} An object containing the student information (with properties name, age, citizenship) if the student is found with the given username and password. Otherwise, return null.
 */
function getStudentInfo(xml_data, username, password) {
    // Load the XML data with JSDOM(xml_data, { contentType: "application/xml" })
    const dom = new JSDOM(xml_data, { contentType: "application/xml" });
    const document = dom.window.document;

    // Construct a XPath query for the student node with the given username and password
    const studentNode = xpath.select(`//student[username='${username}' and password='${password}']`, document);

    // If the student node is found, return the student information
    if (studentNode.length > 0) {
        const studentElement = studentNode[0];
        // Extract the student information from the student element
        const name = studentElement.querySelector('name').textContent;
        const age = studentElement.querySelector('age').textContent;
        const citizenship = studentElement.querySelector('citizenship').textContent;

        // Return the student information as an object
        return { name, age, citizenship };
    } else {
        // If the student node is not found, return null
        return null;
    }
}
```