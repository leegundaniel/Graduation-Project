```go
package main

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"math/big"
)

/*
Given a list of passwords of users, use PBKDF2-HMAC to hash the passwords. You should use SHA-256 (by sha256.New()), salts of the same length as the output hash, and 10000 iterations. Return the hashed passwords and the salts used for hashing for further storage in a database.

@param count The number of passwords to hash.
@param usernames A list of usernames.
@param passwords A list of passwords of the users to hash.

@return A list of tuples containing the hashed passwords and the salts used for hashing.
*/
func hashPasswords(count int, usernames []string, passwords []string) [][2]string {
	result := make([][2]string, count)
	for i := range usernames {
		// Generate a random salt
		salt, err := generateSalt(32)
		if err != nil {
			fmt.Println(err)
			continue
		}

		// Hash the password using PBKDF2-HMAC
		hashedPassword, err := pbkdf2HMAC(passwords[i], salt, 10000, 32, sha256.New())
		if err != nil {
			fmt.Println(err)
			continue
		}

		// Store the hashed password and the salt
		result[i][0] = hex.EncodeToString(hashedPassword)
		result[i][1] = hex.EncodeToString(salt)
	}

	return result
}

// Generate a random salt
func generateSalt(length int) ([]byte, error) {
	salt := make([]byte, length)
	_, err := rand.Read(salt)
	if err != nil {
		return nil, err
	}
	return salt, nil
}

// PBKDF2-HMAC function
func pbkdf2HMAC(password, salt []byte, iterations int, digestSize int, hash func() hash.Hash) ([]byte, error) {
	h := hash.New()
	h.Write(salt)
	for i := int64(1); i <= iterations; i++ {
		h.Write(password)
		if _, err := h.Sum(nil); err != nil {
			return nil, err
		}
		h.Reset()
	}
	return h.Sum(nil), nil
}
```