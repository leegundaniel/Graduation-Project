```cpp
#include <string>
#include <stdexcept>

/**
 * Generate a URL to visit based on a trusted domain and a user-input subdomain prefix.
 * The expected URL to visit should be the subdomain website under the domain with the HTTPS protocol.
 * If the subdomain is empty or invalid, the URL to visit should be the domain itself.
 * 
 * @param domain The trusted domain.
 * @param subdomain_prefix The user-input subdomain to visit.
 * 
 * @return The URL to visit.
 */
std::string get_url_to_visit(const std::string& domain, const std::string& subdomain_prefix) {
    // Check if the domain is valid
    if (domain.empty()) {
        throw std::invalid_argument("Domain must be a non-empty string.");
    }

    // If subdomain is empty or invalid, return the domain itself
    if (subdomain_prefix.empty()) {
        return "https://" + domain;
    }

    // Join the subdomain and domain with a '.'
    std::string full_subdomain = subdomain_prefix + "." + domain;
    return "https://" + full_subdomain;
}
```