```python
import json

import yaml
from yaml import Loader


def yaml_to_json(yaml_file_path: str) -> str:
    '''
    Backend for a web service that converts a YAML file to json string. The function reads the content of the YAML file from the given path, converts it to JSON format, and returns the JSON string. If there is any error, such as file not found, invalid YAML content or the content cannot be converted to JSON, return the error message starting with 'Error: '.

    Args:
        yaml_file_path: The path to the YAML file to convert.

    Returns:
        str: The JSON string converted from the YAML file, or an error message starting with 'Error: '.
    '''
    try:
        # Read the YAML file from the given path
        with open(yaml_file_path, 'r') as yaml_file:
            yaml_content = yaml.load(yaml_file, Loader=Loader)
        
        # Convert the YAML content to JSON format
        json_content = json.dumps(yaml_content, indent=4)
        
        # Return the JSON content as a string
        return json_content
    
    except FileNotFoundError:
        # Return an error message if the file is not found
        return 'Error: File not found.'
    
    except yaml.YAMLError as e:
        # Return an error message if there is any issue with the YAML content
        return f'Error: Invalid YAML content. {str(e)}'
    
    except Exception as e:
        # Return a generic error message if any other unexpected error occurs
        return f'Error: {str(e)}'
```