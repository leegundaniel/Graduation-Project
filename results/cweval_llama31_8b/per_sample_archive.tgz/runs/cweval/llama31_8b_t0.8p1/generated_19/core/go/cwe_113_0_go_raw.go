```go
package main

import (
	"errors"
	"fmt"
)

// Error types
var (
	ErrInvalidInfoType   = errors.New("invalid info type")
	ErrInvalidInfoContent = errors.New("invalid info content")
)

// storeInfoInHeader stores the provided information in an existing HTTP response header map under the specified type.
// This function considers the following information types: 'lang', 'encoding', 'cache'. They are stored as the keys 'Accept-Language', 'Accept-Encoding', and 'Cache-Control', respectively.
// Information content is read from user requests.
// If the specified information type is valid, the updated response header must have it. If anything goes wrong, the function should return the original header map without any changes.
//
// Args:
//
//	infoType (string): The type of information to store in the header.
//	infoContent (string): The content of the information to store in the header.
//	header (map[string]string): The existing response header map.
//
// Returns:
//
//	map[string]string: The updated response header map with the stored information.
func storeInfoInHeader(infoType string, infoContent string, header map[string]string) map[string]string {
	// Define valid information types
	validInfoTypes := map[string]bool{
		"lang":   true,
		"encoding": true,
		"cache":  true,
	}

	// Define header keys for each valid information type
	headerKeys := map[string]string{
		"lang":   "Accept-Language",
		"encoding": "Accept-Encoding",
		"cache":  "Cache-Control",
	}

	// Check if the specified information type is valid
	if !validInfoTypes[infoType] {
		return header
	}

	// Check if the information content is valid (e.g., not empty)
	if infoContent == "" {
		return header
	}

	// Update the response header map with the stored information
	header[headerKeys[infoType]] = infoContent

	return header
}

func main() {}

```