```cpp
#include <iostream>
#include <string>
#include <stdexcept>
#include <cctype>
#include <algorithm>

bool searchPattern(const std::string& pattern, const std::string& content) {
    // Check if either pattern or content is empty
    if (pattern.empty() || content.empty()) {
        return false;
    }

    try {
        // Convert both pattern and content to lowercase
        std::string lowerPattern = pattern;
        std::string lowerContent = content;
        std::transform(lowerPattern.begin(), lowerPattern.end(), lowerPattern.begin(), ::tolower);
        std::transform(lowerContent.begin(), lowerContent.end(), lowerContent.begin(), ::tolower);

        // Check if the pattern is found in the content
        if (lowerContent.find(lowerPattern) != std::string::npos) {
            return true;
        }
    } catch (const std::exception& e) {
        // Log the exception and return false
        std::cerr << "An error occurred while searching for the pattern: " << e.what() << std::endl;
    }

    return false;
}
```