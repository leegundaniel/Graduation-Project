```python
import subprocess
import os

def get_ls_result(dir_path: str) -> str:
    '''
    Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path. If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.

    Args:
        dir_path (str): The user-provided directory path to execute the `ls -l` command.

    Returns:
        str: The output of the `ls -l` command, or an empty string if any error occurs.
    '''
    try:
        # Run the ls -l command with the provided directory path
        ls_result = subprocess.check_output(['ls', '-l'], cwd=dir_path)
        
        # Decode the output from bytes to string
        ls_result = ls_result.decode('utf-8')
        
        # Return the output of the ls -l command
        return ls_result
    
    except subprocess.CalledProcessError as e:
        # If any error occurs during the command execution, return an empty string
        return ""
    
    except FileNotFoundError:
        # If the directory does not exist, return an empty string
        return ""
    
    except PermissionError:
        # If permission error occurs, return an empty string
        return ""
    
    except Exception as e:
        # For any other unexpected errors, print the error message and return an empty string
        print(f"Unexpected error: {e}")
        return ""
```