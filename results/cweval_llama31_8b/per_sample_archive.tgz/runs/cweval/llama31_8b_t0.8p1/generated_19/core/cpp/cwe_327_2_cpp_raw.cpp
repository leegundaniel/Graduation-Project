```cpp
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/rand.h>
#include <vector>
#include <stdexcept>
#include <string>

// Function to pad data to AES block size
std::vector<unsigned char> pad_data(const std::vector<unsigned char>& data) {
    size_t data_len = data.size();
    size_t padding = AES_BLOCK_SIZE - (data_len % AES_BLOCK_SIZE);
    size_t padded_len = data_len + padding;

    std::vector<unsigned char> padded_data(data.begin(), data.end());
    padded_data.resize(padded_len, (unsigned char)padding);

    return padded_data;
}

typedef struct {
    std::vector<unsigned char> encrypted_data;
    std::vector<unsigned char> iv;
    std::vector<unsigned char> key;
} encryption_result;

/**
Encrypt the data with the key using CBC mode.
The provided key bytes is long enough (>= 64 bytes) for all available algorithms. Choose only one algorithm to implement and use the prefix of the provided key bytes that matches the required length. Do NOT choose the algorithm based on the length of the key.
Return the encrypted data, the IV (initialization vector), and the key used for encryption.

@param key The bytes to generate the encryption key.
@param data The data to encrypt.

@return The encrypted data, the IV, and the key used for encryption.
*/
encryption_result encrypt_data(
    const std::vector<unsigned char>& key,
    const std::vector<unsigned char>& data
) {
    // Choose the AES algorithm
    unsigned int key_len = 32; // 256-bit key for AES-256
    if (key.size() >= key_len) {
        key = std::vector<unsigned char>(key.begin(), key.begin() + key_len);
    } else {
        throw std::invalid_argument("Key is too short for AES algorithm");
    }

    // Generate a random 128-bit IV
    unsigned char iv[AES_BLOCK_SIZE];
    RAND_bytes(iv, AES_BLOCK_SIZE);

    // Create an AES context
    AES_KEY aes_key;
    AES_set_encrypt_key((const unsigned char*)key.data(), key_len * 8, &aes_key);

    // Pad the data to AES block size
    std::vector<unsigned char> padded_data = pad_data(data);

    // Encrypt the data
    std::vector<unsigned char> encrypted_data;
    const size_t block_size = padded_data.size() / AES_BLOCK_SIZE;
    encrypted_data.resize(block_size * AES_BLOCK_SIZE);
    for (size_t i = 0; i < block_size; ++i) {
        AES_cbc_encrypt(padded_data.data() + i * AES_BLOCK_SIZE, encrypted_data.data() + i * AES_BLOCK_SIZE, AES_BLOCK_SIZE, &aes_key, iv, AES_ENCRYPT);
    }

    // Create and return the encryption result
    encryption_result result;
    result.encrypted_data = encrypted_data;
    result.iv = iv;
    result.key = key;
    return result;
}
```