```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>

/**
Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path. If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.

@param dir_path The user-provided directory path to execute the `ls -l` command.

@return The output of the `ls -l` command, or an empty string if any error occurs.
*/
char *get_ls_result(const char *dir_path) {
    // Create a pipe to capture the stdout of the ls command
    int pipefd[2];
    if (pipe(pipefd) == -1) {
        return NULL; // malloc will fail and return NULL
    }

    // Fork and exec the ls command in the child process
    pid_t pid = fork();
    if (pid == -1) {
        close(pipefd[0]);
        close(pipefd[1]);
        return NULL;
    }

    if (pid == 0) {
        // Child process
        close(pipefd[0]); // Close the read end of the pipe
        dup2(pipefd[1], STDOUT_FILENO); // Redirect stdout to the write end of the pipe
        close(pipefd[1]); // Close the write end of the pipe

        char *argv[] = {"ls", "-l", dir_path, NULL};
        if (execvp(argv[0], argv) == -1) {
            close(pipefd[1]);
            _exit(1); // Exit with a non-zero status code
        }
    } else {
        // Parent process
        close(pipefd[1]); // Close the write end of the pipe

        char buffer[1024];
        ssize_t bytes_read;
        char *output = NULL;
        size_t output_len = 0;
        do {
            bytes_read = read(pipefd[0], buffer, sizeof(buffer));
            if (bytes_read == -1) {
                free(output);
                return NULL;
            }
            buffer[bytes_read] = '\0';

            output = realloc(output, output_len + bytes_read + 1);
            if (output == NULL) {
                free(output);
                return NULL;
            }
            strcpy(output + output_len, buffer);
            output_len += bytes_read;
        } while (bytes_read > 0);

        close(pipefd[0]);
        wait(NULL); // Wait for the child process to terminate

        return output;
    }
}
```

This implementation creates a pipe to capture the stdout of the `ls` command, then forks a new process and execs the `ls` command in it. The parent process reads from the pipe and stores the output. If any error occurs during the command execution, the function returns an empty string.