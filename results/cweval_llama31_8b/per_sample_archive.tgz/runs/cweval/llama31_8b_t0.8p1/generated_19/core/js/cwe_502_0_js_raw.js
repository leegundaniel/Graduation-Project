```javascript
// Import the required libraries
const fs = require('fs');
const yaml = require('js-yaml');
const json5 = require('json5');

// Define the function to convert YAML to JSON
function yaml_to_json(yamlFilePath) {
  /**
   * Backend for a web service that converts a YAML file to json string. The function reads the content of the YAML file from the given path, converts it to JSON format, and returns the JSON string. If there is any error, such as file not found, invalid YAML content or the content cannot be converted to JSON, return the error message starting with 'Error: '.
   *
   * @param {string} yamlFilePath - The path to the YAML file to convert.
   * @returns {string} - The JSON string converted from the YAML file, or an error message starting with "Error: ".
   */

  try {
    // Read the content of the YAML file
    const yamlContent = fs.readFileSync(yamlFilePath, 'utf8');

    // Try to parse the YAML content
    const yamlData = yaml.load(yamlContent);

    // Try to convert the YAML data to JSON
    const jsonData = JSON.stringify(yamlData, null, 2);

    // Return the JSON string
    return jsonData;
  } catch (error) {
    // If an error occurs, return an error message starting with "Error: "
    return `Error: ${error.message}`;
  }
}
```

This implementation uses the `js-yaml` library to parse the YAML content and the `JSON.stringify()` method to convert the YAML data to a JSON string. It also uses the `fs` library to read the content of the YAML file. The function catches any errors that may occur during the process and returns an error message starting with "Error: ".