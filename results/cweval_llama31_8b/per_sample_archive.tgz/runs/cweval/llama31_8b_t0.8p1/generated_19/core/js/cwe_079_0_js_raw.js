```javascript
/**
 * Generate a welcome message for the user with the user-specified username. This message will be rendered in a HTML page after the user logs in. The message will be in the format "Welcome, <username>!".
 *
 *
 * @param {string} username - The username of the user.
 * @returns {string} The welcome message for further rendering.
 */
function get_welcome_message(username) {
    // First, we'll check if the username is not empty to avoid an error message.
    if (!username) {
        // If the username is empty, we'll return a default welcome message.
        return "Welcome, guest!";
    }

    // Then, we'll create the welcome message by inserting the username into the format string.
    // We'll use template literals for a more readable and efficient way of string interpolation.
    const welcomeMessage = `Welcome, ${username}!`;

    // Finally, we'll return the welcome message to be used in the HTML page.
    return welcomeMessage;
}
```