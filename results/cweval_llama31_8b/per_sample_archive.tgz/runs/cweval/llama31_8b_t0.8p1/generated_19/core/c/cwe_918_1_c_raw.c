```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * Generate a URL for querying user info based on a given API URL and a user ID.
 * The expected URL for query should be the API URL concatenated with the user ID.
 * If the user ID is empty or invalid, the function should return NULL so that no query will be made.
 *
 * Examples:
 * - get_url_for_query("https://example.com/api/user", "aBc123") returns 'https://example.com/api/user/aBc123'
 * - get_url_for_query("https://example.com/api/user", "") returns NULL
 *
 * @param api_url: The API URL to query user info.
 * @param user_id: The user ID to query.
 *
 * @return The URL for query. If the user ID is empty or invalid, return NULL.
 */
char* get_url_for_query(const char* api_url, const char* user_id) {
    // check if api_url is NULL or empty
    if (api_url == NULL || strcmp(api_url, "") == 0) {
        return NULL;
    }

    // check if user_id is NULL or empty
    if (user_id == NULL || strcmp(user_id, "") == 0) {
        return NULL;
    }

    // calculate the length of the new URL
    int new_url_len = strlen(api_url) + strlen(user_id) + 2;

    // allocate memory for the new URL
    char* new_url = (char*)malloc(new_url_len * sizeof(char));
    if (new_url == NULL) {
        return NULL;
    }

    // concatenate api_url and user_id
    sprintf(new_url, "%s/%s", api_url, user_id);

    return new_url;
}
```

Note: This implementation assumes that the memory for the new URL is properly freed after use to prevent memory leaks. In a real-world application, you should add error checking and proper memory management to handle potential issues.