```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/evp.h>
#include <openssl/rand.h>

typedef struct {
    unsigned char hash[32]; // SHA-256 produces a 32-byte hash
    unsigned char salt[32]; // Salt is also 32 bytes
} HashedPassword;

/**
Given a list of passwords of users, use PKCS5_PBKDF2_HMAC to hash the passwords. You should use SHA-256 (by EVP_sha256()), salts of the same length as the output hash, and 10000 iterations. Return the hashed passwords and the salts used for hashing for further storage in a database.

@param count The number of passwords to hash.
@param usernames A list of usernames.
@param passwords A list of passwords of the users to hash.

@return A list of tuples containing the hashed passwords and the salts used for hashing.
*/
HashedPassword* hash_passwords(int count, char** usernames, char** passwords) {
    HashedPassword* hashed_passwords = malloc(count * sizeof(HashedPassword));
    if (hashed_passwords == NULL) {
        return NULL; // Memory allocation failed
    }

    // Initialize EVP context
    EVP_MD_CTX* ctx;
    if ((ctx = EVP_MD_CTX_new()) == NULL) {
        free(hashed_passwords);
        return NULL; // Failed to initialize EVP context
    }

    // Iterate through each password
    for (int i = 0; i < count; i++) {
        // Generate a random salt
        if (RAND_bytes(hashed_passwords[i].salt, 32) != 1) {
            EVP_MD_CTX_free(ctx);
            free(hashed_passwords);
            return NULL; // Failed to generate random salt
        }

        // Hash the password with the generated salt
        unsigned int salt_len = 32;
        if (PKCS5_PBKDF2_HMAC(passwords[i], strlen(passwords[i]), hashed_passwords[i].salt, salt_len, 10000, EVP_sha256(), 32, hashed_passwords[i].hash) != 1) {
            EVP_MD_CTX_free(ctx);
            free(hashed_passwords);
            return NULL; // Failed to hash password
        }
    }

    EVP_MD_CTX_free(ctx);
    return hashed_passwords;
}
```

Note: Make sure to link against the OpenSSL library when compiling this code using the `-lssl` flag. The code assumes that the OpenSSL library is installed and configured properly on your system.