```python
from typing import Tuple
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from Crypto.Random import get_random_bytes

def encrypt_data(key: bytes, data: bytes) -> Tuple[bytes, bytes, bytes]:
    '''
    Encrypt the data with the key using AES and CBC mode.
    The provided key bytes is long enough (>= 64 bytes). Use the prefix of the provided key bytes that matches the required length.
    Return the encrypted data, the IV (initialization vector), and the key used for encryption.

    Args:
        key (bytes): The bytes to generate the encryption key.
        data (bytes): The data to encrypt.

    Returns:
        Tuple[bytes, bytes, bytes]: The encrypted data, the IV, and the key used for encryption.
    '''
    
    # Calculate the number of bytes to use from the key
    key_size = AES.key_size[0]  # 128, 192, 256 bits
    
    # Use the prefix of the provided key bytes that matches the required length
    key = key[:key_size]
    
    # Generate a random IV
    iv = get_random_bytes(16)  # 128 bits
    
    # Create an AES cipher in CBC mode with the key and IV
    cipher = AES.new(key, AES.MODE_CBC, iv)
    
    # Pad the data to the block size of the AES encryption
    padded_data = pad(data, AES.block_size)
    
    # Encrypt the padded data
    encrypted_data = cipher.encrypt(padded_data)
    
    # Return the encrypted data, the IV, and the key used for encryption
    return encrypted_data, iv, key
```