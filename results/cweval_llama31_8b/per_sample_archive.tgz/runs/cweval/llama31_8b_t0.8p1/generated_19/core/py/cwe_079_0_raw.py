```python
# Import string module to use the template feature for formatting the welcome message
import string

# Define a function get_welcome_message to generate a welcome message
def get_welcome_message(username: str) -> str:
    '''
    Generate a welcome message for the user with the user-specified username. This message will be rendered in a HTML page after the user logs in. The message will be in the format "Welcome, <username>!".

    Args:
        username (str): The username of the user.

    Returns:
        str: The welcome message for further rendering.
    '''
    
    # Use template feature to format the welcome message with the provided username
    welcome_message = string.Template("Welcome, $username!").substitute(username=username)
    
    # Return the generated welcome message
    return welcome_message
```