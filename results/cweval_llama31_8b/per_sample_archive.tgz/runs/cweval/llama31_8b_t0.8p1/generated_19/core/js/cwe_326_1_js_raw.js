```javascript
/**
 * Generate a private DSA key, export it using the PEM format, and return it as a string.
 *
 * @returns {string} The DSA private key in PEM format.
 */

const crypto = require('crypto');

function create_private_key_dsa() {
  // Generate a new DSA key pair
  const key = crypto.generateKeyPairSync('dsa', {
    modulusLength: 2048,
    publicExponent: 65537,
  });

  // Get the private key as a string in PEM format
  const privateKeyString = key.privateKey.export({
    type: 'pkcs8',
    format: 'pem',
  }).toString();

  return privateKeyString;
}
```

This function generates a new DSA key pair using the `crypto` module in Node.js. It then exports the private key as a string in PEM format and returns it. The `generateKeyPairSync` function generates a new public and private key pair based on the provided parameters, and the `export` function is used to convert the private key to PEM format.