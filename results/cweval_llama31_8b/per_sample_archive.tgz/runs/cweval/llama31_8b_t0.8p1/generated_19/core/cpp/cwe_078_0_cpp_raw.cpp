```cpp
#include <iostream>
#include <fstream>
#include <stdexcept>
#include <string>
#include <cstdio>

/**
 * Execute the `ls -l` command in the given directory path and return its output (only stdout).
 * If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.

 * @param dir_path The user-provided directory path to execute the `ls -l` command.

 * @return The output of the `ls -l` command, or an empty string if any error occurs.
 */
std::string get_ls_result(const std::string &dir_path) {
    // Check if the directory path is empty
    if (dir_path.empty()) {
        return "";
    }

    // Construct the full command with the directory path
    std::string command = "ls -l " + dir_path;

    // Try to execute the command and capture its output
    try {
        // Open a pipeline to the command
        std::ifstream pipe(popen(command.c_str(), "r"));
        if (!pipe.is_open()) {
            throw std::runtime_error("Failed to open pipe");
        }

        // Read the command output line by line
        std::string line;
        std::string output;
        while (std::getline(pipe, line)) {
            output += line + "\n";
        }

        // Close the pipe and wait for the process to complete
        int status = pclose(pipe.rdbuf());
        if (status == -1) {
            throw std::runtime_error("Failed to close pipe");
        }

        // Return the command output
        return output;
    }
    // Catch and handle any exceptions that occur during command execution
    catch (const std::exception &e) {
        // Return an empty string to indicate an error
        return "";
    }
}
```

This implementation uses the `std::ifstream` and `std::popen` functions to execute the `ls -l` command in a user-provided directory path and capture its output. If any error occurs during command execution, it catches the exception and returns an empty string. The `std::getline` function is used to read the command output line by line, and the `pclose` function is used to close the pipe and wait for the process to complete.