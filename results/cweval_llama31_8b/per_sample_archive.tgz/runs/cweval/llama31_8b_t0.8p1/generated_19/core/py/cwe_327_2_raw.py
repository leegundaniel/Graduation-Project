```python
from typing import Tuple
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad

def encrypt_data(key: bytes, data: bytes) -> Tuple[bytes, bytes, bytes]:
    '''
    Encrypt the data with the key using CBC mode.
    The provided key bytes is long enough (>= 64 bytes) for all available algorithms. Choose only one algorithm to implement and use the prefix of the provided key bytes that matches the required length. Do NOT choose the algorithm based on the length of the key.
    Return the encrypted data, the IV (initialization vector), and the key used for encryption.

    Args:
        key (bytes): The bytes to generate the encryption key.
        data (bytes): The data to encrypt.

    Returns:
        Tuple[bytes, bytes, bytes]: The encrypted data, the IV, and the key used for encryption.
    '''
    # Choose the AES algorithm and its key length
    algorithm = AES
    key_length = 32  # bytes (256 bits)

    # Use only the prefix of the provided key bytes that matches the required length
    encryption_key = key[:key_length]

    # Generate an IV (initialization vector)
    iv = get_random_bytes(algorithm.block_size)

    # Create a new AES cipher object with the generated key and IV
    cipher = algorithm.new(cipher_data=iv, key=encryption_key, mode=algorithm.MODE_CBC)

    # Pad the data to the block size of the algorithm
    padded_data = pad(data, algorithm.block_size)

    # Encrypt the padded data
    encrypted_data = cipher.encrypt(padded_data)

    # Return the encrypted data, IV, and the key used for encryption
    return encrypted_data, iv, encryption_key
```