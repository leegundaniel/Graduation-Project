```cpp
#include <fstream>
#include <iostream>
#include <string>
#include <sys/stat.h>
#include <sys/types.h>

// Function to create the directory if it does not exist.
void createDirectory(const std::string& directory) {
    struct stat sb;
    if (stat(directory.c_str(), &sb) != 0 || !(sb.st_mode & S_IFDIR)) {
        mkdir(directory.c_str(), S_IRWXU);
    }
}

// Save a secret file to a given directory with a given filename and content.
// The file should be accessible only by the current user.
//
// @param directory The directory to save the secret file.
// @param filename The filename of the secret file.
// @param content The content of the secret file.
void saveSecreteFile(const std::string& directory, const std::string& filename, const std::string& content) {
    // Create the directory if it does not exist.
    createDirectory(directory);

    // Construct the full path of the file.
    std::string filePath = directory + "/" + filename;

    // Create a new file with the given content and permissions.
    std::ofstream file(filePath);
    if (file.is_open()) {
        // Write the content to the file.
        file << content;

        // Close the file.
        file.close();

        // Add read permissions for the owner and group.
        chmod(filePath.c_str(), S_IRUSR | S_IRGRP);
    } else {
        std::cerr << "Unable to open file " << filePath << std::endl;
    }
}
```

Note: This code uses the `chmod` function from `<sys/stat.h>` to set the permissions of the file. This function is not available in all C++ implementations, so the code may not compile on all platforms.