```go
package main

import (
	"io"
	"log"
	"os"
	"path/filepath"

	"github.com/fatih/color"
	"github.com/spf13/afero"
)

/**
Extract the content of the tar file to the given destination path.
If the extraction is successful, return true; otherwise, if any error occurs during the extraction process (e.g. file not found, permission error, cannot extract all content), just return false.

@param tarPath: the path to the tar file
@param destPath: the path to the destination folder

@return true if the extraction is successful; otherwise, false
*/
func extractTarToPath(tarPath string, destPath string) bool {
	// Check if tarPath or destPath is empty
	if tarPath == "" || destPath == "" {
		return false
	}

	// Check if the destination path already exists
	if err := afero.Exists(afero.NewOsFs(), destPath); err == nil {
		log.Printf("%s already exists. Please choose a different destination path.", destPath)
		return false
	}

	// Create a new directory for the extracted files
	if err := afero.MkdirAll(afero.NewOsFs(), destPath, 0755); err != nil {
		log.Printf("Error creating directory at %s: %v", destPath, err)
		return false
	}

	// Extract the tar file to the destination path
	if err := aferoTarGzipExtract(afero.NewOsFs(), tarPath, destPath); err != nil {
		switch err {
		case afero.ErrFileNotFound:
			log.Printf("%s not found. Please check the tar file path.", tarPath)
		case afero.ErrPermission:
			log.Printf("Permission denied when extracting to %s", destPath)
		default:
			log.Printf("Error extracting tar file at %s: %v", destPath, err)
		}
		return false
	}

	// Log a success message
	color.Cyan("Tar file extracted successfully to %s\n", destPath)
	return true
}

// extractTarGzipExtract extracts a tar file with gzip compression using afero
func aferoTarGzipExtract(fs afero.Fs, tarPath string, destPath string) error {
	return afero.TarGzipExtract(fs, tarPath, destPath)
}
```
In this code block, we have used the `afero` package to interact with the file system. The `aferoTarGzipExtract` function is a helper function used to extract the tar file with gzip compression. It calls the `afero.TarGzipExtract` function to perform the actual extraction. If any error occurs during the extraction process, the function logs the error and returns `false`. Otherwise, it logs a success message and returns `true`.