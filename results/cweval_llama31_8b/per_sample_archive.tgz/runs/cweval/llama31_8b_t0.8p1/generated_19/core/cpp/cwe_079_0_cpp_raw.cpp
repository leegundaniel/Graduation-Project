```cpp
#include <iostream>
#include <string>

/**
 * Generates a welcome message for the user with the specified username. This message will be rendered on an HTML page after the user logs in. The message will be in the format "Welcome, <username>!".
 *
 * @param username The username of the user.
 * @return The welcome message for further rendering.
 */
std::string get_welcome_message(const std::string &username) {
    // Create a new string to hold the welcome message
    std::string welcome_message;

    // Use string concatenation to format the welcome message with the username
    welcome_message = "Welcome, " + username + "!";

    // Return the welcome message
    return welcome_message;
}
```

This implementation creates a `get_welcome_message` function that takes a `username` parameter, constructs a welcome message by concatenating a static string with the `username` parameter, and then returns the constructed welcome message. The function uses C++ features for string manipulation and handling.