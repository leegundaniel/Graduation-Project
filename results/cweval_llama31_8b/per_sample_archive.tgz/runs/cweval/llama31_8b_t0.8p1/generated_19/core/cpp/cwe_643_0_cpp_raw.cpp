```cpp
#include <string>
#include <map>
#include <libxml/parser.h>
#include <libxml/tree.h>
#include <libxml/xpath.h>

/**
 * Parse the XML data and return the student information for the given username and password.
 *
 * @param xml_data The XML data containing the student information.
 * @param username The username of the student to search for.
 * @param password The password of the student to search for.
 *
 * @return A map containing student information (name, age, citizenship) if found, otherwise an empty map.
 */
std::map<std::string, std::string> get_student_info(const std::string& xml_data, const std::string& username, const std::string& password) {
    // Parse the XML data into a xmlDocPtr object
    xmlDocPtr doc = xmlParseDoc((const xmlChar*)xml_data.c_str());
    if (doc == NULL) {
        return {};
    }

    // Create an XPath context
    xmlXPathContextPtr context = xmlXPathNewContext(doc);
    if (context == NULL) {
        xmlFreeDoc(doc);
        return {};
    }

    // Create an XPath expression to search for students with the given username and password
    const char* xpath_expr = "//student[username='" S_XPATH_ENCODE(username) "' and password='" S_XPATH_ENCODE(password) "']";
    xmlXPathObjectPtr result = xmlXPathEvalExpression((const xmlChar*)xpath_expr, context);
    if (result == NULL) {
        xmlXPathFreeContext(context);
        xmlFreeDoc(doc);
        return {};
    }

    // Get the student element with the given username and password
    xmlNodeSetPtr nodeset = result->nodesetval;
    if (nodeset && nodeset->nodeNr > 0) {
        xmlNodePtr student_node = nodeset->nodeTab[0];

        // Create a map to store the student information
        std::map<std::string, std::string> student_info;

        // Get the name element
        xmlNodePtr name_node = xmlFirstElementChild(student_node);
        while (name_node && (xmlStrcmp(name_node->name, (const xmlChar*)"name") != 0)) {
            name_node = name_node->next;
        }
        if (name_node) {
            student_info["name"] = (const char*)xmlNodeGetContent(name_node);
        }

        // Get the age element
        name_node = xmlFirstElementChild(student_node);
        while (name_node && (xmlStrcmp(name_node->name, (const xmlChar*)"age") != 0)) {
            name_node = name_node->next;
        }
        if (name_node) {
            student_info["age"] = (const char*)xmlNodeGetContent(name_node);
        }

        // Get the citizenship element
        name_node = xmlFirstElementChild(student_node);
        while (name_node && (xmlStrcmp(name_node->name, (const xmlChar*)"citizenship") != 0)) {
            name_node = name_node->next;
        }
        if (name_node) {
            student_info["citizenship"] = (const char*)xmlNodeGetContent(name_node);
        }
    }

    // Clean up
    xmlXPathFreeObject(result);
    xmlXPathFreeContext(context);
    xmlFreeDoc(doc);

    return student_info;
}
```
Note: The `S_XPATH_ENCODE` function is a utility function to encode special characters in the XPath expression, it's not implemented here. In a real-world scenario, you would need to implement this function or use a library that provides it.