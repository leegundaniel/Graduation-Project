```cpp
#include <openssl/sha.h>
#include <openssl/md5.h>
#include <openssl/err.h>
#include <openssl/pem.h>
#include <iostream>
#include <string>
#include <stdexcept>

#ifndef OPENSSL_NO_SHA
#define OPENSSL_NO_SHA 0
#endif

#ifndef OPENSSL_NO_MD5
#define OPENSSL_NO_MD5 0
#endif

std::string hashCertificate(const std::string& cert) {
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256_CTX sha256;
    MD5_CTX md5;

    if (cert.empty()) {
        return "";
    }

    // Use SHA-256 for a more secure hash
    SHA256_Init(&sha256);
    SHA256_Update(&sha256, cert.c_str(), cert.size());
    SHA256_Final(hash, &sha256);

    // Convert the hash to a hexadecimal string
    std::string sha256Hex;
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
        char hex[3];
        sprintf(hex, "%02x", hash[i]);
        sha256Hex += hex;
    }

    return sha256Hex;
}
```

This function securely hashes the given certificate using SHA-256. The result is then returned as a hexadecimal string. If the input certificate is empty, an empty string is returned. The code ensures that the necessary OpenSSL libraries are included and configured to handle SHA-256 hashing. The SHA-256 hash is then converted to a hexadecimal string and returned.