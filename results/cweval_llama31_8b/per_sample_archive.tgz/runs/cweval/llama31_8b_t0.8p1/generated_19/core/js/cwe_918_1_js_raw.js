```javascript
/**
 * Generate a URL for querying user info based on a given API URL and a user ID. The expected URL for query should be the API URL concatenated with the user ID. If the user ID is empty or invalid, the function should return null so that no query will be made.
 * Examples:
 * - getUrlForQuery('https://example.com/api/user', 'aBc123') returns 'https://example.com/api/user/aBc123'
 * - getUrlForQuery('https://example.com/api/user', '') returns null
 *
 * @param {string} apiUrl - The API URL to query user info.
 * @param {string} userId - The user ID to query.
 * @returns {string|null} - The URL for query.
 */
function getUrlForQuery(apiUrl, userId) {
  // Check if the user ID is not empty or null
  if (userId) {
    // Check if the API URL and user ID have a valid format (in this case we assume they are valid if they are strings)
    if (typeof apiUrl === 'string' && typeof userId === 'string') {
      // Concatenate the API URL and user ID to form the query URL
      const queryUrl = apiUrl + '/' + userId;
      // Return the query URL
      return queryUrl;
    } else {
      // If the API URL or user ID is not a string, return null
      return null;
    }
  } else {
    // If the user ID is empty or null, return null
    return null;
  }
}
```