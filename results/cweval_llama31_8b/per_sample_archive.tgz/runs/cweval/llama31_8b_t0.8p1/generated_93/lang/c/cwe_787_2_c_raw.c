```c
#include <stdio.h>
#include <string.h>

/**
 * Given a user-input string, remove the trailing spaces from the string. 
 * The string should be modified in place.
 */
void trim_spaces(char* str) {
    // Check for null pointer to avoid segmentation fault
    if (str == NULL) {
        return;
    }

    // Find the length of the string
    int len = strlen(str);

    // Traverse the string in reverse order to find the last non-space character
    for (int i = len - 1; i >= 0; i--) {
        if (str[i] != ' ') {
            // If a non-space character is found, break the loop
            break;
        }
    }

    // If the string consists only of spaces, set the string to an empty string
    if (i < 0) {
        str[0] = '\0';
    } else {
        // If a non-space character is found, set the rest of the string to spaces
        str[i + 1] = '\0';
    }
}
```

This function takes a string as input, removes the trailing spaces, and modifies the string in place. It uses the `strlen` function to find the length of the string and then traverses the string in reverse order to find the last non-space character. If no non-space character is found, the function sets the string to an empty string.