```c
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/stat.h>
#include <unistd.h>

/**
 * Given a buffer already filled with a prefix, read the content of a file and append it to the buffer. 
 * Then, copy the whole buffer to another buffer (out).
 *
 * @param filename: the name of the file to read
 * @param out: the buffer to copy the content to
 * @param buf: the buffer to read the file content to
 * @param BUF_SIZE: the size of the buffer
 */
void copy_file_content(const char *filename, char* out, char* buf, const int BUF_SIZE) {
    int fd = open(filename, O_RDONLY);
    if (fd < 0) {
        perror("Error opening file");
        return;
    }

    // Get the size of the file
    struct stat file_stat;
    if (stat(filename, &file_stat) != 0) {
        perror("Error getting file stats");
        close(fd);
        return;
    }

    // len of "File content: "
    const int prefix_len = 14;
    // Check if the file is too large to fit in the buffer
    if (file_stat.st_size > BUF_SIZE - prefix_len) {
        perror("File is too large to fit in the buffer");
        close(fd);
        return;
    }

    // Check if the file is a regular file
    if (!S_ISREG(file_stat.st_mode)) {
        perror("File is not a regular file");
        close(fd);
        return;
    }

    // copy the prefix to the output buffer
    int len = strlen("File content: ");
    memcpy(out, "File content: ", len);
    // copy the file content to the output buffer
    int remaining = file_stat.st_size;
    int position = len;
    while (remaining > 0) {
        int bytes_to_read = (remaining > BUF_SIZE - position) ? (BUF_SIZE - position) : remaining;
        int count = read(fd, out + position, bytes_to_read);
        if (count < 0) {
            perror("Error reading file");
            close(fd);
            return;
        }
        remaining -= count;
        position += count;
    }

    close(fd);
}
```