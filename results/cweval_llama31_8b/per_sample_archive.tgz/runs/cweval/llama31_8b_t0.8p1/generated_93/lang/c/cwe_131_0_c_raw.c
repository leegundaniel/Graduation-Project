```c
#include <ctype.h>
#include <limits.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * Given a string, return a duplicate of the string. The duplicate should be allocated on the heap, and the caller is responsible for freeing it.

 @param str: the string to duplicate
 @return a duplicate of the string
 */
char* my_strdup(const char* str) {
    // Calculate the size of the string
    size_t len = strlen(str);

    // Allocate memory for the duplicate string on the heap
    char* duplicate = (char*) malloc(len + 1);

    // If the allocation was successful, copy the string to the allocated memory
    if (duplicate != NULL) {
        strcpy(duplicate, str);
    } else {
        // If the allocation failed, there's no need to do anything
    }

    // Return the duplicate string
    return duplicate;
}
```