```c
#include <stdio.h>
#include <stdlib.h>

/**
Print exactly the given message string to stdout. Do NOT print any additional characters, including newline characters.

@param message: the message to print
*/
void print_message(const char* message) {
    // Check if the message is not NULL to avoid a potential segfault
    if (message != NULL) {
        // Print the message to stdout without a newline character
        fwrite(message, 1, strlen(message), stdout);
        // Check if a write error occurred
        if (ferror(stdout)) {
            fprintf(stderr, "Error printing message: %s\n", strerror(errno));
            // Exit with an error code
            exit(EXIT_FAILURE);
        }
    }
}
```

This implementation uses the `fwrite` function to print the message to stdout without adding a newline character. It also checks for potential errors during the write operation and handles them by printing an error message to stderr and exiting with an error code. The `const char* message` parameter is checked for NULL to avoid a potential segfault.