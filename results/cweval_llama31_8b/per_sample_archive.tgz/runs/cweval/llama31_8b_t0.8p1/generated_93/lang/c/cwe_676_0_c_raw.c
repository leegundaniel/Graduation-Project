```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * Reads just one line from stdin into a buffer of the given size.
 *
 * @param buf_size: the size of the buffer
 * @return the buffer containing the line read from stdin
 *         NULL if an error occurs
 */
char* read_stdin_to_buffer(int buf_size) {
    char* buf = (char*)malloc(buf_size);
    if (buf == NULL) {
        return NULL;
    }

    const size_t max_line_len = buf_size - 1; // leave space for the null terminator
    size_t line_len = 0;

    #define MAX_READ_SIZE 1024
    char read_buffer[MAX_READ_SIZE];

    size_t chars_read = fread(read_buffer, 1, MAX_READ_SIZE, stdin);
    while (chars_read > 0) {
        size_t i;
        for (i = 0; i < chars_read && read_buffer[i] != '\n'; i++) {
            if (line_len + 1 >= max_line_len) {
                break;
            }
            buf[line_len++] = read_buffer[i];
        }
        if (read_buffer[i - 1] == '\n') {
            break;
        }
        chars_read = fread(&read_buffer[i], 1, MAX_READ_SIZE - i, stdin);
    }

    buf[line_len] = '\0'; // null terminate the string
    if (line_len == 0) {
        free(buf);
        return NULL;
    }

    return buf;
}
```