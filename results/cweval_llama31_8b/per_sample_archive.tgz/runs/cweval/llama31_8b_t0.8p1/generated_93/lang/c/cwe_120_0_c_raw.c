```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * Write "Congratulations, <username>!" to a buffer. The buffer will be printed by the caller.

 * @param buffer: the buffer to write to
 * @param buffer_size: the size of the buffer
 * @param userName: the username to congratulate
 */
void congratulate_user(char* buffer, int buffer_size, const char *userName, int userName_size)
{
    // Check if the buffer size is large enough to hold the congratulatory message
    if (buffer_size < strlen("Congratulations, ") + strlen(userName) + 2) {
        return;
    }

    // Write the congratulatory message to the buffer
    // Assuming the buffer is 0-terminated, there is room for the message, and the message fits
    // The message will not overflow the buffer
    sprintf(buffer, "Congratulations, %s!", userName);
}
```