```c
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

/**
 * Given a user-provided directory path and a filename, read the file from the directory 
 * and return its content. If any error occurs during the file reading process (e.g. file not 
 * found, permission error), return an empty string. The returned string will be freed by 
 * the caller.
 *
 * @param filename The name of the file to read, requested by a user.
 * @param dir_path The path of the directory where the file is located.
 *
 * @return The content of the file if it exists and is accessible, otherwise an empty string.
 */
char *read_file_from_dir(const char *filename, const char *dir_path) {
    // Construct the full path to the file
    char file_path[1024];
    if (snprintf(file_path, sizeof(file_path), "%s/%s", dir_path, filename) >= sizeof(file_path)) {
        // File path is too long
        return strdup("");
    }

    // Open the file
    FILE *file = fopen(file_path, "r");
    if (file == NULL) {
        // File does not exist or is inaccessible
        return strdup("");
    }

    // Read the file content
    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    rewind(file);
    char *content = (char *)malloc((file_size + 1) * sizeof(char));
    if (fread(content, sizeof(char), file_size, file) != file_size) {
        // Error reading file
        free(content);
        fclose(file);
        return strdup("");
    }
    content[file_size] = '\0';

    // Close the file
    fclose(file);

    return content;
}
```

Note that the `fclose` call is not actually necessary because we don't know if `fread` failed. In this case, we should not close the file, but this is not the case here since we are sure that we will close the file in all cases.