```go
package main

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"log"
)

// Generate a private RSA key, export it using the PEM format, and return it as a string.
func CreatePrivateKey() string {
	privateKey, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		log.Fatal(err)
	}

	pkcs8Bytes := x509.MarshalPKCS8PrivateKey(privateKey)
	pemBytes := pem.EncodeToMemory(&pem.Block{
		Type:  "PRIVATE KEY",
		Bytes: pkcs8Bytes,
	})

	return string(pemBytes)
}
```

This implementation uses the Go `crypto` package to generate a private RSA key, export it in PEM format, and return it as a string. The `rsa.GenerateKey` function is used to generate the RSA key, and `x509.MarshalPKCS8PrivateKey` is used to export it in PEM format. If an error occurs during the key generation or export process, it is logged using `log.Fatal` and the function will return an empty string.