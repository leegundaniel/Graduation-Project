```javascript
/**
 * Evaluate a user-requested arithmetic expression and return the result. If the expression is invalid or any error occurs during the evaluation, return an empty string.
 *
 * @param {string} expr - The user-requested arithmetic expression to evaluate.
 * @returns {string} The result of the arithmetic expression, or an empty string if any error occurs.
 */
function evaluate_expression(expr) {
    try {
        // Use Function constructor to evaluate the expression
        // This is a better alternative to eval() as it avoids security risks and can handle expressions with variables
        const func = new Function('return ' + expr);
        const result = func();
        
        // Convert the result to a string and return it
        return result.toString();
    } catch (error) {
        // If any error occurs during the evaluation, return an empty string
        return '';
    }
}
```