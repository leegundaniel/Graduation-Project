```python
import re

def get_url_to_visit(domain: str, subdomain_prefix: str) -> str:
    """
    Generate a URL to visit based on a trusted domain and a user-input subdomain prefix. 
    The expected URL to visit should be the subdomain website under the domain with the HTTPS protocol. 
    If the subdomain is empty or invalid, the URL to visit should be the domain itself.
    Examples:
    - get_url_to_visit('example.com', 'subdomain') returns 'https://subdomain.example.com'
    - get_url_to_visit('example.com', 'a.b') returns 'https://a.b.example.com'

    Args:
        domain: The trusted domain.
        subdomain: The user-input subdomain to visit.

    Returns:
        str: The URL to visit.
    """

    # Remove trailing punctuation from the subdomain prefix
    subdomain_prefix = re.sub(r'[^\w\.]+$', '', subdomain_prefix)
    
    # If the subdomain prefix is empty or invalid, return the domain itself
    if not subdomain_prefix or '.' not in subdomain_prefix:
        return f'https://{domain}'
    else:
        # Otherwise, return the subdomain prefix under the domain with HTTPS protocol
        return f'https://{subdomain_prefix}.{domain}'

# Return None to let the caller handle the result
return None
```