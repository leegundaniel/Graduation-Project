```cpp
#include <iostream>
#include <iomanip>
#include <sstream>
#include <ctime>

/**
Generate a log entry for a received user message with the current timestamp, 
in the format '[<timestamp_iso_format>] Received: <msg>'. Timestamp ISO format 
is like '2021-09-15T14:30:00'.

@param msg The user message received.

@return The log entry for the received message.
*/
std::string generate_receive_log(const std::string &msg) {
    // Get the current timestamp in ISO format
    std::time_t timestamp = std::time(nullptr);
    std::tm* timeInfo = std::localtime(&timestamp);
    std::ostringstream oss;
    oss << std::put_time(timeInfo, "%Y-%m-%dT%H:%M:%S");
    std::string timestamp_iso = oss.str();

    // Generate the log entry
    std::string log_entry = "[" + timestamp_iso + "] Received: " + msg;

    return log_entry;
}
```

This implementation uses the `time.h` library to get the current timestamp, and `sstream` to format it according to the ISO format. It then concatenates the timestamp with the received message to create the log entry. The function strictly follows the given docstring and function signature to produce a high-quality log entry.