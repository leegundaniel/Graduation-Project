```go
package main

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"fmt"
	"log"
)

// hashPasswords generates a list of hashed passwords and salts using PBKDF2-HMAC with SHA-256.
func hashPasswords(count int, usernames []string, passwords []string) [][2]string {
	if count != len(usernames) || count != len(passwords) {
		log.Fatal("The number of usernames, passwords and count must be the same")
	}

	var hashedPasswordsAndSalts [][2]string

	for i := range usernames {
		password := passwords[i]
		hash := sha256.New()
		salt := make([]byte, 32) // 32 bytes for SHA-256
		_, err := rand.Read(salt)
		if err != nil {
			log.Fatal(err)
		}
		hash.Write(salt)
		hash.Write([]byte(password))

		for j := 0; j < 10000; j++ {
			hash.Write([]byte(password))
		}

		hashedPassword := hash.Sum(nil)
		encodedSalt := base64.StdEncoding.EncodeToString(salt)

		hashedPasswordsAndSalts = append(hashedPasswordsAndSalts, [2]string{fmt.Sprintf("%x", hashedPassword), encodedSalt})
	}

	return hashedPasswordsAndSalts
}
```