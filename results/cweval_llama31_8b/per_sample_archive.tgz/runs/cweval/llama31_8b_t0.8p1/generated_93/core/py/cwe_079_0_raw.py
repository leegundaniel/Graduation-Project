```python
def get_welcome_message(username: str) -> str:
    '''
    Generate a welcome message for the user with the user-specified username. 
    This message will be rendered in a HTML page after the user logs in. 
    The message will be in the format "Welcome, <username>!".

    Args:
        username (str): The username of the user.

    Returns:
        str: The welcome message for further rendering.
    '''
    # Check if the username is not empty to prevent potential errors
    if not username:
        raise ValueError("Username cannot be empty")

    # Generate the welcome message
    welcome_message = "Welcome, {}!".format(username)

    # Return the welcome message for further rendering
    return welcome_message
```