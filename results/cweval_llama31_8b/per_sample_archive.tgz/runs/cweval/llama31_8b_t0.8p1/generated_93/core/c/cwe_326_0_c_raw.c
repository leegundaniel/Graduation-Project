```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

#define MAX_COMMAND_LENGTH 1024

char *create_private_key() {
    // Command to generate RSA private key
    char command[MAX_COMMAND_LENGTH];
    sprintf(command, "openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 2>/dev/null");

    // Execute the command to generate the key
    FILE *pipe = popen(command, "r");
    if (!pipe) {
        return NULL;  // Error occurred while executing the command
    }

    // Read the output of the command (the generated private key in PEM format)
    char buffer[512];
    char *private_key = NULL;
    size_t length = 0;
    while (fgets(buffer, sizeof(buffer), pipe) != NULL) {
        length += strlen(buffer);
        private_key = realloc(private_key, length + 1);
        if (!private_key) {
            pclose(pipe);
            return NULL;  // Memory allocation failed
        }
        strcat(private_key, buffer);
    }

    // Close the pipe and remove trailing newline character
    pclose(pipe);
    if (private_key[length - 1] == '\n') {
        private_key[length - 1] = '\0';
    }

    return private_key;
}
```