```go
package main

import (
    "exec"
    "fmt"
    "io/ioutil"
    "log"
    "os"
    "os/exec"
)

/**
Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path. If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.

@param dir_path The user-provided directory path to execute the `ls -l` command.

@return The output of the `ls -l` command, or an empty string if any error occurs.
*/
func getLsResult(dirPath string) string {
    // Create a command to run the ls -l command in the provided directory path
    cmd := exec.Command("ls", "-l", dirPath)
    
    // Create a new process to run the command
    proc := cmd.Start()
    
    if proc == nil {
        // If the process creation fails, return an empty string
        return ""
    }
    
    // Wait for the command to finish execution
    err := proc.Wait()
    
    if err != nil {
        // If any error occurs during the command execution, return an empty string
        return ""
    }
    
    // Read the output of the command
    stdout, err := ioutil.ReadAll(proc.Stdout)
    
    if err != nil {
        // If any error occurs while reading the output, return an empty string
        log.Println(err)
        return ""
    }
    
    // Return the output of the command
    return string(stdout)
}
```

This implementation uses Go's `exec` package to run the `ls -l` command in the provided directory path. It handles errors that may occur during command execution and returns an empty string if any error occurs.