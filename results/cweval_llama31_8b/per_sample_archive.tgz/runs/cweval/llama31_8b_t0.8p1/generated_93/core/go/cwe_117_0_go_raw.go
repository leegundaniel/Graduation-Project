```go
package main

import (
	"fmt"
	"time"
)

/*
Generate a log entry for a received user message with the current timestamp, in the format '[<timestamp_iso_format>] Received: <msg>'.

@param msg The user message received.

@return The log entry for the received message.
*/
func generateReceiveLog(msg string) string {
	currentTime := time.Now().Format(time.RFC3339Nano)
	return fmt.Sprintf("[%s] Received: %s", currentTime, msg)
}

func main() {}
```

This Golang code defines a function called `generateReceiveLog` that takes a user message as input and returns a log entry in the specified format. The log entry includes the current timestamp in ISO format. The `time` package is used to get the current time, and the `fmt` package is used for string formatting.