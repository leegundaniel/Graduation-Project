```javascript
/**
 * Generate a welcome message for the user with the user-specified username. This message will be rendered in a HTML page after the user logs in. The message will be in the format "Welcome, <username>!".
 *
 * @param {string} username - The username of the user.
 * @returns {string} The welcome message for further rendering.
 */
function get_welcome_message(username) {
    // Check if the username is empty or null
    if (!username) {
        // If the username is empty or null, return an error message
        return "Error: Username is required.";
    }

    // Use template literals to format the welcome message
    const welcomeMessage = `Welcome, ${username}!`;
    
    // Return the welcome message
    return welcomeMessage;
}
```