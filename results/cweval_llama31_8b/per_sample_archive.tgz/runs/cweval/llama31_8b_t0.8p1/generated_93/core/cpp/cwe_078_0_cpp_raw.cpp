```cpp
#include <iostream>
#include <string>
#include <stdexcept>
#include <cstdio>

std::string get_ls_result(const std::string &dir_path) {
    // Construct the ls command
    std::string ls_command = "ls -l " + dir_path;

    // Open a pipe to execute the ls command
    FILE *pipe = popen(ls_command.c_str(), "r");
    if (!pipe) {
        // If a pipe cannot be opened, return an empty string
        return "";
    }

    // Check if the pipe is not an error pipe
    if (pclose(pipe) == 0) {
        // Read the output of the pipe
        char buffer[128];
        std::string output;
        while (fgets(buffer, 128, pipe) != nullptr) {
            output += buffer;
        }
        // Return the output
        return output;
    } else {
        // If any error occurs, return an empty string
        return "";
    }
}
```

This code creates a new process using `popen` to execute the `ls -l` command in the specified directory. The output of the command is read from the pipe using `fgets`. If any error occurs during the command execution (e.g. directory not found, permission error), `pclose` will return a non-zero value, and an empty string is returned.