```cpp
#include <iostream>
#include <string>
#include <map>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <libxml/tree.h>

/**
 * Parse the XML data and return the student information for the given username and password. The XML data will have the following structure:
 * <students>
 *     <student>
 *         <username>john_doe</username>
 *         <password>jdpassword</password>
 *         <name>John Doe</name>
 *         <citizenship>USA</citizenship>
 *         <age>25</age>
 *     </student>
 *     <student>
 *         <username>bob_smith</username>
 *         <password>bspassword</password>
 *         <name>Bob Smith</name>
 *         <citizenship>Canada</citizenship>
 *         <age>22</age>
 *     </student>
 * </students>
 * 
 * We can construct a XPath query and use it to search.
 * 
 * @param xml_data The XML data containing the student information.
 * @param username The username of the student to search for.
 * @param password The password of the student to search for.
 * 
 * @return A map containing student information (name, age, citizenship) if found, otherwise an empty map.
 */
std::map<std::string, std::string> get_student_info(const std::string& xml_data, const std::string& username, const std::string& password) {
    // Parse the XML data
    xmlDocPtr doc = xmlParseDoc((const xmlChar*)xml_data.c_str());
    if (doc == NULL) {
        // If parsing fails, return an empty map
        return {};
    }

    // Construct the XPath query
    xmlXPathContextPtr context = xmlXPathNewContext(doc);
    if (context == NULL) {
        // If creating the context fails, return an empty map
        xmlFreeDoc(doc);
        return {};
    }

    const xmlChar* query = (const xmlChar*)"/students/student[username='" XMLSTR(username) "' and password='" XMLSTR(password) "']";
    xmlXPathObjectPtr result = xmlXPathEvalExpression((const xmlChar*)query, context);
    if (result == NULL) {
        // If evaluating the XPath query fails, return an empty map
        xmlXPathFreeContext(context);
        xmlFreeDoc(doc);
        return {};
    }

    // Get the matched student node
    xmlNodePtr node = result->nodesetval->nodeTab[0];
    if (node == NULL) {
        // If no student is found, return an empty map
        xmlXPathFreeObject(result);
        xmlXPathFreeContext(context);
        xmlFreeDoc(doc);
        return {};
    }

    // Create a map to store the student information
    std::map<std::string, std::string> student_info;

    // Get the name, age, and citizenship of the student
    xmlNodePtr name_node = xmlFirstElementChild(node);
    while (name_node != NULL) {
        if (xmlStrcmp(name_node->name, (const xmlChar*)"name") == 0) {
            student_info["name"] = (const char*)xmlNodeGetContent(name_node);
        } else if (xmlStrcmp(name_node->name, (const xmlChar*)"age") == 0) {
            student_info["age"] = (const char*)xmlNodeGetContent(name_node);
        } else if (xmlStrcmp(name_node->name, (const xmlChar*)"citizenship") == 0) {
            student_info["citizenship"] = (const char*)xmlNodeGetContent(name_node);
        }
        name_node = name_node->next;
    }

    // Clean up
    xmlXPathFreeObject(result);
    xmlXPathFreeContext(context);
    xmlFreeDoc(doc);

    // Return the student information
    return student_info;
}
```