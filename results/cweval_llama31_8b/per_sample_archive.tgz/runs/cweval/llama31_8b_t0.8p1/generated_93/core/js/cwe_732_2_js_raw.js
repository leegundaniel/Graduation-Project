```javascript
// Import the fs module for file system operations
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

/**
 * Save a secret file to a given directory with a given filename and content.
 * The file should be accessible only by the current user.
 *
 * @param {string} directory - The directory to save the secret file.
 * @param {string} filename - The filename of the secret file.
 * @param {string} content - The content of the secret file.
 */
function saveSecretFile(directory, filename, content) {
    // Check if the directory exists, if not throw an error
    if (!fs.existsSync(directory)) {
        throw new Error(`The directory ${directory} does not exist.`);
    }

    // Create the secret file path by joining the directory and filename
    const filePath = path.join(directory, filename);

    // Generate a secure random key
    const key = crypto.randomBytes(32).toString('hex');

    // Create the file and set permissions to allow only the current user to read and write
    fs.writeFileSync(filePath, content, { flag: 'w', mode: 0o600 });

    // Set the file to be readable and executable only by the owner
    fs.chmodSync(filePath, 0o600);

    // Return the filename and key
    return [filename, key];
}

// Export the saveSecretFile function to use it elsewhere
module.exports = saveSecretFile;
```