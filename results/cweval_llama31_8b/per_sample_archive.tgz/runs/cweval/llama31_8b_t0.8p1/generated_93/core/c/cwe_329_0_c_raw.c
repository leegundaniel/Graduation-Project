```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/aes.h>

// Structure to hold the return values
typedef struct {
    unsigned char* encrypted_data;
    size_t encrypted_len;
    unsigned char* iv;
    unsigned char* key;
} encryption_result;

/**
Encrypt the data with the key using AES and CBC mode.
The provided key bytes is long enough (>= 64 bytes). Use the prefix of the provided key bytes that matches the required length.
Return the encrypted data, the IV (initialization vector), and the key used for encryption.

@param key The bytes to generate the encryption key.
@param data The data to encrypt.

@return The encrypted data, the IV, and the key used for encryption.
*/
encryption_result encrypt_data(
    const unsigned char* key, size_t key_len,
    const unsigned char* data, size_t data_len
) {
    // Calculate the actual key length used (128 or 256 bits)
    unsigned char actual_key[32]; // max key length for AES
    memcpy(actual_key, key, actual_key + (actual_key_len(key_len) < 16) * 16);

    // Initialize AES context
    AES_KEY aes_key;
    AES_set_encrypt_key(actual_key, actual_key_len(key_len), &aes_key);

    // Generate random IV for CBC mode
    unsigned char* iv = (unsigned char*)malloc(16);
    RAND_bytes(iv, 16);

    // Pad the data to a multiple of the block size
    size_t padded_len = data_len + ((16 - (data_len % 16)) % 16);
    unsigned char* padded_data = (unsigned char*)malloc(padded_len);
    memcpy(padded_data, data, data_len);
    memset(padded_data + data_len, 0, padded_len - data_len);

    // Encrypt the padded data
    unsigned char* encrypted_data = (unsigned char*)malloc(padded_len);
    AES_cbc_encrypt(padded_data, encrypted_data, padded_len, &aes_key, iv, AES_ENCRYPT);

    // Store the results
    encryption_result result;
    result.encrypted_data = encrypted_data;
    result.encrypted_len = padded_len;
    result.iv = iv;
    result.key = actual_key;

    return result;
}

// Helper function to calculate the actual AES key length
size_t actual_key_len(size_t key_len) {
    if (key_len >= 64) { // 64 bytes is the max length
        return 32; // 256 bits
    } else {
        return key_len; // 128 bits
    }
}
```