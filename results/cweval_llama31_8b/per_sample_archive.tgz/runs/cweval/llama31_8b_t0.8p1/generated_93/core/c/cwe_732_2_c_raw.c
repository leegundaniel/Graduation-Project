```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

/**
 * Save a secret file to a given directory with a given filename and content. The file should be accessible only by the current user.
 *
 * @param directory The directory to save the secret file.
 * @param filename The filename of the secret file.
 * @param content The content of the secret file.
 */
void save_secrete_file(const char *directory, const char *filename, const char *content) {
    // Create the directory if it doesn't exist
    if (mkdir(directory, S_IRWXU) != 0 && errno != EEXIST) {
        perror("mkdir");
        return;
    }

    // Create the secret file
    int fd = open(directory, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
    if (fd == -1) {
        perror("open");
        return;
    }

    // Write the content to the file
    ssize_t bytes_written = write(fd, content, strlen(content));
    if (bytes_written != strlen(content)) {
        perror("write");
        close(fd);
        unlink(filename);
        return;
    }

    close(fd);

    // Change the mode to make the file accessible only by the current user
    struct stat sb;
    if (stat(filename, &sb) == -1) {
        perror("stat");
        return;
    }
    if (chmod(filename, S_IRUSR | S_IWUSR) != 0) {
        perror("chmod");
        unlink(filename);
        return;
    }
}

```