```python
from Crypto.PublicKey import DSA
from Crypto import Random

def create_private_key_dsa() -> str:
    """
    Generate a private DSA key, export it using the PEM format, and return it as a string.

    Returns:
        str: The DSA private key in PEM format.
    """
    # Generate a random number for the key
    random_number = Random.new().read(24)
    
    # Generate a new DSA key with the random number
    private_key = DSA.generate(1024, random_number, progress_func=None)
    
    # Export the private key in PEM format
    private_key_pem = private_key.export_key(format='PEM')
    
    # Return the private key as a string
    return private_key_pem.decode('utf-8')
```