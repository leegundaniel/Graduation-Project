```go
package main

import (
	"encoding/xml"
	"fmt"
	"github.com/ChrisTrenkamp/goxpath"
	"github.com/ChrisTrenkamp/goxpath/tree"
	"github.com/ChrisTrenkamp/goxpath/tree/xmltree"
)

// Represents the student information in the XML data.
type Student struct {
	XMLName xml.Name `xml:"student"`
	Username string `xml:"username"`
	Password string `xml:"password"`
	Name string `xml:"name"`
	Citizenship string `xml:"citizenship"`
	Age string `xml:"age"`
}

func getStudentInfo(xmlData, username, password string) (string, string, string) {
	// Parse the XML data into a goxpath tree.
	tree := xmltree.New(xmlData)

	// Construct the XPath query to search for the student with the given username and password.
	query := "//student[@username='" + username + "' and @password='" + password + "']"

	// Execute the XPath query on the tree.
 nodes, err := tree.Select(query)

	// Handle any errors that occurred during query execution.
	if err != nil {
		fmt.Println("Error executing XPath query:", err)
		return "", "", ""
	}

	// Get the first matching node, if any.
	node := nodes[0]

	// Check if a node was found.
	if node != nil {
		// Unmarshal the node into a Student struct.
		var student Student
		err := node.Unmarshal(&student)
		if err != nil {
			fmt.Println("Error unmarshaling node to Student struct:", err)
			return "", "", ""
		}

		// Return the student information as a tuple.
		return student.Name, student.Age, student.Citizenship
	}

	// If no node was found, return empty strings.
	return "", "", ""
}
```