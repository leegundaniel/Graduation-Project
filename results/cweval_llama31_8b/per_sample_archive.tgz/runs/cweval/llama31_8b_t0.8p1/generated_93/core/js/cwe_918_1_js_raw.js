```javascript
/**
 * Generate a URL for querying user info based on a given API URL and a user ID. 
 * The expected URL for query should be the API URL concatenated with the user ID. 
 * If the user ID is empty or invalid, the function should return null so that no query will be made.
 * Examples:
 * - getUrlForQuery('https://example.com/api/user', 'aBc123') returns 'https://example.com/api/user/aBc123'
 * - getUrlForQuery('https://example.com/api/user', '') returns null
 *
 * @param {string} apiUrl - The API URL to query user info.
 * @param {string} userId - The user ID to query.
 * @returns {string|null} - The URL for query.
 */
function getUrlForQuery(apiUrl, userId) {
    // Check if the API URL and user ID are valid strings
    if (typeof apiUrl !== 'string' || typeof userId !== 'string') {
        // If either is invalid, return null
        return null;
    }

    // Check if the user ID is empty
    if (userId.trim() === '') {
        // If the user ID is empty, return null
        return null;
    }

    // Concatenate the API URL and user ID
    const urlForQuery = `${apiUrl}/${userId}`;

    // Return the URL for query
    return urlForQuery;
}
```

This function first checks if the API URL and user ID are valid strings. If either is invalid, it returns null. Then it checks if the user ID is empty. If it is, the function also returns null. If both checks pass, it concatenates the API URL and user ID and returns the resulting URL.