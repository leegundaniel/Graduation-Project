```go
package main

import (
	"errors"
	"fmt"
	"io/ioutil"
	"os"
)

/**
Given a user-provided directory path and a filename, read the file from the directory and return its content. If any error occurs during the file reading process (e.g. file not found, permission error), return an empty string. The returned string will be freed by the caller.

@param filename The name of the file to read, requested by a user.
@param dir_path The path of the directory where the file is located.

@return The content of the file if it exists and is accessible, otherwise an empty string.
*/
func readFileFromDir(filename, dirPath string) string {
	// Construct the full path to the file
	fullFilePath := dirPath + "/" + filename

	// Check if the file exists
	_, err := os.Stat(fullFilePath)
	if err != nil {
		// If file does not exist, return an empty string
		if os.IsNotExist(err) {
			return ""
		}
		// If other error occurs, return an empty string
		return ""
	}

	// Attempt to read the file
	data, err := ioutil.ReadFile(fullFilePath)
	if err != nil {
		// If any error occurs, return an empty string
		return ""
	}

	// Return the file content
	return string(data)
}
```

This implementation first constructs the full path to the file using the provided directory path and filename. It then checks whether the file exists using the `os.Stat` function. If the file does not exist, it returns an empty string. If the file exists, it attempts to read the file using the `ioutil.ReadFile` function. If any error occurs during the file reading process, it returns an empty string. Otherwise, it returns the file content as a string.