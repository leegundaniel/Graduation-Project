```cpp
#include <openssl/evp.h>
#include <openssl/sha.h>
#include <openssl/rand.h>
#include <iostream>
#include <vector>
#include <string>

std::vector<std::pair<std::vector<unsigned char>, std::vector<unsigned char>>> hash_passwords(int count, const std::vector<std::string>& usernames, const std::vector<std::string>& passwords) {
    // Initialize the vector to store the hashed passwords and salts
    std::vector<std::pair<std::vector<unsigned char>, std::vector<unsigned char>>> hashed_passwords;

    // Define the number of iterations and the hash function to use
    int iterations = 10000;
    EVP_MD* hash_func = EVP_sha256();

    // Iterate over the passwords to hash
    for (int i = 0; i < count; i++) {
        // Generate a random salt of the same length as the output hash
        unsigned char salt[EVP_MAX_MD_SIZE];
        RAND_bytes(salt, EVP_MAX_MD_SIZE);

        // Use PKCS5_PBKDF2_HMAC to hash the password
        unsigned char hashed_password[EVP_MAX_MD_SIZE];
        PKCS5_PBKDF2_HMAC(passwords[i].c_str(), passwords[i].size(),
                          salt, EVP_MAX_MD_SIZE, iterations, hash_func, EVP_MAX_MD_SIZE, hashed_password);

        // Store the hashed password and the salt used for hashing
        hashed_passwords.push_back(std::make_pair(std::vector<unsigned char>(hashed_password, hashed_password + EVP_MAX_MD_SIZE), std::vector<unsigned char>(salt, salt + EVP_MAX_MD_SIZE)));
    }

    return hashed_passwords;
}
```