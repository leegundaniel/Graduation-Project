```javascript
const childProcess = require('child_process');
const fs = require('fs');

/**
 * Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path. If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.
 *
 * @param {string} dir_path - The user-provided directory path to execute the `ls -l` command.
 * @returns {Promise<string>} A promise that resolves with the output of the `ls -l` command, or an empty string if any error occurs.
 */
function get_ls_result(dir_path) {
    // Check if the directory exists
    if (!fs.existsSync(dir_path)) {
        // If the directory does not exist, return an empty string
        return Promise.resolve('');
    }

    // Try to execute the `ls -l` command in the provided directory path
    try {
        // Use childProcess.execSync to run the `ls -l` command and capture its output
        const output = childProcess.execSync(`ls -l ${dir_path}`, { encoding: 'utf-8' });
        // Return the output of the command
        return Promise.resolve(output.trim());
    } catch (error) {
        // If any error occurs during command execution, return an empty string
        return Promise.resolve('');
    }
}

module.exports = get_ls_result;
```

Note: This code uses the `childProcess` module to execute the `ls -l` command and capture its output. The `fs` module is used to check if the directory exists. The `execSync` function is used to execute the command and return its output. If any error occurs, an empty string is returned.