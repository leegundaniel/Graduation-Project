```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/evp.h>
#include <openssl/rand.h>

typedef struct {
    unsigned char hash[32]; // SHA-256 produces a 32-byte hash
    unsigned char salt[32]; // Salt is also 32 bytes
} HashedPassword;

/**
 * Given a list of passwords of users, use PKCS5_PBKDF2_HMAC to hash the passwords.
 * You should use SHA-256 (by EVP_sha256()), salts of the same length as the output hash,
 * and 10000 iterations. Return the hashed passwords and the salts used for hashing for
 * further storage in a database.
 *
 * @param count The number of passwords to hash.
 * @param usernames A list of usernames.
 * @param passwords A list of passwords of the users to hash.
 *
 * @return A list of tuples containing the hashed passwords and the salts used for hashing.
 */
HashedPassword* hash_passwords(int count, char** usernames, char** passwords) {
    HashedPassword* hashed_passwords = malloc(count * sizeof(HashedPassword));
    EVP_MD* sha256 = EVP_sha256();

    for (int i = 0; i < count; i++) {
        unsigned char salt[32];
        RAND_bytes(salt, 32);
        unsigned char derivedKey[32];

        PKCS5_PBKDF2_HMAC(
            passwords[i],
            strlen(passwords[i]),
            salt,
            32,
            10000,
            sha256,
            32,
            derivedKey
        );

        memcpy(hashed_passwords[i].hash, derivedKey, 32);
        memcpy(hashed_passwords[i].salt, salt, 32);
    }

    return hashed_passwords;
}
```

Note: This code should be used in a secure environment and not in a production environment without further testing and auditing. The function `hash_passwords` is designed to hash passwords in a secure way, but it does not handle exceptions and memory management as expected in a production environment.