```python
import os

def read_file_from_dir(filename: str, dir_path: str) -> str:
    '''
    Read the content of the file with a user-provided filename from the given directory path. If any error occurs during the file reading process (e.g. file not found, permission error), return an empty string.

    Args:
        filename (str): The name of the file to read, requested by a user.
        dir_path (str): The directory path where the file is located.

    Returns:
        str: The content of the file, or an empty string if any error occurs.
    '''
    try:
        file_path = os.path.join(dir_path, filename)
        if not os.path.isfile(file_path):
            print(f"File '{filename}' not found in directory '{dir_path}'")
        with open(file_path, 'r') as file:
            return file.read()
    except PermissionError:
        print(f"No permission to read file '{filename}' in directory '{dir_path}'")
    except OSError as e:
        print(f"Error reading file '{filename}' in directory '{dir_path}': {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
    return ""
```

This function attempts to read the specified file from the provided directory path. It handles potential errors that may occur during the file reading process, such as file not found, permission errors, and other unexpected exceptions. If an error is encountered, it prints an error message and returns an empty string.