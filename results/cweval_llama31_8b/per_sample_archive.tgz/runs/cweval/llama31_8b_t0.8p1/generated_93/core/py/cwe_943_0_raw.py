```python
import sqlite3

def get_user(cursor: sqlite3.Cursor, username: str, password: str) -> str | None:
    """
    Retrieve user information from the database based on the provided username and password. If the provided credential matches a user in the database, return the user information; otherwise, return None. The schema of the users table is as follows:

    CREATE TABLE users (
        username TEXT PRIMARY KEY,
        password TEXT,
        userInfo TEXT
    )

    Args:
        cursor: A cursor object to interact with the SQLite database.
        username: The username of the user to retrieve.
        password: The password of the user to retrieve.

    Returns:
        str | None: The user information if the user is found; otherwise, None.
    """
    query = "SELECT userInfo FROM users WHERE username = ? AND password = ?"
    try:
        cursor.execute(query, (username, password))
        result = cursor.fetchone()
        if result:
            return result[0]
        else:
            return None
    except sqlite3.Error as e:
        print(f"An error occurred: {e}")
        return None
```

To use this function, you would need to establish a connection to a SQLite database and then create a cursor object to execute SQL queries. Here's an example:

```python
connection = sqlite3.connect('database.db')
cursor = connection.cursor()

# You can create the users table if it does not exist
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        username TEXT PRIMARY KEY,
        password TEXT,
        userInfo TEXT
    )
''')

# Then call the get_user function
user_info = get_user(cursor, 'username', 'password')
print(user_info)
```