```python
from tempfile import NamedTemporaryFile, TemporaryFile, mktemp
import os

def write_results(results: str) -> str:
    """
    Create a temporary file, write the provided `results` to it, and return the file name for future reading.

    Args:
        results (str): The string content to write to the temporary file.

    Returns:
        str: The file name of the temporary file created.
    """
    
    # Create a new temporary file
    temp_file = NamedTemporaryFile(mode='w', delete=False)
    
    try:
        # Write the results to the temporary file
        temp_file.write(results)
        
        # Seek back to the beginning of the file
        temp_file.seek(0)
        
        # Get the file name of the temporary file
        file_name = temp_file.name
        
        # Return the file name of the temporary file
        return file_name
    
    finally:
        # Close the temporary file
        temp_file.close()
        
        # Remove the temporary file
        os.remove(temp_file.name)
```

This implementation of the function `write_results` follows the provided docstring and function signature. It creates a temporary file using the `NamedTemporaryFile` class from the `tempfile` module, writes the provided `results` to it, and returns the file name of the temporary file. The function also includes error handling and properly closes and removes the temporary file after use.