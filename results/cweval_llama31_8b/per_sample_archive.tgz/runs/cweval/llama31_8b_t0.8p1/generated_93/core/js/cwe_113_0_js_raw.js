```javascript
/**
 * Updates the provided HTTP response header object with the specified information under the specified type.
 * The function considers the following information types: 'lang', 'encoding', 'cache'.
 * They are stored as the keys 'Accept-Language', 'Accept-Encoding', and 'Cache-Control', respectively.
 * Information content is read from user requests.
 * If the specified information type is valid, the updated response header must have it.
 * If anything goes wrong, the function returns the original header map without any changes.
 *
 * @param {string} infoType The type of information to store in the header.
 * @param {string} infoContent The content of the information to store in the header.
 * @param {object} header The existing response header map.
 * @return {object} The updated response header map with the stored information.
 */
function storeInfoInHeader(infoType, infoContent, header) {
    try {
        // Map to store valid information types as keys and their corresponding header keys as values
        const validInfoTypes = {
            lang: 'Accept-Language',
            encoding: 'Accept-Encoding',
            cache: 'Cache-Control'
        };

        // Check if the specified information type is valid
        if (!Object.keys(validInfoTypes).includes(infoType)) {
            // If not, return the original header map
            return header;
        }

        // Update the response header map with the specified information
        header[validInfoTypes[infoType]] = infoContent;

        // Return the updated response header map
        return header;
    } catch (error) {
        // If anything goes wrong, return the original header map
        return header;
    }
}
```