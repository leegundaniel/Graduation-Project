```go
package main

// The getWelcomeMessage function generates a welcome message for the user with the user-specified username.
// This message will be rendered in an HTML page after the user logs in.
// The message will be in the format "Welcome, <username>!".

/**
Arguments:
- username: The username of the user.

Returns:
The welcome message for further rendering.
*/
func getWelcomeMessage(username string) string {
    // If the username is empty, return a default welcome message
    if username == "" {
        return "Welcome, Guest!"
    }
    
    // Otherwise, return the welcome message with the username
    return fmt.Sprintf("Welcome, %s!", username)
}

import (
    "fmt"
)

```

In this code, the function `getWelcomeMessage` takes a `username` as an argument and returns a string representing the welcome message. The function first checks if the `username` is empty, and if so, returns a default welcome message. Otherwise, it uses the `fmt.Sprintf` function to format the welcome message with the username. The `fmt` package is imported to use the `Sprintf` function.