```go
package main

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"errors"
	"io"
)

/*
Encrypt the data with the key using AES and CBC mode.
The provided key bytes is long enough (>= 64 bytes). Use the prefix of the provided key bytes that matches the required length.
Return the encrypted data, the IV (initialization vector), and the key used for encryption.

Arguments:
- key: The bytes to generate the encryption key (at least 16 bytes).
- data: The data to encrypt.

Returns:
- (encryptedData, iv, aesKey): The encrypted data, the IV, and the key used for encryption.
*/
func encryptData(key []byte, data []byte) (encryptedData []byte, iv []byte, aesKey []byte) {
	// Calculate the size of the AES key
	aesKeySize := aes.BlockSize

	// Calculate the prefix of the key that matches the required length
	aesKey = key[:aesKeySize]

	// Generate a random IV
	iv = make([]byte, aes.BlockSize)
	_, err := io.ReadFull(rand.Reader, iv)
	if err != nil {
		panic(err)
	}

	// Create a new AES cipher
	block, err := aes.NewCipher(aesKey)
	if err != nil {
		panic(err)
	}

	// Create a CBC mode
	cipherText := make([]byte, aes.BlockSize+len(data))
	ivCopy := make([]byte, len(iv))
	copy(ivCopy, iv)
Modes := cipher.NewCBCEncrypter(block, ivCopy)

	// Encrypt the data
 Modes.CryptBlocks(cipherText[aes.BlockSize:], data)

	// Return the encrypted data, the IV, and the key used for encryption
	return cipherText, iv, aesKey
}
```