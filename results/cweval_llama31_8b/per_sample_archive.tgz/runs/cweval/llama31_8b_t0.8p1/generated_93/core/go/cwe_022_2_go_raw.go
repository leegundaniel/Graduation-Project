```go
package main

import (
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"tarExtract"
)

/**
Extract the content of the tar file to the given destination path.
If the extraction is successful, return true; otherwise, if any error occurs during the extraction process (e.g. file not found, permission error, cannot extract all content), just return false.

@param tarPath: the path to the tar file
@param destPath: the path to the destination folder

@return true if the extraction is successful; otherwise, false
*/
func extractTarToPath(tarPath string, destPath string) bool {
	// Check if the tar file exists
	if _, err := os.Stat(tarPath); err != nil {
		return false
	}

	// Check if the destination path exists, if not create it
	if _, err := os.Stat(destPath); err != nil {
		if err := os.MkdirAll(destPath, os.ModePerm); err != nil {
			log.Println(err)
			return false
		}
	}

	// Open the tar file
	var tarFile *os.File
	if tarFile, err := os.Open(tarPath); err != nil {
		log.Println(err)
		return false
	}
	defer tarFile.Close()

	// Create a new tar reader
	tarReader := tar.FileReader(tarFile)

	// Extract the tar file
	for {
		// Read the next header
		header, err := tarReader.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			log.Println(err)
			return false
		}

		// Check if the file already exists in the destination path
		if _, err := os.Stat(filepath.Join(destPath, header.Name)); err == nil {
			log.Printf("File %s already exists in destination path\n", header.Name)
			continue
		}

		// Extract the file
		if err := decomp(header, tarReader, destPath); err != nil {
			log.Println(err)
			return false
		}
	}

	return true
}

// decomp decompresses a tar file and writes it to a file
func decomp(header *tar.Header, r io.Reader, destPath string) error {
	// Create the file in the destination path
	f, err := os.Create(filepath.Join(destPath, header.Name))
	if err != nil {
		return err
	}
	defer f.Close()

	// Decompress the file
	if _, err := io.Copy(f, r); err != nil {
		return err
	}

	return nil
}
```

Please note that I have assumed that you have a `tarExtract` package available for extracting tar files. However, this package does not exist in Go's standard library. If you are looking for a standard solution, you can use `os/exec` package to call the `tar` command.

This implementation uses the `tar` package provided by Go, which is available at `golang.org/x/tools/pkg/mod/golang.org/x/tools@v0.1.0/tar`. You can add this package to your `go.mod` file by running `go mod init` and then `go mod edit -replace golang.org/x/tools=golang.org/x/tools@v0.1.0/tar` and then `go get golang.org/x/tools`.