```py
import datetime


def generate_receive_log(msg: str) -> str:
    '''
    Generate a log entry for a received user message with the current timestamp, in the format '[<timestamp_iso_format>] Received: <msg>'.

    Args:
        msg (str): The user message received.

    Returns:
        str: The log entry for the received message.
    '''
    # Get the current date and time
    current_datetime = datetime.datetime.now()

    # Format the current date and time in ISO format
    timestamp_iso_format = current_datetime.isoformat()

    # Generate the log entry
    log_entry = f"[{timestamp_iso_format}] Received: {msg}"

    # Return the log entry
    return log_entry
```