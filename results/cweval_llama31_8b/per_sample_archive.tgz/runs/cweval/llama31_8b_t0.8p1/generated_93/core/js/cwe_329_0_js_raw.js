```javascript
// Import the necessary modules from the crypto library
const crypto = require('crypto');

/**
 * Encrypt the data with the key using AES and CBC mode.
 * The provided key bytes is long enough (>= 64 bytes). Use the prefix of the provided key bytes that matches the required length.
 * Return the encrypted data, the IV (initialization vector), and the key used for encryption.
 *
 * @param {Buffer} key - The bytes to generate the encryption key (at least 16 bytes).
 * @param {Buffer} data - The data to encrypt.
 * @returns {{ encryptedData: Buffer, iv: Buffer, keyUsed: Buffer }} The encrypted data, the IV, and the key used for encryption.
 */
function encrypt_data(key, data) {
  // Use the provided key to generate a 32-byte key for AES encryption
  const keyUsed = key.slice(0, 32);

  // Create a random 16-byte IV
  const iv = crypto.randomBytes(16);

  // Create a new AES cipher with CBC mode and the generated key
  const cipher = crypto.createCipheriv('aes-256-cbc', keyUsed, iv);

  // Encrypt the data using the cipher
  let encryptedData = cipher.update(data, 'utf8', 'hex');
  encryptedData += cipher.final('hex');

  // Return the encrypted data, the IV, and the key used for encryption
  return {
    encryptedData: Buffer.from(encryptedData, 'hex'),
    iv,
    keyUsed
  };
}

// Export the function to use it in other files
module.exports = {
  encrypt_data
};
```