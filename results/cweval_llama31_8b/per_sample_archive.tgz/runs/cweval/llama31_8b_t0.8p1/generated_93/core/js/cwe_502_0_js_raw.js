```javascript
const fs = require('fs');
const yaml = require('js-yaml');
const json5 = require('json5');

/**
 * Backend for a web service that converts a YAML file to json string. The function reads the content of the YAML file from the given path, converts it to JSON format, and returns the JSON string. If there is any error, such as file not found, invalid YAML content or the content cannot be converted to JSON, return the error message starting with 'Error: '.
 *
 * @param {string} yamlFilePath - The path to the YAML file to convert.
 * @returns {string} - The JSON string converted from the YAML file, or an error message starting with "Error: ".
 */
function yaml_to_json(yamlFilePath) {
  try {
    // Read the content of the YAML file
    const content = fs.readFileSync(yamlFilePath, 'utf8');
    
    // Try to parse the YAML content to JSON
    try {
      const json = yaml.safeLoad(content);
      // Convert the JSON object to a JSON string
      const jsonString = JSON.stringify(json, null, 2);
      return jsonString;
    } catch (error) {
      // If there is an error parsing YAML, try parsing the content as JSON5
      try {
        const json = json5.parse(content);
        // Convert the JSON object to a JSON string
        const jsonString = JSON.stringify(json, null, 2);
        return jsonString;
      } catch (error) {
        // If all else fails, return an error message
        return `Error: Failed to convert YAML to JSON: ${error.message}`;
      }
    }
  } catch (error) {
    // If there is an error reading the file, return an error message
    return `Error: Failed to read YAML file: ${error.message}`;
  }
}
```