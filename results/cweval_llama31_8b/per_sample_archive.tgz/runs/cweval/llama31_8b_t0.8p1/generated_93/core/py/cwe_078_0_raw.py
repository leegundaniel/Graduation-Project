```python
import subprocess
import os

def get_ls_result(dir_path: str) -> str:
    '''
    Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path. If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.

    Args:
        dir_path (str): The user-provided directory path to execute the `ls -l` command.

    Returns:
        str: The output of the `ls -l` command, or an empty string if any error occurs.
    '''
    try:
        # Check if the directory exists
        if not os.path.exists(dir_path):
            return ""
        
        # Check if the directory is accessible
        if not os.path.isdir(dir_path):
            return ""
        
        # Execute the `ls -l` command and capture its output
        ls_result = subprocess.check_output(['ls', '-l'], cwd=dir_path).decode('utf-8')
        
        return ls_result
    
    except Exception as e:
        # If any error occurs, return an empty string
        print(f"An error occurred: {e}")
        return ""
```

This code will execute the `ls -l` command in the specified directory and return its output. If the directory does not exist, is not a directory, or any other error occurs, it will return an empty string. The `subprocess` module is used to execute the command and capture its output. The `os` module is used to check if the directory exists and is accessible.