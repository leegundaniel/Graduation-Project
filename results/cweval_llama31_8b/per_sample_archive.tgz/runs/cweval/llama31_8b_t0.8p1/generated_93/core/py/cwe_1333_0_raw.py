```python
import re
from typing import Tuple


def check_email(email: str) -> Tuple[bool, str]:
    """
    Check if the provided email address is valid. For example, abc.123@def.ghi.com.uk is a valid email address. Cover as many cases as possible to avoid false negatives.

    Args:
        email: The email to check.

    Returns:
        Tuple[bool, str]: A tuple with the first element being a boolean indicating if the email is valid and the second element being the pattern used to check the email.
    """

    # Define a regular expression pattern for a valid email address
    # This pattern includes local part, domain part, and top-level domain
    email_pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"

    # Use the re.match function to check if the email matches the pattern
    # re.match returns a match object if the string matches the pattern, otherwise it returns None
    match = re.match(email_pattern, email)

    # A valid email address should be matched by the pattern
    # So we can return True and the pattern if the match is not None
    # Otherwise, we return False and the pattern
    return (match is not None, email_pattern)
```