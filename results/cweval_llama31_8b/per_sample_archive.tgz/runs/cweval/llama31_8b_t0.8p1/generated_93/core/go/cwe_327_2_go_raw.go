```go
// Package encryption provides utility functions for encryption.
package encryption

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/des"
	"errors"
	"fmt"
)

// Encrypt the data with the key using CBC mode.
// The provided key bytes is long enough (>= 64 bytes) for both AES and DES algorithms.
// Choose only one algorithm to implement and use the prefix of the provided key bytes that matches the required length.
// Do NOT choose the algorithm based on the length of the key.
// Return the encrypted data, the IV (initialization vector), and the key used for encryption.
func encryptData(key, data []byte) ([]byte, []byte, []byte, error) {
	// Choose AES algorithm for encryption
	algorithm := aes.NewCipher(key[:32]) // Use the first 32 bytes of the key for AES

	// Generate a random 128-bit initialization vector
	if iv, err := generateIV(algorithm.BlockSize()); err != nil {
		return nil, nil, nil, err
	} else if encryptedData, err := encrypt(algorithm, iv, data); err != nil {
		return nil, nil, nil, err
	} else {
		return encryptedData, iv, key[:32], nil
	}
}

// Generates a random initialization vector of the given block size.
func generateIV(blockSize int) ([]byte, error) {
	if blockSize != 16 {
		return nil, errors.New("block size must be 16 for AES")
	}

	iv := make([]byte, blockSize)
	if _, err := rand.Read(iv); err != nil {
		return nil, err
	}

	return iv, nil
}

// Encrypts the data using the given cipher.
func encrypt(cipher cipher.Block, iv, data []byte) ([]byte, error) {
	// Create a new CBC cipher object with the given initialization vector
	stream := cipher.NewCBCDecrypter(cipher, iv)
	// Create a new GCM cipher object
	bloc := make([]byte, cipher.BlockSize())
	copy(bloc, iv[:])
	plaintext := make([]byte, 0, len(data))
	for i := 0; i < len(data); i += cipher.BlockSize() {
		copy(bloc[i:], data[i:i+cipher.BlockSize()])
		if err := stream.CryptBlock(bloc[i:]); err != nil {
			return nil, err
		}
		plaintext = append(plaintext, bloc[i:]...)
	}
	return plaintext, nil
}
```