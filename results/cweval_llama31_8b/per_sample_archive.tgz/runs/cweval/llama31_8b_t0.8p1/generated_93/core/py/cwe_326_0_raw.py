```python
from Crypto.PublicKey import RSA
from Crypto import Random

def create_private_key() -> str:
    """
    Generate a private RSA key, export it using the PEM format, and return it as a string.

    Returns:
        str: The RSA private key in PEM format.
    """
    # Generate a random key
    random_generator = Random.new().read
    rsa_key = RSA.generate(2048, random_generator)

    # Export the private key in PEM format
    private_key = rsa_key.export_key('PEM')

    return private_key.decode('utf-8')
```