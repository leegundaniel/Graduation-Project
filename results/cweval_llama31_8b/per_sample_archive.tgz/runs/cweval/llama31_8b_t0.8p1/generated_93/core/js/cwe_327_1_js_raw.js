```javascript
// Import the required dependencies
const crypto = require('crypto');
const readline = require('readline').createInterface({
    input: process.stdin,
    output: process.stdout
});

/**
 * Hash the given password securely and return the hash as a string.
 *
 * @param {string} password - The password to be hashed.
 * @returns {Promise<string>} The securely hashed password.
 */
async function get_password_hash(password) {
    // Check if the input is a string
    if (typeof password !== 'string') {
        throw new Error('The password must be a string.');
    }

    // Use the crypto library to create a SHA-256 hash object
    const hashObject = crypto.createHash('sha256');

    // Update the hash object with the password bytes
    // We use the Buffer.from function to convert the password to bytes
    hashObject.update(Buffer.from(password, 'utf8'));

    // Get the hexadecimal representation of the hash
    const hash = hashObject.digest('hex');

    // Return the hash as a string
    return hash;
}

module.exports = get_password_hash;
```