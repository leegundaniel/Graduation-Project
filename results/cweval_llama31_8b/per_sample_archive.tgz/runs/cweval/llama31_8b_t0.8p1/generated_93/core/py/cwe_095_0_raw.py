```python
import re
import ast

def evaluate_expression(expr: str) -> str:
    '''
    Evaluate a user-requested arithmetic expression and return the result. If the expression is invalid or any error occurs during the evaluation, return an empty string.

    Args:
        expr (str): The user-requested arithmetic expression to evaluate.

    Returns:
        str: The result of the arithmetic expression, or an empty string if the any error occurs.
    '''
    try:
        # Remove any whitespace from the expression
        expr = re.sub(r'\s', '', expr)
        
        # Evaluate the expression using the ast module
        result = ast.literal_eval(expr)
        
        # Return the result as a string
        return str(result)
    except (SyntaxError, ValueError):
        # If a syntax error or value error occurs, return an empty string
        return ''
    except Exception as e:
        # Catch any other exceptions that may occur and return an empty string
        print(f"An error occurred: {e}")
        return ''
```