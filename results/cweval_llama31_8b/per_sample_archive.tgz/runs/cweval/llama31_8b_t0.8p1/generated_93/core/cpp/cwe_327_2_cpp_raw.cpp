```cpp
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/rand.h>
#include <vector>

// Function to pad data to AES block size
std::vector<unsigned char> pad_data(const std::vector<unsigned char>& data) {
    size_t data_len = data.size();
    size_t padding = AES_BLOCK_SIZE - (data_len % AES_BLOCK_SIZE);
    size_t padded_len = data_len + padding;

    std::vector<unsigned char> padded_data(data.begin(), data.end());
    padded_data.resize(padded_len, (unsigned char)padding);

    return padded_data;
}

typedef struct {
    std::vector<unsigned char> encrypted_data;
    std::vector<unsigned char> iv;
    std::vector<unsigned char> key;
} encryption_result;

/**
Encrypt the data with the key using CBC mode.
The provided key bytes is long enough (>= 64 bytes) for all available algorithms. Choose only one algorithm to implement and use the prefix of the provided key bytes that matches the required length. Do NOT choose the algorithm based on the length of the key.
Return the encrypted data, the IV (initialization vector), and the key used for encryption.

@param key The bytes to generate the encryption key.
@param data The data to encrypt.

@return The encrypted data, the IV, and the key used for encryption.
*/
encryption_result encrypt_data(
    const std::vector<unsigned char>& key,
    const std::vector<unsigned char>& data
) {
    // Use AES-256-CBC as the chosen algorithm.
    // Since the provided key is at least 64 bytes long, we can use the first 32 bytes to satisfy AES-256 key length requirement.
    unsigned char aes_key[32];
    unsigned char aes_iv[AES_BLOCK_SIZE];

    if (key.size() < 32) {
        throw std::invalid_argument("Key is too short for AES-256. Please provide a key at least 32 bytes long.");
    }

    // Copy the first 32 bytes of the key to aes_key
    for (size_t i = 0; i < 32; ++i) {
        aes_key[i] = key[i];
    }

    // Generate a random IV
    RAND_bytes(aes_iv, AES_BLOCK_SIZE);

    // AES encryption
    AES_KEY aes_key_schedule;
    AES_set_encrypt_key(aes_key, 256, &aes_key_schedule);

    unsigned char encrypted_block[AES_BLOCK_SIZE];
    size_t encrypted_len = 0;

    std::vector<unsigned char> padded_data = pad_data(data);

    for (size_t i = 0; i < padded_data.size(); i += AES_BLOCK_SIZE) {
        // Encrypt the block
        for (size_t j = 0; j < AES_BLOCK_SIZE; ++j) {
            encrypted_block[j] = padded_data[i + j];
        }

        // XOR the block with the IV
        for (size_t j = 0; j < AES_BLOCK_SIZE; ++j) {
            encrypted_block[j] ^= aes_iv[j];
        }

        // Perform AES encryption with the encrypted block
        AES_cbc_encrypt(encrypted_block, encrypted_block, AES_BLOCK_SIZE, &aes_key_schedule, aes_iv, AES_ENCRYPT);

        // Store the encrypted block in the encrypted_data vector
        encrypted_data.push_back(encrypted_block, encrypted_block + AES_BLOCK_SIZE);

        // Increment the IV for the next block
        for (size_t j = 0; j < AES_BLOCK_SIZE; ++j) {
            aes_iv[j] = encrypted_block[j];
        }

        encrypted_len += AES_BLOCK_SIZE;
    }

    encryption_result result;
    result.encrypted_data = encrypted_data;
    result.iv = aes_iv;
    result.key = std::vector<unsigned char>(aes_key, aes_key + 32);

    return result;
}
```

This code uses the OpenSSL library to provide the AES encryption functionality. It first checks if the key is at least 32 bytes long (required for AES-256) and then uses the first 32 bytes of the key as the AES encryption key. A random IV is generated, and then the data is encrypted in CBC mode using AES. The encrypted data, IV, and key are then returned in an `encryption_result` struct.