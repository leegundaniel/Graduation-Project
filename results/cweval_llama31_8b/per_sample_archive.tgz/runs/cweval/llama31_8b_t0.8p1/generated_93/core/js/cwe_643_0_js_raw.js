```javascript
const { JSDOM } = require('jsdom');
const xpath = require('xpath');
const { document } = require('jsdom').JSDOM;

/**
 * Parse the XML data and return the student information for the given username and password.
 * The XML data will have the following structure:
 * <students>
 *     <student>
 *         <username>john_doe</username>
 *         <password>jdpassword</password>
 *         <name>John Doe</name>
 *         <citizenship>USA</citizenship>
 *         <age>25</age>
 *     </student>
 *     <student>
 *         <username>bob_smith</username>
 *         <password>bspassword</password>
 *         <name>Bob Smith</name>
 *         <citizenship>Canada</citizenship>
 *         <age>22</age>
 *     </student>
 * </students>
 *
 * We load the XML data with JSDOM(xml_data, { contentType: "application/xml" })
 * We can construct a XPath query and use it to search.
 *
 * @param {string} xml_data - The XML data containing the student information.
 * @param {string} username - The username of the student to search for.
 * @param {string} password - The password of the student to search for.
 * @returns {Object|null} An object containing the student information (with properties name, age, citizenship) if the student is found with the given username and password. Otherwise, return null.
 */
function getStudentInfo(xml_data, username, password) {
  try {
    // Load the XML data into JSDOM
    const dom = new JSDOM(xml_data, { contentType: "application/xml" });
    const doc = dom.window.document;

    // Construct a XPath query to search for the student with the given username and password
    const xpathQuery = `/students/student[username="${username}" and password="${password}"]]`;

    // Use the XPath query to search for the student
    const studentElement = xpath.select(xpathQuery, doc);

    // If the student is found, return the student information
    if (studentElement.length > 0) {
      const student = studentElement[0];
      return {
        name: student.querySelector('name').textContent,
        age: student.querySelector('age').textContent,
        citizenship: student.querySelector('citizenship').textContent
      };
    }
  } catch (e) {
    console.error(`Error parsing XML data: ${e}`);
  }

  // If the student is not found, return null
  return null;
}

module.exports = getStudentInfo;
```