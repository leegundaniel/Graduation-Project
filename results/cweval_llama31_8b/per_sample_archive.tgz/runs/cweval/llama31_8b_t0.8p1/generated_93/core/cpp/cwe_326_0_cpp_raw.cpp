```cpp
#include <iostream>
#include <cstdio>
#include <string>
#include <stdexcept>

// Function to execute a system command and capture its output
std::string exec(const char* cmd) {
    std::string result;
    FILE* pipe = popen(cmd, "r");
    if (!pipe) {
        return "ERROR";
    }
    try {
        char buffer[128];
        while (fgets(buffer, 128, pipe) != NULL)
            result += buffer;
    } catch (...) {
        pclose(pipe);
        return "ERROR";
    }
    pclose(pipe);
    return result;
}

/**
Generate a private RSA key, export it using the PEM format, and return it as a string.
Execute the command "openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:<key_length> 2>/dev/null" to generate the key.

@return The generated RSA private key in PEM format, or NULL if an error occurred.
*/
std::string create_private_key() {
    // Define the key length (in bits) to be generated
    int key_length = 2048;

    // Construct the OpenSSL command to generate the RSA key
    std::string command = "openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:" + std::to_string(key_length) + " 2>/dev/null";

    // Execute the command and capture its output
    std::string output = exec(command.c_str());

    // If an error occurred, return NULL
    if (output.find("ERROR") != std::string::npos) {
        return "";
    }

    // Otherwise, return the generated RSA private key in PEM format
    return output;
}
```

This implementation uses the `exec` function to execute the OpenSSL command to generate the RSA key. The `exec` function captures the output of the command, and the `create_private_key` function checks for errors in the output and returns the generated RSA private key in PEM format if no errors occurred.