Here's the complete implementation in C++ as per your requirements.

```cpp
#include <openssl/aes.h>
#include <openssl/rand.h>
#include <vector>
#include <tuple>

// Helper function to pad data according to PKCS7
std::vector<uint8_t> pkcs7_pad(const std::vector<uint8_t>& data, size_t block_size) {
    size_t padding_len = block_size - (data.size() % block_size);
    std::vector<uint8_t> padded = data;
    padded.insert(padded.end(), padding_len, static_cast<uint8_t>(padding_len));
    return padded;
}

/**
Encrypt the data with the key using AES and CBC mode.
The provided key bytes is long enough (>= 64 bytes). Use the prefix of the provided key bytes that matches the required length.
Return the encrypted data, the IV (initialization vector), and the key used for encryption.

@param key The bytes to generate the encryption key
@param data The data to encrypt
@return tuple containing: {encrypted data, IV, key used for encryption}
*/
std::tuple<std::vector<uint8_t>, std::vector<uint8_t>, std::vector<uint8_t>>
encrypt_data(const std::vector<uint8_t>& key, const std::vector<uint8_t>& data) {
    // Determine the length of the key required for AES
    size_t key_len = 32;  // AES-256 requires a 32-byte key
    std::vector<uint8_t> key_used(key.begin(), key.begin() + std::min(key_len, key.size()));  // Use the prefix of the key that matches the required length

    // Generate the IV (initialization vector)
    std::vector<uint8_t> iv(16);  // IV for AES-256 CBC mode is 16 bytes
    RAND_bytes(iv.data(), iv.size());

    // Create a new AES context using the key and IV
    AES_KEY aes_key;
    AES_set_encrypt_key(key_used.data(), 256, &aes_key);

    // Determine the block size for AES-256 CBC mode
    const size_t block_size = 16;

    // Pad the data according to PKCS#7
    std::vector<uint8_t> padded_data = pkcs7_pad(data, block_size);

    // Encrypt the padded data using AES CBC mode
    std::vector<uint8_t> encrypted_data(padded_data.size());
    AES_cbc_encrypt(padded_data.data(), encrypted_data.data(), padded_data.size(), &aes_key, iv.data(), AES_ENCRYPT);

    return std::make_tuple(encrypted_data, iv, key_used);
}
```

This implementation follows the function signature and docstring provided in your problem description. It uses the OpenSSL library for encryption and random number generation. The `pkcs7_pad` function is used to pad the data according to the PKCS#7 standard before encryption. The `encrypt_data` function generates the encryption key and IV, creates an AES context, and encrypts the padded data using AES CBC mode. The encrypted data, IV, and key used for encryption are returned as a tuple.