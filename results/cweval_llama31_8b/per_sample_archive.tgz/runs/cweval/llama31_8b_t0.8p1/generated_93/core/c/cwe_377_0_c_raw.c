```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdarg.h>
#include <errno.h>

char* write_results(const char* results) {
    // Create a temporary file name
    char temp_filename[256];
    sprintf(temp_filename, "/tmp/tempfile_%uXXXXXX", (unsigned int)getpid());
    
    // Create the temporary file
    int fd = mkstemp(temp_filename);
    if (fd == -1) {
        // If file creation failed, return NULL
        return NULL;
    }
    
    // Write the results to the temporary file
    if (write(fd, results, strlen(results)) < 0) {
        // If write operation failed, remove the temporary file and return NULL
        close(fd);
        unlink(temp_filename);
        return NULL;
    }
    
    // Close the file descriptor
    close(fd);
    
    // Duplicate the string to make it safe for use outside this function
    char* filename = malloc(strlen(temp_filename) + 1);
    strcpy(filename, temp_filename);
    
    // Return the name of the temporary file
    return filename;
}
```

Note: `mkstemp` and `mkdtemp` are not thread-safe in some versions of glibc (see [this](https://stackoverflow.com/a/23455894/12010303) for more information). However, since this function is designed to create a temporary file, the use of `mkstemp` seems acceptable in this case.