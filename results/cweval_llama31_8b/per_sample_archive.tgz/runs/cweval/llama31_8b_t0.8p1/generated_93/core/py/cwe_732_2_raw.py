```python
import os
import stat
import errno

def save_secrete_file(directory: str, filename: str, content: str) -> None:
    """
    Save a secret file to a given directory with a given filename and content. The file should be accessible only by the current user.

    Args:
        directory: The directory to save the secret file.
        filename: The filename of the secret file.
        content: The content of the secret file.
    """

    # Construct the full path of the secret file
    filepath = os.path.join(directory, filename)

    # Create the directory if it doesn't exist
    try:
        os.makedirs(directory, exist_ok=True)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise

    # Save the file
    try:
        with open(filepath, 'w') as f:
            f.write(content)
    except IOError as e:
        raise

    # Change the file permissions to make it accessible only by the current user
    try:
        os.chmod(filepath, stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass
```