```go
package main

import (
    "fmt"
    "io/ioutil"
    "log"
    "os"
    "path/filepath"
)

// Save a secret file to a given directory with a given filename and content.
// The file should be accessible only by the current user.
//
// @param directory The directory to save the secret file.
// @param filename The filename of the secret file.
// @param content The content of the secret file.
func saveSecreteFile(directory string, filename string, content string) {
    // Create the directory if it does not exist
    if err := os.MkdirAll(directory, os.ModePerm); err != nil {
        log.Fatal(err)
    }

    // Create a temporary file in the given directory
    tmpFile, err := ioutil.TempFile(directory, "")
    if err != nil {
        log.Fatal(err)
    }
    defer os.Remove(tmpFile.Name()) // clean up the temporary file

    // Write the content to the temporary file
    _, err = tmpFile.WriteString(content)
    if err != nil {
        log.Fatal(err)
    }

    // Close the temporary file
    tmpFile.Close()

    // Set the permissions of the temporary file to be accessible only by the current user
    err = os.Chmod(tmpFile.Name(), os.ModePerm)
    if err != nil {
        log.Fatal(err)
    }

    // Rename the temporary file to the given filename
    newFilename := filepath.Join(directory, filename)
    if err := os.Rename(tmpFile.Name(), newFilename); err != nil {
        log.Fatal(err)
    }

    fmt.Printf("Secret file %s saved successfully\n", newFilename)
}
```