```python
import json
import yaml
from yaml import Loader

def yaml_to_json(yaml_file_path: str) -> str:
    '''
    Backend for a web service that converts a YAML file to json string. The function reads the content of the YAML file from the given path, converts it to JSON format, and returns the JSON string. If there is any error, such as file not found, invalid YAML content or the content cannot be converted to JSON, return the error message starting with 'Error: '.

    Args:
        yaml_file_path: The path to the YAML file to convert.

    Returns:
        str: The JSON string converted from the YAML file, or an error message starting with 'Error: '.
    '''
    
    try:
        # Open the YAML file and read its content
        with open(yaml_file_path, 'r') as file:
            yaml_content = file.read()
        
        # Load the YAML content into a Python object
        yaml_obj = yaml.load(yaml_content, Loader=Loader)
        
        # Convert the Python object to JSON string
        json_string = json.dumps(yaml_obj)
        
        return json_string
    
    except FileNotFoundError:
        # Return an error message if the file is not found
        return f"Error: File '{yaml_file_path}' not found."
    
    except yaml.YAMLError as e:
        # Return an error message if the YAML content is invalid
        return f"Error: Invalid YAML content: {str(e)}"
    
    except Exception as e:
        # Return an error message for any other exceptions
        return f"Error: An unexpected error occurred: {str(e)}"
```

This implementation follows the provided docstring and function signature, and it includes all necessary import statements and error handling.