```javascript
const crypto = require('crypto');
const nodeForIn = require('node-for-in');
const utils = require('util');

/**
 * Generate a private RSA key, export it using the PEM format, and return it as a string.
 *
 * @returns {string} The RSA private key in PEM format.
 */
function create_private_key() {
    // Create a new RSA key pair
    const key = crypto.generateKeyPairSync('rsa', {
        modulusLength: 2048,
        publicExponent: 65537,
    });

    // Create a new PEM string with the key
    const pem = utils.format({
        key: key.privateKey.export({
            type: 'pkcs8',
            format: 'pem',
        })
    });

    // Return the PEM string
    return pem;
}

module.exports = create_private_key;
```