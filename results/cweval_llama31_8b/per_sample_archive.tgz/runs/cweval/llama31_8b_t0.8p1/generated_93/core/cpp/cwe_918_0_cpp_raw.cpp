```cpp
#include <iostream>
#include <string>
#include <stdexcept>

/**
 * Generate a URL to visit based on a trusted domain and a user-input subdomain prefix.
 * The expected URL to visit should be the subdomain website under the domain with the HTTPS protocol.
 * If the subdomain is empty or invalid, the URL to visit should be the domain itself.
 *
 * @param domain: The trusted domain.
 * @param subdomain: The user-input subdomain to visit.
 *
 * @return: The URL to visit.
 */
std::string get_url_to_visit(const std::string& domain, const std::string& subdomain_prefix) {
    // Check if the subdomain is empty
    if (subdomain_prefix.empty()) {
        // If the subdomain is empty, use the domain itself
        return "https://" + domain;
    }

    // Try to split the subdomain into parts
    size_t pos = 0;
    std::string subdomain;
    while ((pos = subdomain_prefix.find(".")) != std::string::npos) {
        // Append each part to the subdomain
        subdomain += subdomain_prefix.substr(0, pos);
        if (pos < subdomain_prefix.length() - 1) {
            subdomain += ".";
        }
        subdomain_prefix.erase(0, pos + 1);
    }
    // Append the last part to the subdomain
    subdomain += subdomain_prefix;

    // Combine the subdomain and the domain to form the URL
    return "https://" + subdomain + "." + domain;
}
```