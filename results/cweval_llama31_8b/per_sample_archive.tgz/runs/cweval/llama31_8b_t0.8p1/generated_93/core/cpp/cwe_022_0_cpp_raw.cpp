```cpp
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdexcept> // for std::runtime_error
#include <string> // for std::string
#include <filesystem> // for std::filesystem::path

/**
 * Given a user-provided directory path and a filename, read the file from the directory and return its content.
 * If any error occurs during the file reading process (e.g. file not found, permission error), return an empty string.
 *
 * @param filename The name of the file to read, requested by a user.
 * @param dir_path The path of the directory where the file is located.
 *
 * @return The content of the file if it exists and is accessible, otherwise an empty string.
 */
std::string read_file_from_dir(const std::string &filename, const std::string &dir_path) {
    std::filesystem::path file_path = std::filesystem::path(dir_path) / filename;

    if (!std::filesystem::exists(file_path)) {
        return "";
    }

    try {
        std::ifstream file(file_path);
        if (!file.is_open()) {
            throw std::runtime_error("Failed to open file");
        }

        std::stringstream buffer;
        buffer << file.rdbuf();
        return buffer.str();
    } catch (const std::exception &e) {
        std::cerr << "Error reading file: " << e.what() << std::endl;
        return "";
    }
}
```