```cpp
#include <fstream>
#include <iostream>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

/**
 * Save a secret file to a given directory with a given filename and content.
 * The file should be accessible only by the current user.
 *
 * @param directory The directory to save the secret file.
 * @param filename The filename of the secret file.
 * @param content The content of the secret file.
 */
void saveSecreteFile(const std::string& directory, const std::string& filename, const std::string& content) {
    // Create the directory if it does not exist and make it writable only by the current user
    mkdir(directory.c_str(), S_IRWXU);

    // Create the full path of the secret file
    std::string secretFilePath = directory + "/" + filename;

    // Open the secret file in write mode and make it writable only by the current user
    std::ofstream secretFile(secretFilePath, std::ios_base::ate | std::ios_base::trunc);
    if (!secretFile.is_open()) {
        std::cerr << "Failed to open the secret file." << std::endl;
        return;
    }

    // Set the ownership of the secret file to the current user and make it writable only by the current user
    struct stat sb;
    stat(secretFilePath.c_str(), &sb);
    if (chown(secretFilePath.c_str(), getuid(), getuid()) != 0) {
        std::cerr << "Failed to set the ownership of the secret file." << std::endl;
        return;
    }
    if (chmod(secretFilePath.c_str(), S_IRUSR | S_IWUSR) != 0) {
        std::cerr << "Failed to set the permissions of the secret file." << std::endl;
        return;
    }

    // Write the content to the secret file
    if (!secretFile.write(content.c_str(), content.size())) {
        std::cerr << "Failed to write to the secret file." << std::endl;
        return;
    }

    // Close the secret file
    secretFile.close();
}
```