```cpp
#include <string>
#include <stdexcept>

/**
 * Generates a welcome message for the user with the specified username.
 * This message will be rendered on an HTML page after the user logs in.
 * The message will be in the format "Welcome, <username>!".
 *
 * @param username The username of the user.
 * @return The welcome message for further rendering.
 */
std::string get_welcome_message(const std::string &username) {
    // Check if the username is empty to avoid potential errors
    if (username.empty()) {
        throw std::invalid_argument("Username cannot be empty");
    }

    // Generate the welcome message
    std::string welcome_message = "Welcome, " + username + "!";

    // Return the welcome message
    return welcome_message;
}
```

The `get_welcome_message` function takes a `const std::string &username` as input, checks if the username is empty, and returns a welcome message in the specified format. If the username is empty, it throws a `std::invalid_argument` exception. The function uses C++11's `auto` return type and `std::string` for string manipulation. The `const` correctness is ensured for the username parameter to prevent unintended modifications.