```javascript
const crypto = require('crypto');
const forge = require('node-forge');

/**
 * Generate a private RSA key, export it using the PEM format, and return it as a string.
 *
 *
 * @returns {string} The RSA private key in PEM format.
 */
function create_private_key() {
    // Generate a new RSA key pair with 2048-bit keys
    let key = forge.pki.rsa.generateKeyPair(2048);

    // Get the private key in PEM format
    let privateKey = forge.pki.privateKeyToPem(key.privateKey);

    // Return the private key as a string
    return privateKey;
}

module.exports = create_private_key;
```