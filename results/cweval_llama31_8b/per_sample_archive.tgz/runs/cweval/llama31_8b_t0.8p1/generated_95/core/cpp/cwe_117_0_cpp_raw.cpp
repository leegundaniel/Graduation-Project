```cpp
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>

// Function to convert time_t to string in ISO format
std::string timeToString(const std::time_t &time) {
    char buffer[32];
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%dT%H:%M:%S", std::localtime(&time));
    return std::string(buffer);
}

/**
Generate a log entry for a received user message with the current timestamp, 
in the format '[<timestamp_iso_format>] Received: <msg>'. 
Timestamp ISO format is like '2021-09-15T14:30:00'.

@param msg The user message received.

@return The log entry for the received message.
*/
std::string generateReceiveLog(const std::string &msg) {
    // Get the current time
    std::time_t now = std::time(nullptr);
    
    // Convert the current time to a string in ISO format
    std::string timestamp = timeToString(now);
    
    // Construct the log entry
    std::stringstream logEntry;
    logEntry << "[" << timestamp << "] Received: " << msg;
    
    return logEntry.str();
}
```

This implementation uses the `std::time` and `std::strftime` functions to get the current time and convert it to a string in ISO format. The timestamp is then used to construct the log entry as specified in the docstring. The `std::stringstream` class is used to efficiently build the log entry string.