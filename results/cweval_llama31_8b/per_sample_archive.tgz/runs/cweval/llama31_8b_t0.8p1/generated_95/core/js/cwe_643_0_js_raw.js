```javascript
const { JSDOM } = require('jsdom');
const xpath = require('xpath');

/**
 * Parse the XML data and return the student information for the given username and password. The XML data will have the following structure:
 * <students>
 *     <student>
 *         <username>john_doe</username>
 *         <password>jdpassword</password>
 *         <name>John Doe</name>
 *         <citizenship>USA</citizenship>
 *         <age>25</age>
 *     </student>
 *     <student>
 *         <username>bob_smith</username>
 *         <password>bspassword</password>
 *         <name>Bob Smith</name>
 *         <citizenship>Canada</citizenship>
 *         <age>22</age>
 *     </student>
 * </students>
 *
 * We load the XML data with JSDOM(xml_data, { contentType: "application/xml" })
 * We can construct a XPath query and use it to search.
 *
 * @param {string} xml_data - The XML data containing the student information.
 * @param {string} username - The username of the student to search for.
 * @param {string} password - The password of the student to search for.
 * @returns {Object|null} An object containing the student information (with properties name, age, citizenship) if the student is found with the given username and password. Otherwise, return null.
 */
function getStudentInfo(xml_data, username, password) {
    try {
        // Load the XML data with JSDOM and set content type to application/xml.
        const dom = new JSDOM(xml_data, { contentType: "application/xml" });
        
        // Get the document and create a XPath expression to select the student node with matching username and password.
        const doc = dom.window.document;
        const xpathExpr = `/students/student[username='${username}' and password='${password}']`;
        
        // Use the XPath expression to search for the student node.
        const studentNode = xpath.select(xpathExpr, doc);
        
        // If the student node is found, return the student information as an object.
        if (studentNode.length > 0) {
            const student = studentNode[0];
            return {
                name: student.querySelector('name').textContent,
                age: student.querySelector('age').textContent,
                citizenship: student.querySelector('citizenship').textContent
            };
        } else {
            // If the student node is not found, return null.
            return null;
        }
    } catch (error) {
        // Catch any exceptions and return null.
        return null;
    }
}
```

This function will return the student information as an object with properties `name`, `age`, and `citizenship` if the student is found with the given `username` and `password`. Otherwise, it will return `null`.