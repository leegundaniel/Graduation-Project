```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <errno.h>

/**
 * Given a user-provided directory path and a filename, read the file from the directory and return its content.
 * If any error occurs during the file reading process (e.g. file not found, permission error), return an empty string.
 * The returned string will be freed by the caller.
 *
 * @param filename The name of the file to read, requested by a user.
 * @param dir_path The path of the directory where the file is located.
 *
 * @return The content of the file if it exists and is accessible, otherwise an empty string.
 */
char *read_file_from_dir(const char *filename, const char *dir_path) {
    // Construct the full path to the file
    char *file_path = malloc(strlen(dir_path) + strlen(filename) + 2);
    if (file_path == NULL) {
        return NULL; // Out of memory error
    }
    sprintf(file_path, "%s/%s", dir_path, filename);

    // Check if the file exists
    DIR *dir = opendir(dir_path);
    if (dir == NULL) {
        free(file_path);
        return NULL; // Directory does not exist or cannot be opened
    }

    struct dirent *ent;
    while ((ent = readdir(dir)) != NULL) {
        if (strcmp(ent->d_name, filename) == 0) {
            closedir(dir);
            break;
        }
    }

    if (ent == NULL) {
        free(file_path);
        closedir(dir);
        return NULL; // File does not exist in the directory
    }

    closedir(dir);

    // Open the file
    FILE *fp = fopen(file_path, "r");
    if (fp == NULL) {
        free(file_path);
        return NULL; // File cannot be opened
    }

    // Read the content of the file
    fseek(fp, 0, SEEK_END);
    long file_size = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    char *content = malloc(file_size + 1);
    if (content == NULL) {
        fclose(fp);
        free(file_path);
        return NULL; // Out of memory error
    }

    fread(content, 1, file_size, fp);
    content[file_size] = '\0'; // Null terminate the string

    fclose(fp);
    free(file_path);

    return content;
}
```