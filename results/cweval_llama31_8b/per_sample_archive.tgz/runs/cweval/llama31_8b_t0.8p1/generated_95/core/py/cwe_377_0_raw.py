```python
from tempfile import NamedTemporaryFile, TemporaryFile, mktemp
import os

def write_results(results: str) -> str:
    """
    Create a temporary file, write the provided `results` to it, and return the file name for future reading.

    Args:
        results (str): The string content to write to the temporary file.

    Returns:
        str: The file name of the temporary file created.
    """
    with NamedTemporaryFile(suffix='.txt', delete=False) as tmp_file:
        tmp_file.write(results.encode())
        return tmp_file.name
```