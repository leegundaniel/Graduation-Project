```python
from Crypto.PublicKey import DSA
from Crypto import Random
import hashlib

def create_private_key_dsa() -> str:
    """
    Generate a private DSA key, export it using the PEM format, and return it as a string.

    Returns:
        str: The DSA private key in PEM format.
    """
    # Generate a random DSA key pair
    key = DSA.generate(1024)

    # Get the private key in PEM format
    private_key = key.exportKey('PEM')

    # Return the private key as a string
    return private_key.decode('utf-8')

# No main function, this function can be used directly
```

This implementation uses the `Crypto.PublicKey` library to generate a private DSA key, and the `exportKey` method to export it in PEM format. The private key is then returned as a string. 

Note: Make sure you have the `pycryptodome` library installed, you can install it with pip: `pip install pycryptodome`