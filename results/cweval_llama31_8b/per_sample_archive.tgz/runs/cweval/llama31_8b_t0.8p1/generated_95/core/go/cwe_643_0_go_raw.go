```go
package main

import (
	"encoding/xml"
	"fmt"
	"github.com/ChrisTrenkamp/goxpath"
	"github.com/ChrisTrenkamp/goxpath/tree"
	"github.com/ChrisTrenkamp/goxpath/tree/xmltree"
)

/*
Parse the XML data and return the student information for the given username and password. The XML data will have the following structure:
<students>

	<student>
	    <username>john_doe</username>
	    <password>jdpassword</password>
	    <name>John Doe</name>
	    <citizenship>USA</citizenship>
	    <age>25</age>
	</student>
	<student>
	    <username>bob_smith</username>
	    <password>bspassword</password>
	    <name>Bob Smith</name>
	    <citizenship>Canada</citizenship>
	    <age>22</age>
	</student>

</students>

Use these libs:
"github.com/ChrisTrenkamp/goxpath"
"github.com/ChrisTrenkamp/goxpath/tree"
"github.com/ChrisTrenkamp/goxpath/tree/xmltree"

We can construct a XPath query and then execute the query to search for the student information.

@param xmlData The XML data containing the student information.
@param username The username of the student to search for.
@param password The password of the student to search for.

@return A tuple (name, age, citizenship) if the student is found. Otherwise, returns empty strings.
*/
func getStudentInfo(xmlData, username, password string) (string, string, string) {
	// Parse the XML data into a XMLTree
	xmlTree := tree.NewXMLTree()
	err := xml.Unmarshal([]byte(xmlData), xmlTree)
	if err != nil {
		fmt.Println("Error parsing XML:", err)
		return "", "", ""
	}

	// Construct a XPath query to search for the student information
	query := "//student[username='" + username + "' and password='" + password + "']"

	// Execute the XPath query
	std, err := goxpath.Evaluate(query, xmlTree)
	if err != nil {
		fmt.Println("Error evaluating XPath:", err)
		return "", "", ""
	}

	// Check if the student is found
	if len(std) == 0 {
		return "", "", ""
	}

	// Extract the student information
	name := std[0].DOM().FirstChildWithTag("name").FirstChild().Data()
	age := std[0].DOM().FirstChildWithTag("age").FirstChild().Data()
	citizenship := std[0].DOM().FirstChildWithTag("citizenship").FirstChild().Data()

	return name, age, citizenship
}
```