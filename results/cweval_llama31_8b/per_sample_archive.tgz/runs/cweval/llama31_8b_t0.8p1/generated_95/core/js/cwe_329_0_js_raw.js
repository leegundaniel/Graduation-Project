```javascript
// Import the crypto library, which provides cryptographic functionality that includes a set of wrappers for OpenPGP functions.
const crypto = require('crypto');

/**
 * Encrypt the data with the key using AES and CBC mode.
 * The provided key bytes is long enough (>= 64 bytes). Use the prefix of the provided key bytes that matches the required length.
 * Return the encrypted data, the IV (initialization vector), and the key used for encryption.
 *
 * @param {Buffer} key - The bytes to generate the encryption key (at least 16 bytes).
 * @param {Buffer} data - The data to encrypt.
 * @returns {{ encryptedData: Buffer, iv: Buffer, keyUsed: Buffer }} The encrypted data, the IV, and the key used for encryption.
 */
function encrypt_data(key, data) {
  // Generate a random IV of the required length for CBC mode (16 bytes)
  const iv = crypto.randomBytes(16);

  // Create a new AES cipher object with the provided key (we use the first 32 bytes of the key for AES-256)
  const cipher = crypto.createCipheriv('aes-256-cbc', key.slice(0, 32), iv);

  // Encrypt the data using the cipher object
  let encryptedData = Buffer.concat([cipher.update(data), cipher.final()]);

  // Return the encrypted data, the IV, and the key used for encryption
  return {
    encryptedData: encryptedData,
    iv: iv,
    keyUsed: key.slice(0, 32)
  };
}

module.exports = encrypt_data;
```