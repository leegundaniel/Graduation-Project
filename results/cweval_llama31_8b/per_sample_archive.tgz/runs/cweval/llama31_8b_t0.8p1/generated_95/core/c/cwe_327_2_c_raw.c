```c
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/rand.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_KEY_LEN 256

typedef struct {
    unsigned char* encrypted_data;
    size_t encrypted_len;
    unsigned char* iv;
    unsigned char* key;
} encryption_result;

/**
Encrypt the data with the key using CBC mode.
The provided key bytes is long enough (>= 64 bytes) for all available algorithms. Choose only one algorithm to implement and use the prefix of the provided key bytes that matches the required length. Do NOT choose the algorithm based on the length of the key.
Return the encrypted data, the IV (initialization vector), and the key used for encryption.

@param key The bytes to generate the encryption key.
@param data The data to encrypt.

@return The encrypted data, the IV, and the key used for encryption.
*/
encryption_result encrypt_data(
    const unsigned char* key, size_t key_len,
    const unsigned char* data, size_t data_len
) {
    // Check whether the key length is sufficient for AES-256-CBC
    if (key_len < 32) {
        // We cannot securely continue without a sufficient key length
        return (encryption_result){ NULL, 0, NULL, NULL };
    }

    // Select the AES-256-CBC algorithm
    AES_KEY aes_key;
    unsigned char iv[AES_BLOCK_SIZE];
    unsigned char key_for_aes[key_len];
    memcpy(key_for_aes, key, 32);

    // Generate a random 128-bit IV for AES-256-CBC
    RAND_bytes(iv, AES_BLOCK_SIZE);

    // Initialize AES-256-CBC context
    AES_set_encrypt_key(key_for_aes, 256, &aes_key);

    // Encrypt the data
    unsigned char* encrypted_data = malloc(data_len);
    unsigned int encrypted_len = AES_cbc_encrypt(data, encrypted_data, data_len, &aes_key, iv, AES_ENCRYPT);
    if (encrypted_len > data_len) {
        // Free allocated memory to prevent memory leak
        free(encrypted_data);
        encrypted_data = NULL;
    } else {
        encrypted_len = data_len;
    }

    // Store the IV and key in the result structure
    encryption_result result;
    result.encrypted_data = allocated_data = malloc(encrypted_len);
    memcpy(result.encrypted_data, encrypted_data, encrypted_len);
    free(encrypted_data);
    result.iv = malloc(AES_BLOCK_SIZE);
    memcpy(result.iv, iv, AES_BLOCK_SIZE);
    result.key = malloc(32);
    memcpy(result.key, key_for_aes, 32);
    result.encrypted_len = encrypted_len;

    return result;
}
```