```go
// Package secretefile provides functionality to save a secret file with restricted access.
package main

import (
	"fmt"
	"io/ioutil"
	"log"
	"os"
	"path/filepath"

	"golang.org/x/crypto/ssh/terminal"
)

// Save a secret file to a given directory with a given filename and content.
// The file should be accessible only by the current user.
//
// @param directory The directory to save the secret file.
// @param filename The filename of the secret file.
// @param content The content of the secret file.
func saveSecreteFile(directory string, filename string, content string) {
	// Get the current user to set permissions
	uid, gid, err := os.Getuid(), os.Getgid(), os.Geteuid()
	if err != nil {
		log.Fatal(err)
	}

	// Create the secret file
	filepath.Walk(directory, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if info.IsDir() {
			return nil
		}
		if filepath.Base(path) == filepath.Base(filename) {
			// If the file already exists, delete it
			if err := os.Remove(path); err != nil {
				log.Printf("Error deleting existing file %s: %s\n", path, err)
			}
		}
		return nil
	})

	// Create the secret file
	file, err := ioutil.TempFile(directory, filename)
	if err != nil {
		log.Fatal(err)
	}
	defer func() {
		if err := file.Close(); err != nil {
			log.Printf("Error closing file %s: %s\n", file.Name(), err)
		}
	}()

	// Write the secret content to the file
	if _, err := file.WriteString(content); err != nil {
		log.Fatal(err)
	}

	// Set the file permissions
	if err := os.Chown(file.Name(), uid, gid); err != nil {
		log.Fatal(err)
	}
	if err := os.Chmod(file.Name(), 0o600); err != nil {
		log.Fatal(err)
	}

	// Print the path to the secret file
	fmt.Printf("Secret file saved to: %s\n", file.Name())
}

```