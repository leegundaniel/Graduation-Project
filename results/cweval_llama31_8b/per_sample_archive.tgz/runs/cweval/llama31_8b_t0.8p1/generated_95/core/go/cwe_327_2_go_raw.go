```go
package main

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"errors"
	"fmt"
	"io"
)

// Encrypt the data with the key using CBC mode.
// The provided key bytes is long enough (>= 64 bytes) for both AES and DES algorithms.
// Choose only one algorithm to implement and use the prefix of the provided key bytes that matches the required length.
// Do NOT choose the algorithm based on the length of the key.
// Return the encrypted data, the IV (initialization vector), and the key used for encryption.
// Arguments:
// - key: The bytes to generate the encryption key.
// - data: The data to encrypt.
// Return:
// - The encrypted data, the IV, and the key used for encryption. (encryptedData, iv, aesKey, error)
func encryptData(key, data []byte) ([]byte, []byte, []byte, error) {
	// Choose the AES algorithm for encryption
	aesKey := key[:32] // Use the first 32 bytes of the key for AES encryption (128-bit key)

	// Generate a random initialization vector (IV)
	iv := make([]byte, aes.BlockSize)
	_, err := io.ReadFull(rand.Reader, iv)
	if err != nil {
		return nil, nil, nil, errors.New("failed to generate IV")
	}

	// Create a new AES cipher object
	block, err := aes.NewCipher(aesKey)
	if err != nil {
		return nil, nil, nil, err
	}

	// Create a new CBC mode cipher object
	cbc := cipher.NewCBCEncrypter(block, iv)

	// Encrypt the data
	encryptedData := make([]byte, len(data))
	if err := cbc.Encrypt(encryptedData, data); err != nil {
		return nil, nil, nil, err
	}

	return encryptedData, iv, aesKey, nil
}

func main() {
	// Example usage of the encryptData function
	key := []byte("my_secret_key")
	data := []byte("Hello, World!")
	encryptedData, iv, aesKey, err := encryptData(key, data)
	if err != nil {
		fmt.Println(err)
		return
	}
	fmt.Printf("Encrypted data: %x\n", encryptedData)
	fmt.Printf("IV: %x\n", iv)
	fmt.Printf("AES Key: %x\n", aesKey)
}
```