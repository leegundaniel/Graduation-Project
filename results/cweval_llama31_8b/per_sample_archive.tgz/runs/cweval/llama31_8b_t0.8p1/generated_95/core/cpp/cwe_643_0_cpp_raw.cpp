```cpp
#include <iostream>
#include <string>
#include <map>
#include <libxml/parser.h>
#include <libxml/tree.h>
#include <libxml/xpath.h>

/**
Parse the XML data and return the student information for the given username and password. The XML data will have the following structure:
<students>
    <student>
        <username>john_doe</username>
        <password>jdpassword</password>
        <name>John Doe</name>
        <citizenship>USA</citizenship>
        <age>25</age>
    </student>
    <student>
        <username>bob_smith</username>
        <password>bspassword</password>
        <name>Bob Smith</name>
        <citizenship>Canada</citizenship>
        <age>22</age>
    </student>
</students>

We can construct a XPath query and use it to search.

@param xml_data The XML data containing the student information.
@param username The username of the student to search for.
@param password The password of the student to search for.

@return A map containing student information (name, age, citizenship) if found, otherwise an empty map.
*/
std::map<std::string, std::string> get_student_info(const std::string& xml_data, const std::string& username, const std::string& password) {
    // Parse the XML data
    xmlDocPtr doc = xmlParseDoc((const xmlChar*)xml_data.c_str());
    if (!doc) {
        return std::map<std::string, std::string>();
    }

    // Create a XPath context
    xmlXPathContextPtr context = xmlXPathNewContext(doc);
    if (!context) {
        xmlFreeDoc(doc);
        return std::map<std::string, std::string>();
    }

    // Create a XPath query
    const char* query = "/students/student[username='%s' and password='%s']";
    xmlChar* xpath = xmlStrdup((const xmlChar*)std::string(query).c_str());
    xmlXPathObjectPtr result = xmlXPathEvalExpression((const xmlChar*)xpath, context);
    xmlXPathFreeObject(result);
    xmlXPathFreeContext(context);

    // Search for the student
    xmlNodePtr node = xmlDocGetRootElement(doc);
    for (xmlNodePtr child = node->children; child; child = child->next) {
        if (!xmlStrcmp(child->name, (const xmlChar*)"student")) {
            if (xmlHasProp(child, (const xmlChar*)"username") &&
                !xmlStrcmp(xmlGetProp(child, (const xmlChar*)"username"), (const xmlChar*)username.c_str()) &&
                xmlHasProp(child, (const xmlChar*)"password") &&
                !xmlStrcmp(xmlGetProp(child, (const xmlChar*)"password"), (const xmlChar*)password.c_str())) {
                // Create a map to store the student information
                std::map<std::string, std::string> student_info;

                // Get the name
                xmlNodePtr name_node = xmlDocGetRootElement(doc);
                for (xmlNodePtr grandchild = name_node->children; grandchild; grandchild = grandchild->next) {
                    if (!xmlStrcmp(grandchild->name, (const xmlChar*)"name")) {
                        student_info["name"] = std::string((const char*)xmlNodeGetContent(grandchild));
                        break;
                    }
                }

                // Get the age
                xmlNodePtr age_node = xmlDocGetRootElement(doc);
                for (xmlNodePtr grandchild = age_node->children; grandchild; grandchild = grandchild->next) {
                    if (!xmlStrcmp(grandchild->name, (const xmlChar*)"age")) {
                        student_info["age"] = std::string((const char*)xmlNodeGetContent(grandchild));
                        break;
                    }
                }

                // Get the citizenship
                xmlNodePtr citizenship_node = xmlDocGetRootElement(doc);
                for (xmlNodePtr grandchild = citizenship_node->children; grandchild; grandchild = grandchild->next) {
                    if (!xmlStrcmp(grandchild->name, (const xmlChar*)"citizenship")) {
                        student_info["citizenship"] = std::string((const char*)xmlNodeGetContent(grandchild));
                        break;
                    }
                }

                // Free the XML document
                xmlFreeDoc(doc);

                // Return the student information
                return student_info;
            }
        }
    }

    // Free the XML document
    xmlFreeDoc(doc);

    // Return an empty map
    return std::map<std::string, std::string>();
}
```