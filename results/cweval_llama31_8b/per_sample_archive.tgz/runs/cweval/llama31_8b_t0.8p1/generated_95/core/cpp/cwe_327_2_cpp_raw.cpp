```cpp
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/rand.h>
#include <vector>
#include <cstdint>

// Function to pad data to AES block size
std::vector<unsigned char> pad_data(const std::vector<unsigned char>& data) {
    size_t data_len = data.size();
    size_t padding = AES_BLOCK_SIZE - (data_len % AES_BLOCK_SIZE);
    size_t padded_len = data_len + padding;

    std::vector<unsigned char> padded_data(data.begin(), data.end());
    padded_data.resize(padded_len, (unsigned char)padding);

    return padded_data;
}

typedef struct {
    std::vector<unsigned char> encrypted_data;
    std::vector<unsigned char> iv;
    std::vector<unsigned char> key;
} encryption_result;

/**
Encrypt the data with the key using CBC mode.
The provided key bytes is long enough (>= 64 bytes) for all available algorithms. Choose only one algorithm to implement and use the prefix of the provided key bytes that matches the required length. Do NOT choose the algorithm based on the length of the key.
Return the encrypted data, the IV (initialization vector), and the key used for encryption.

@param key The bytes to generate the encryption key.
@param data The data to encrypt.

@return The encrypted data, the IV, and the key used for encryption.
*/
encryption_result encrypt_data(
    const std::vector<unsigned char>& key,
    const std::vector<unsigned char>& data
) {
    uint8_t iv[AES_BLOCK_SIZE];
    RAND_bytes(iv, AES_BLOCK_SIZE);

    // Use AES-256 for encryption
    unsigned char key_used[AES_KEYLEN_256];
    memcpy(key_used, key.data(), AES_KEYLEN_256);

    // Create an AES context
    AES_KEY aes_key;
    AES_set_encrypt_key(key_used, 256, &aes_key);

    // Pad the data to AES block size
    std::vector<unsigned char> padded_data = pad_data(data);

    // Create a vector to store the encrypted data
    std::vector<unsigned char> encrypted_data(padded_data.size());

    // Encrypt the padded data using CBC mode
    for (size_t i = 0; i < padded_data.size(); i += AES_BLOCK_SIZE) {
        AES_cbc_encrypt(padded_data.data() + i, encrypted_data.data() + i, 
                        AES_BLOCK_SIZE, &aes_key, iv, AES_ENCRYPT);
    }

    // Create an encryption result struct
    encryption_result result;
    result.encrypted_data = encrypted_data;
    result.iv = iv;
    result.key = std::vector<unsigned char>(key_used, key_used + AES_KEYLEN_256);

    return result;
}
```

This code implements the `encrypt_data` function, which takes a key and data as input and returns the encrypted data, the IV, and the key used for encryption. It uses AES-256 encryption with CBC mode and pads the data to AES block size before encryption. The IV is generated randomly, and the key is used directly from the provided key bytes. The encrypted data is stored in a vector, and the function returns the encrypted data, the IV, and the key in an `encryption_result` struct.