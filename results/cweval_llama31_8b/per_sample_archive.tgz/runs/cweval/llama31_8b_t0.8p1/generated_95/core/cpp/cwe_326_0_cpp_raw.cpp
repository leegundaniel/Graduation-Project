```cpp
#include <iostream>
#include <stdexcept>
#include <string>
#include <cstdio>

// OpenSSL library
extern "C" {
#include <openssl/err.h>
#include <openssl/pem.h>
}

/**
 * Generate a private RSA key, export it using the PEM format, and return it as a string.
 * Execute the command "openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:<key_length> 2>/dev/null" to generate the key.
 *
 * @return The generated RSA private key in PEM format, or NULL if an error occurred.
 */
std::string create_private_key(int key_length = 2048) {
    // Initialize OpenSSL error stack
    ERR_load_BIO_errors(BIO_new(NULL));
    ERR_load_crypto_strings();

    // Command to generate private key
    std::string command = "openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:" + std::to_string(key_length) + " 2>/dev/null";

    // Execute the command and store the output
    std::string private_key;
    FILE* pipe = popen(command.c_str(), "r");
    if (!pipe) {
        return "";
    }

    char buffer[128];
    while (fgets(buffer, 128, pipe) != NULL) {
        private_key += buffer;
    }

    // Close the pipe and store the exit status
    int status = pclose(pipe);
    if (status != 0) {
        return "";
    }

    // Check if the key is in PEM format
    if (!PEM_read_string(private_key.c_str(), NULL, NULL, NULL)) {
        return "";
    }

    return private_key;
}
```