```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/evp.h>
#include <openssl/rand.h>

/**
 * Structure to store the hashed password and the salt used.
 */
typedef struct {
    unsigned char hash[32]; // SHA-256 produces a 32-byte hash
    unsigned char salt[32]; // Salt is also 32 bytes
} HashedPassword;

/**
 * Structure to store the hash and the salt for a single password.
 */
typedef struct {
    HashedPassword hashed;
    EVP_MD_CTX* ctx;
} PasswordContext;

/**
 * Function to free the resources used by the context.
 */
void free_context(PasswordContext* ctx) {
    if (ctx == NULL) return;
    EVP_MD_CTX_free(ctx->ctx);
    free(ctx);
}

/**
 * Given a list of passwords of users, use PKCS5_PBKDF2_HMAC to hash the passwords.
 * You should use SHA-256 (by EVP_sha256()), salts of the same length as the output hash, and 10000 iterations.
 * Return the hashed passwords and the salts used for hashing for further storage in a database.

 @param count The number of passwords to hash.
 @param usernames A list of usernames.
 @param passwords A list of passwords of the users to hash.

 @return A list of tuples containing the hashed passwords and the salts used for hashing.
 */
HashedPassword* hash_passwords(int count, char** usernames, char** passwords) {
    HashedPassword* hashed_passwords = malloc(count * sizeof(HashedPassword));
    if (hashed_passwords == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        return NULL;
    }

    PasswordContext* contexts = malloc(count * sizeof(PasswordContext));
    if (contexts == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        free(hashed_passwords);
        return NULL;
    }

    for (int i = 0; i < count; i++) {
        contexts[i].ctx = EVP_MD_CTX_new();
        if (EVP_DigestInit_ex(contexts[i].ctx, EVP_sha256(), NULL) != 1) {
            fprintf(stderr, "Failed to initialize SHA-256 context\n");
            break;
        }

        unsigned char salt[32];
        RAND_bytes(salt, 32);
        memcpy(contexts[i].hashed.salt, salt, 32);

        if (PKCS5_PBKDF2_HMAC(contexts[i].hashed.salt, 32, contexts[i].ctx, EVP_sha256(), 10000, 32, contexts[i].hashed.hash) != 1) {
            fprintf(stderr, "Failed to hash the password\n");
            free_context(&contexts[i]);
            break;
        }
    }

    for (int i = 0; i < count; i++) {
        if (i < count) {
            memcpy(&hashed_passwords[i], &contexts[i].hashed, sizeof(HashedPassword));
        } else {
            free_context(&contexts[i]);
        }
    }

    if (count < count) {
        for (int i = count; i >= 0; i--) {
            free_context(&contexts[i]);
        }
        free(hashed_passwords);
        free(contexts);
        return NULL;
    }

    free(contexts);
    return hashed_passwords;
}
```