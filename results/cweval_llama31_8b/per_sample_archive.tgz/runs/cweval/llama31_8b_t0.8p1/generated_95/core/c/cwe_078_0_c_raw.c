```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>

/**
Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path. If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.

@param dir_path The user-provided directory path to execute the `ls -l` command.

@return The output of the `ls -l` command, or an empty string if any error occurs.
*/
char *get_ls_result(const char *dir_path) {
    // Initialize error pointer for exec functions
    char *err_buf = NULL;

    // Initialize the command to be executed
    char *command = malloc(strlen("ls -l") + strlen(dir_path) + 2);
    if (command == NULL) {
        return NULL;
    }
    strcpy(command, "ls -l");
    strcat(command, " ");
    strcat(command, dir_path);

    // Execute the command in a pipe
    FILE *pipe = popen(command, "r");
    if (pipe == NULL) {
        free(command);
        return NULL;  // Return empty string in case of memory allocation failure
    }

    // Get the output of the command
    char buffer[1024];
    char *output = NULL;
    ssize_t bytes;
    while ((bytes = fread(buffer, 1, 1024, pipe)) > 0) {
        char *temp_output = realloc(output, output ? strlen(output) + bytes + 1 : bytes + 1);
        if (temp_output == NULL) {
            pclose(pipe);
            free(command);
            free(output);
            return NULL;  // Return empty string in case of memory allocation failure
        }
        output = temp_output;
        output += fread(buffer, 1, bytes, pipe);
    }

    // Check for an error
    if (pclose(pipe) != 0) {
        free(output);
        free(command);
        return NULL;  // Return empty string in case of an error
    }

    free(command);
    return output;
}
```

This function uses the `popen` function to execute the `ls -l` command in a pipe. It then reads the output of the command and stores it in a dynamically allocated buffer. If any error occurs during the command execution, it returns an empty string. The function also frees any dynamically allocated memory to prevent memory leaks.