```python
from typing import Tuple
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from Crypto.Random import get_random_bytes

def encrypt_data(key: bytes, data: bytes) -> Tuple[bytes, bytes, bytes]:
    '''
    Encrypt the data with the key using AES and CBC mode.
    The provided key bytes is long enough (>= 64 bytes). Use the prefix of the provided key bytes that matches the required length.
    Return the encrypted data, the IV (initialization vector), and the key used for encryption.

    Args:
        key (bytes): The bytes to generate the encryption key.
        data (bytes): The data to encrypt.

    Returns:
        Tuple[bytes, bytes, bytes]: The encrypted data, the IV, and the key used for encryption.
    '''

    # Determine the length of the key and the number of rounds
    key_length = 32  # AES-256
    num_rounds = key_length // 4

    # Get the required key length from the provided key
    required_key_length = key_length
    cipher_key = key[:required_key_length]

    # Generate a random IV
    iv = get_random_bytes(16)

    # Create an AES cipher object with the key and IV
    cipher = AES.new(cipher_key, AES.MODE_CBC, iv)

    # Pad the data to the block size
    padded_data = pad(data, AES.block_size)

    # Encrypt the data
    encrypted_data = cipher.encrypt(padded_data)

    # Return the encrypted data, the IV, and the key used for encryption
    return encrypted_data, iv, cipher_key
```