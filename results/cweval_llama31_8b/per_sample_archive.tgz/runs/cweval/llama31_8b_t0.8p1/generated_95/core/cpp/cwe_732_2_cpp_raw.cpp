```cpp
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <sys/stat.h>
#include <unistd.h>

// Function to save a secret file to a given directory with a given filename and content.
// The file should be accessible only by the current user.
//
// @param directory The directory to save the secret file.
// @param filename The filename of the secret file.
// @param content The content of the secret file.
void saveSecreteFile(const std::string& directory, const std::string& filename, const std::string& content) {
    // Create the directory if it does not exist
    if (mkdir(directory.c_str(), S_IRWXU) != 0 && errno != EEXIST) {
        std::cerr << "Error creating directory: " << strerror(errno) << std::endl;
        return;
    }

    // Create a new file in the directory with the given filename and content
    try {
        std::ofstream file(directory + "/" + filename);
        if (!file.is_open()) {
            throw std::runtime_error("Failed to open file");
        }
        file << content;
        file.close();
    } catch (const std::exception& e) {
        std::cerr << "Error saving secret file: " << e.what() << std::endl;
    }

    // Change the permissions of the file to be accessible only by the current user
    try {
        struct stat sb;
        if (stat((directory + "/" + filename).c_str(), &sb) != 0) {
            throw std::runtime_error("Failed to access file");
        }
        if (chmod((directory + "/" + filename).c_str(), S_IRUSR | S_IWUSR) != 0) {
            throw std::runtime_error("Failed to change permissions");
        }
    } catch (const std::exception& e) {
        std::cerr << "Error changing permissions: " << e.what() << std::endl;
    }
}
```