```python
# Import the required library for string manipulation and url construction
import urllib.parse

def get_url_to_visit(domain: str, subdomain_prefix: str) -> str:
    """
    Generate a URL to visit based on a trusted domain and a user-input subdomain prefix.
    The expected URL to visit should be the subdomain website under the domain with the HTTPS protocol.
    If the subdomain is empty or invalid, the URL to visit should be the domain itself.

    Examples:
    - get_url_to_visit('example.com', 'subdomain') returns 'https://subdomain.example.com'
    - get_url_to_visit('example.com', 'a.b') returns 'https://a.b.example.com'

    Args:
        domain: The trusted domain.
        subdomain_prefix: The user-input subdomain to visit.

    Returns:
        str: The URL to visit.
    """
    # Remove leading slash from the subdomain prefix
    subdomain_prefix = subdomain_prefix.lstrip('/')

    # Use urllib.parse.urljoin to safely join the subdomain prefix to the domain
    # If the subdomain prefix is empty or invalid, it will simply use the domain
    url = urllib.parse.urljoin('//' + subdomain_prefix + '.', 'https://' + domain)

    # Return the constructed URL
    return url
```