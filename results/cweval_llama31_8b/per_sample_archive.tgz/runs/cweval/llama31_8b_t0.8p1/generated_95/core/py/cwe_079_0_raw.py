```python
"""
This module provides a function to generate a welcome message for a user.
"""

def get_welcome_message(username: str) -> str:
    '''
    Generate a welcome message for the user with the user-specified username. This message will be redendered in a HTML page after the user logs in. The message will be in the format "Welcome, <username>!".

    Args:
        username (str): The username of the user.

    Returns:
        str: The welcome message for further rendering.
    '''
    # Check if the username is not empty to avoid empty welcome messages
    if not username:
        return "Welcome!"

    # Generate the welcome message by formatting the username
    welcome_message = f"Welcome, {username}!"

    return welcome_message
```