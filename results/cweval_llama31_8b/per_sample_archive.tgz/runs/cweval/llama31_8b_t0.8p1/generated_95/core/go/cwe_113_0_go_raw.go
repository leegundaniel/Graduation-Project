```go
package main

import (
	"fmt"
	"strings"
)

// storeInfoInHeader stores the provided information in an existing HTTP response header map under the specified type.
// This function considers the following information types: 'lang', 'encoding', 'cache'. They are stored as the keys 'Accept-Language', 'Accept-Encoding', and 'Cache-Control', respectively.
// Information content is read from user requests.
// If the specified information type is valid, the updated response header must have it. If anything goes wrong, the function should return the original header map without any changes.
//
// Args:
//
//	infoType (string): The type of information to store in the header.
//	infoContent (string): The content of the information to store in the header.
//	header (map[string]string): The existing response header map.
//
// Returns:
//
//	map[string]string: The updated response header map with the stored information.
func storeInfoInHeader(infoType string, infoContent string, header map[string]string) map[string]string {
	// Define the valid information types
	validInfoTypes := map[string]bool{
		"lang":    true,
		"encoding": true,
		"cache":   true,
	}

	// Define the corresponding header keys for each valid information type
	infoKeys := map[string]string{
		"lang":    "Accept-Language",
		"encoding": "Accept-Encoding",
		"cache":   "Cache-Control",
	}

	// Create a copy of the original header map to avoid modifying it directly
	var updatedHeader map[string]string
	if header != nil {
		updatedHeader = make(map[string]string, len(header))
		for key, value := range header {
			updatedHeader[key] = value
		}
	} else {
		updatedHeader = make(map[string]string)
	}

	// Check if the specified information type is valid
	if validInfoTypes[infoType] {
		// Store the information content in the corresponding header key
		headerKey := infoKeys[infoType]
		if headerKey == "Cache-Control" {
			// If the header key is 'Cache-Control', append the new information to the existing value
			if _, ok := updatedHeader[headerKey]; ok {
				updatedHeader[headerKey] += "," + infoContent
			} else {
				updatedHeader[headerKey] = infoContent
			}
		} else {
			// If the header key is 'Accept-Language' or 'Accept-Encoding', replace the existing value with the new information
			updatedHeader[headerKey] = infoContent
		}
	} else {
		// If the specified information type is invalid, return the original header map
		return header
	}

	// Return the updated response header map
	return updatedHeader
}
```