```go
package main

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"log"
)

// Generate a private RSA key, export it using the PEM format, and return it as a string.
func CreatePrivateKey() string {
	// Generate a new RSA key pair
	privateKey, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		log.Fatal(err)
	}

	// Convert the private key to a PEM-encoded string
DER := x509.MarshalPKCS1PrivateKey(privateKey)
block := pem.Block{
	Type:  "RSA PRIVATE KEY",
	Bytes: DER,
}
pemPrivateKey := pem.EncodeToMemory(&block)

	return string(pemPrivateKey)
}

func main() {}
```

This function generates a new RSA key pair using the `crypto/rsa` package, converts it to a PEM-encoded string using the `encoding/pem` package, and returns the string representation of the private key. If an error occurs during key generation, the function will log the error and exit the program. If successful, it will return the private key as a string.