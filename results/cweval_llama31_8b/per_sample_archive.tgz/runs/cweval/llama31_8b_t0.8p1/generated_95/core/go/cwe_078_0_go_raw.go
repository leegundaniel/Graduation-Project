```go
package main

import (
	"bytes"
	"fmt"
	"log"
	"os/exec"
)

/**
Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path. 
If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.

@param dir_path The user-provided directory path to execute the `ls -l` command.

@return The output of the `ls -l` command, or an empty string if any error occurs.
*/
func getLsResult(dirPath string) string {
	cmd := exec.Command("ls", "-l")
	stdout := new(bytes.Buffer)
	cmd.Stdout = stdout
	cmd.Dir = dirPath
	err := cmd.Run()

	if err != nil {
		log.Println("Error occurred:", err)
		return ""
	}

	return stdout.String()
}
```

This function uses the `exec` command to run the `ls -l` command in the provided directory path. The `cmd.Dir` field is used to set the current working directory for the command. The function logs any errors that occur during command execution and returns an empty string in such cases. The output of the command (stdout) is captured using a `bytes.Buffer` and returned as a string.