```javascript
// Import the required modules
const fs = require('fs');
const yaml = require('js-yaml');
const json-stringify-safe = require('json-stringify-safe');

/**
 * Backend for a web service that converts a YAML file to json string.
 * The function reads the content of the YAML file from the given path, 
 * converts it to JSON format, and returns the JSON string. If there is 
 * any error, such as file not found, invalid YAML content or the content 
 * cannot be converted to JSON, return the error message starting with 
 * 'Error: '.
 *
 * @param {string} yamlFilePath - The path to the YAML file to convert.
 * @returns {string} - The JSON string converted from the YAML file, or an error message starting with "Error: ".
 */
function yaml_to_json(yamlFilePath) {
  // Try to read the YAML file from the given path
  try {
    // Read the content of the YAML file
    const yamlContent = fs.readFileSync(yamlFilePath, 'utf8');
    
    // Try to parse the YAML content
    try {
      // Parse the YAML content
      const yamlObject = yaml.safeLoad(yamlContent);
      
      // Try to convert the YAML object to JSON string
      try {
        // Convert the YAML object to JSON string
        const jsonString = json-stringify-safe.yamlObjectToJSON(yamlObject, null, 2);
        
        // Return the JSON string
        return jsonString;
      } catch (e) {
        // If the YAML object cannot be converted to JSON, return the error message
        return `Error: The YAML object cannot be converted to JSON. ${e.message}`;
      }
    } catch (e) {
      // If the YAML content is invalid, return the error message
      return `Error: Invalid YAML content. ${e.message}`;
    }
  } catch (e) {
    // If the file is not found, return the error message
    return `Error: File not found. ${e.message}`;
  }
}
```

This implementation uses the 'fs', 'js-yaml', and 'json-stringify-safe' modules to read the YAML file, parse the YAML content, and convert the YAML object to JSON string. If any error occurs during the process, it returns the error message starting with 'Error: '.