```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

/**
 * Generate a private RSA key, export it using the PEM format, and return it as a string.
 * Execute the command "openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:<key_length> 2>/dev/null" to generate the key.
 *
 * @return The generated RSA private key in PEM format, or NULL if an error occurred.
 */
char *create_private_key() {
    // Define the command to generate the private key
    char command[256];
    sprintf(command, "openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 2>/dev/null");

    // Execute the command and capture the output
    FILE *fp = popen(command, "r");
    if (fp == NULL) {
        return NULL;
    }

    // Read the output of the command
    char buffer[1024];
    char *result = NULL;
    ssize_t bytesRead;
    while ((bytesRead = fread(buffer, 1, 1024, fp)) > 0) {
        buffer[bytesRead] = '\0';
        result = realloc(result, strlen(result) + bytesRead + 1);
        strcpy(result + strlen(result), buffer);
    }

    // Close the pipe
    pclose(fp);

    return result;
}
```

This code uses the `popen` function to execute the OpenSSL command and capture its output. It then reads the output from the pipe and stores it in a string. The `realloc` function is used to dynamically allocate memory for the output string as it grows. If the `popen` or `fread` functions fail, the function returns NULL to indicate an error.