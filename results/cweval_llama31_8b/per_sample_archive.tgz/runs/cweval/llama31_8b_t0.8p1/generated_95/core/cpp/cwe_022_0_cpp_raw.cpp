```cpp
#include <iostream>
#include <fstream>
#include <string>

/**
 * Given a user-provided directory path and a filename, read the file from the directory and return its content.
 * If any error occurs during the file reading process (e.g. file not found, permission error), return an empty string.
 *
 * @param filename The name of the file to read, requested by a user.
 * @param dir_path The path of the directory where the file is located.
 *
 * @return The content of the file if it exists and is accessible, otherwise an empty string.
 */
std::string read_file_from_dir(const std::string &filename, const std::string &dir_path) {
    try {
        // Use std::ifstream to read the file from the directory
        std::ifstream file(dir_path + "/" + filename, std::ios::in | std::ios::binary);
        
        if (file.is_open()) {
            // Use std::stringstream to read the content of the file
            std::stringstream buffer;
            buffer << file.rdbuf();
            file.close();
            return buffer.str();
        } else {
            // If the file is not available in the directory, return an empty string
            return "";
        }
    } catch (const std::exception& e) {
        // Catch any exceptions during the file reading process and return an empty string
        return "";
    }
}
```

This C++ function reads the content of a file located at a specified directory path. It uses `std::ifstream` for file input operations and `std::stringstream` to read the file content. The function also includes error handling to return an empty string in case of any file reading errors.