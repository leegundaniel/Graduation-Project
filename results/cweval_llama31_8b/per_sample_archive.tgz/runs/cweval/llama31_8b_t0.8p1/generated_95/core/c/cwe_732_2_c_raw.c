```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>

/**
 * Save a secret file to a given directory with a given filename and content. The file should be accessible only by the current user.
 * 
 * @param directory The directory to save the secret file.
 * @param filename The filename of the secret file.
 * @param content The content of the secret file.
 */
void save_secrete_file(const char *directory, const char *filename, const char *content) {
    // Create the directory if it doesn't exist
    if (mkdir(directory, S_IRWXU) != 0 && errno != EEXIST) {
        perror("mkdir");
        return;
    }

    // Create the secret file
    int fd = openat(AT_FDCWD, directory, O_RDONLY | O_DIRECTORY);
    if (fd < 0) {
        perror("openat");
        return;
    }
    fd = openat(fd, filename, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
    if (fd < 0) {
        perror("openat");
        close(fd);
        return;
    }

    // Write the content to the secret file
    ssize_t bytes_written = write(fd, content, strlen(content));
    if (bytes_written != strlen(content)) {
        perror("write");
        close(fd);
        return;
    }

    close(fd);
}
```

This code creates the specified directory if it doesn't exist and then creates a secret file in that directory. The secret file is accessible only by the current user, and its content is written from the `content` parameter.