```cpp
#include <openssl/evp.h>
#include <openssl/sha.h>
#include <vector>
#include <string>
#include <cstdint>
#include <stdexcept>

std::vector<std::pair<std::vector<unsigned char>, std::vector<unsigned char>>> hash_passwords(int count, const std::vector<std::string>& usernames, const std::vector<std::string>& passwords) {
    if (count != usernames.size() || count != passwords.size()) {
        throw std::runtime_error("The number of usernames/passwords does not match the count");
    }

    std::vector<std::pair<std::vector<unsigned char>, std::vector<unsigned char>>> hashed_passwords;
    hashed_passwords.reserve(count);

    unsigned char salt[32];
    for (int i = 0; i < count; i++) {
        unsigned int salt_len = 32;
        RAND_bytes(salt, salt_len);

        unsigned int output_len = EVP_MAX_MD_SIZE;
        unsigned char hash[output_len];
        PKCS5_PBKDF2_HMAC(EVP_sha256(), usernames[i].c_str(), usernames[i].size(), salt, salt_len, 10000, &output_len, hash);

        hashed_passwords.emplace_back(hash, salt);
    }

    return hashed_passwords;
}
```

This function uses the OpenSSL library to generate a SHA-256 hash with PKCS5_PBKDF2_HMAC for each password, and stores the hashed password and the salt used for hashing in a pair. The function also checks that the number of usernames and passwords match the count. If they do not match, it throws a runtime error. The `hashed_passwords` vector is reserving space for `count` pairs in advance to avoid unnecessary reallocations.