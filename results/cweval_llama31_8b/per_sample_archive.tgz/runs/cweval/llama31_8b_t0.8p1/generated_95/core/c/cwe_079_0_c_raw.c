```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * Generates a welcome message for the user with the specified username. 
 * This message will be rendered in a HTML page after the user logs in.
 * The message will be in the format "Welcome, <username>!".

 * @param username The username of the user.

 * @return The welcome message for further rendering.
 */
char* get_welcome_message(const char* username) {
    // Calculate the length of the welcome message by adding 1 to the length of the username
    size_t message_length = strlen(username) + strlen("Welcome, ") + strlen("!");
    
    // Allocate memory for the welcome message using malloc
    char* welcome_message = (char*)malloc(message_length * sizeof(char));
    
    // Check if memory allocation was successful
    if (welcome_message == NULL) {
        fprintf(stderr, "Memory allocation failed.\n");
        return NULL;
    }
    
    // Copy "Welcome, " into the welcome message
    strcpy(welcome_message, "Welcome, ");
    
    // Copy the username into the welcome message
    strcpy(welcome_message + strlen("Welcome, "), username);
    
    // Append the exclamation mark to the welcome message
    welcome_message[strcspn(welcome_message, "\0")++] = '!';
    
    return welcome_message;
}
```

Note: Don't forget to free the allocated memory in the calling function to prevent memory leaks. For example:

```c
int main() {
    char* welcome_message = get_welcome_message("John");
    if (welcome_message != NULL) {
        printf("%s\n", welcome_message);
        free(welcome_message);
    }
    return 0;
}
```