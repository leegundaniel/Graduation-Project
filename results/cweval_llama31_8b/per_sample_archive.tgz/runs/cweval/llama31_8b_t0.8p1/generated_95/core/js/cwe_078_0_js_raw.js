```javascript
// Import the required module
const childProcess = require('child_process');

/**
 * Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path. If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.
 *
 * @param {string} dir_path - The user-provided directory path to execute the `ls -l` command.
 * @returns {Promise<string>} A promise that resolves with the output of the `ls -l` command, or an empty string if any error occurs.
 */
function get_ls_result(dir_path) {
    try {
        // Execute the command using childProcess and capture the stdout output
        const lsCmd = childProcess.execSync(`ls -l ${dir_path}`, { encoding: 'utf8', stdio: ['ignore', process.stdout, 'ignore'] });
        // Return the captured stdout output
        return lsCmd;
    } catch (error) {
        // If any error occurs, return an empty string
        return '';
    }
}

// You can export the function if needed
module.exports = get_ls_result;
```

This JavaScript implementation includes the required `childProcess` module to execute the `ls -l` command and capture its stdout output. The function is designed to handle potential errors that may occur when executing the command in the provided directory path, and it returns an empty string in case of any errors.