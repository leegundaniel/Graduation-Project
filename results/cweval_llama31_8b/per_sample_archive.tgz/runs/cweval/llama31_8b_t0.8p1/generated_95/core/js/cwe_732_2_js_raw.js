```javascript
const fs = require('fs');
const path = require('path');
const os = require('os');
const { promisify } = require('util');

const writeFile = promisify(fs.writeFile);
const mkdir = promisify(fs.mkdir);

/**
 * Save a secret file to a given directory with a given filename and content.
 * The file should be accessible only by the current user.
 *
 * @param {string} directory - The directory to save the secret file.
 * @param {string} filename - The filename of the secret file.
 * @param {string} content - The content of the secret file.
 */
async function saveSecretFile(directory, filename, content) {
  try {
    // Create the directory if it doesn't exist and set permissions to 0700 (drwx------)
    await mkdir(path.join(directory), { recursive: true }, fs.constants.S_IRUSR | fs.constants.S_IXUSR);

    // Create the secret file and set permissions to 0600 (rw-------)
    const filePath = path.join(directory, filename);
    await writeFile(filePath, content, { mode: fs.constants.S_IRUSR | fs.constants.S_IWUSR });
  } catch (error) {
    console.error(`Error saving secret file: ${error.message}`);
    // Return an empty string to indicate failure
    return '';
  }

  // Return the path to the saved secret file
  return filePath;
}
```