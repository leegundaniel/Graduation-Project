```go
package main

import (
	"fmt"
	"io/ioutil"
	"os"
)

/**
Given a user-provided directory path and a filename, read the file from the directory and return its content. 
If any error occurs during the file reading process (e.g. file not found, permission error), return an empty string. 
The returned string will be freed by the caller.

@param filename The name of the file to read, requested by a user.
@param dir_path The path of the directory where the file is located.

@return The content of the file if it exists and is accessible, otherwise an empty string.
*/
func readFileFromDir(filename, dirPath string) string {
	// Construct the full path of the file
	filePath := dirPath + "/" + filename

	// Attempt to read the file
	data, err := ioutil.ReadFile(filePath)

	// If an error occurs, return an empty string
	if err != nil {
		if os.IsNotExist(err) {
			fmt.Printf("Error: File %s does not exist in directory %s\n", filename, dirPath)
		} else if os.IsPermission(err) {
			fmt.Printf("Error: Permission denied for file %s in directory %s\n", filename, dirPath)
		} else {
			fmt.Printf("Error reading file %s from directory %s: %v\n", filename, dirPath, err)
		}
		return ""
	}

	// If the file is read successfully, return its content
	return string(data)
}
```