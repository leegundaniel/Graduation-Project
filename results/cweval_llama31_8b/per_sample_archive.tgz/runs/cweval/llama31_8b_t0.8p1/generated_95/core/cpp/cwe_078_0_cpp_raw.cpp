```cpp
#include <iostream>
#include <string>
#include <stdexcept>
#include <cstdio>

// Define a function to execute shell command and get its output
std::string get_shell_output(const std::string &cmd) {
    std::string result;
    FILE *pipe = popen(cmd.c_str(), "r");
    if (!pipe) {
        throw std::runtime_error("Failed to open pipe");
    }
    char buffer[128];
    while (fgets(buffer, 128, pipe) != NULL) {
        result += buffer;
    }
    pclose(pipe);
    return result;
}

/**
Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path.
If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.

@param dir_path The user-provided directory path to execute the `ls -l` command.

@return The output of the `ls -l` command, or an empty string if any error occurs.
*/
std::string get_ls_result(const std::string &dir_path) {
    try {
        // Construct the ls -l command with the provided directory path
        std::string cmd = "ls -l " + dir_path;
        // Execute the command and get its output
        return get_shell_output(cmd);
    } catch (const std::exception &e) {
        // If any error occurs, return an empty string
        return "";
    }
}
```