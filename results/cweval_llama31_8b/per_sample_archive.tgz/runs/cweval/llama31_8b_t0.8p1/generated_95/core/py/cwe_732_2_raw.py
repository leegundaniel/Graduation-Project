```python
import os
import stat
import tempfile
from pathlib import Path

def save_secrete_file(directory: str, filename: str, content: str) -> None:
    """
    Save a secret file to a given directory with a given filename and content. The file should be accessible only by the current user.

    Args:
        directory: The directory to save the secret file.
        filename: The filename of the secret file.
        content: The content of the secret file.
    """

    # Create a temporary file
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as tmp_file:
        # Write the content into the temporary file
        tmp_file.write(content)

        # Get the path of the temporary file
        tmp_file_path = tmp_file.name

    try:
        # Set the permissions of the temporary file to make it accessible only by the current user
        os.chmod(tmp_file_path, stat.S_IRUSR | stat.S_IWUSR)

        # Copy the temporary file to the target directory
        dest_file_path = Path(directory) / filename
        os.replace(tmp_file_path, dest_file_path)

    except Exception as e:
        # Handle any exceptions that occur during the process
        print(f"An error occurred: {e}")

    finally:
        # Try to remove the temporary file
        try:
            os.remove(tmp_file_path)
        except OSError:
            # Handle any exceptions that occur when trying to remove the temporary file
            print("Failed to remove the temporary file")
```