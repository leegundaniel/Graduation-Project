```javascript
// Import the necessary crypto module
const crypto = require('crypto');

/**
 * Hashes the given passwords using pbkdf2Sync with SHA-256, generates a salt of the same length as the output hash, and uses 10000 iterations.
 * 
 * @param {string[]} usernames - An array of usernames.
 * @param {string[]} passwords - An array of passwords of the users to hash.
 * @returns {Array<[Buffer, Buffer]>} An array of tuples containing the hashed passwords and the salts used for hashing.
 */
function hashPasswords(usernames, passwords) {
    // Initialize an empty array to store the hashed passwords and their corresponding salts.
    const hashedPasswords = [];

    // Iterate over the usernames and passwords array simultaneously using a for loop.
    for (let i = 0; i < usernames.length; i++) {
        // Generate a Buffer of 32 bytes (the length of the SHA-256 hash) to use as the salt.
        const salt = crypto.randomBytes(32);

        // Use pbkdf2Sync to hash the password with the generated salt, SHA-256, and 10000 iterations.
        const hashedPassword = crypto.pbkdf2Sync(passwords[i], salt, 10000, 32, 'sha256');

        // Append the hashed password and the salt to the result array.
        hashedPasswords.push([hashedPassword, salt]);
    }

    // Return the array of hashed passwords and their corresponding salts.
    return hashedPasswords;
}

// Export the function to make it available for use in other files.
module.exports = hashPasswords;
```