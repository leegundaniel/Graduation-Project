```go
package main

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"errors"
	"io"
)

/*
Encrypt the data with the key using AES and CBC mode.
The provided key bytes is long enough (>= 64 bytes). Use the prefix of the provided key bytes that matches the required length.
Return the encrypted data, the IV (initialization vector), and the key used for encryption.

Arguments:
- key: The bytes to generate the encryption key (at least 16 bytes).
- data: The data to encrypt.

Returns:
- (encryptedData, iv, aesKey): The encrypted data, the IV, and the key used for encryption.
*/
func encryptData(key []byte, data []byte) (encryptedData []byte, iv []byte, aesKey []byte) {
	if len(key) < 16 {
		panic(errors.New("key must be at least 16 bytes long"))
	}

	// Get the first 16 bytes of the key as the AES key
	aesKey = key[:16]

	// Create a new SHA256 hash to hash the key
	hash := sha256.New()
	_, _ = hash.Write(aesKey)
	hashedKey := hash.Sum(nil)

	// Derive the encryption key
	encryptionKey := hashedKey

	// Create a new AES cipher with 128-bit key and CBC mode
	c, err := aes.NewCipher(encryptionKey)
	if err != nil {
		panic(err)
	}

	// Generate a random initialization vector
	iv = make([]byte, c.BlockSize())
	_, _ = rand.Read(iv)

	// Create a new CBC mode instance
	blockMode := cipher.NewCBCEncrypter(c, iv)

	// Encrypt the data
	encryptedData = make([]byte, len(data))
	blockMode.CryptBlocks(encryptedData, data)

	// Encode the IV and encryption key as base64 and append it to the encrypted data
	base64Iv := base64.StdEncoding.EncodeToString(iv)
	base64Key := base64.StdEncoding.EncodeToString(encryptionKey)
	joined := base64Iv + "." + base64Key
	joinedBytes := []byte(joined)
	encryptedData = append(encryptedData, joinedBytes...)

	return encryptedData, iv, aesKey
}
```