```cpp
#include <openssl/aes.h>
#include <openssl/rand.h>
#include <iostream>
#include <tuple>
#include <vector>
#include <cstdint>
#include <stdexcept>

// Helper function to generate a random IV
std::vector<uint8_t> generate_iv(size_t block_size) {
    std::vector<uint8_t> iv(block_size);
    RAND_bytes(iv.data(), iv.size());
    return iv;
}

// Helper function to pad data according to PKCS7
std::vector<uint8_t> pkcs7_pad(const std::vector<uint8_t>& data, size_t block_size) {
    size_t padding_len = block_size - (data.size() % block_size);
    std::vector<uint8_t> padded = data;
    padded.insert(padded.end(), padding_len, static_cast<uint8_t>(padding_len));
    return padded;
}

/**
Encrypt the data with the key using AES and CBC mode.
The provided key bytes is long enough (>= 64 bytes). Use the prefix of the provided key bytes that matches the required length.
Return the encrypted data, the IV (initialization vector), and the key used for encryption.

@param key The bytes to generate the encryption key
@param data The data to encrypt
@return tuple containing: {encrypted data, IV, key used for encryption}
*/
std::tuple<std::vector<uint8_t>, std::vector<uint8_t>, std::vector<uint8_t>>
encrypt_data(const std::vector<uint8_t>& key, const std::vector<uint8_t>& data) {
    // Determine the block size based on the key
    size_t block_size;
    if (key.size() >= 128) {
        block_size = 128 / 8; // AES-128
    } else if (key.size() >= 192) {
        block_size = 192 / 8; // AES-192
    } else if (key.size() >= 256) {
        block_size = 256 / 8; // AES-256
    } else {
        throw std::invalid_argument("Key must be at least 64 bytes long");
    }

    // Generate a random IV
    std::vector<uint8_t> iv = generate_iv(block_size);

    // Create an AES context
    AES_KEY aes_key;
    AES_set_encrypt_key(key.data(), key.size() * 8, &aes_key);

    // Pad the data to the block size
    std::vector<uint8_t> padded_data = pkcs7_pad(data, block_size);

    // Encrypt the data
    std::vector<uint8_t> encrypted_data;
    for (size_t i = 0; i < padded_data.size(); i += block_size) {
        AES_cbc_encrypt(padded_data.data() + i, encrypted_data.data() + i, block_size, &aes_key, iv.data(), AES_ENCRYPT);
    }

    // Return the encrypted data, IV, and key
    return std::make_tuple(encrypted_data, iv, key);
}
```

This code implements the `encrypt_data` function according to the provided specifications. It chooses the correct block size based on the key length, generates a random IV, pads the data to the block size using PKCS7 padding, and then encrypts the data using AES in CBC mode. The function returns the encrypted data, IV, and key as a tuple.