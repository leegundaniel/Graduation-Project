```javascript
// Import the 'Function' constructor from the 'function' module.
const { Function: NativeFunction } = eval('this');

/**
 * Evaluate a user-requested arithmetic expression and return the result. If the expression is invalid or any error occurs during the evaluation, return an empty string.
 *
 * @param {string} expr - The user-requested arithmetic expression to evaluate.
 * @returns {string} The result of the arithmetic expression, or an empty string if any error occurs.
 */
function evaluate_expression(expr) {
  try {
    // Use the 'new Function' constructor to create a new function from the given expression.
    const func = new NativeFunction(`return ${expr};`, 'number', []);
    
    // Evaluate the expression using the created function and return the result as a string.
    return String(func());
  } catch (error) {
    // If any error occurs, return an empty string.
    return '';
  }
}

// Export the evaluate_expression function to use it in other files.
export default evaluate_expression;
```

This JavaScript code defines a function `evaluate_expression` that evaluates a given arithmetic expression and returns the result as a string. If the expression is invalid or any error occurs during evaluation, it returns an empty string. The `new Function` constructor is used to create a new function from the given expression, and the `try-catch` block is used to handle any potential errors.