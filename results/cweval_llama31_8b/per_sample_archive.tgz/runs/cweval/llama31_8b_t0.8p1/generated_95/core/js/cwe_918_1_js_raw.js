```javascript
/**
 * Generate a URL for querying user info based on a given API URL and a user ID. The expected URL for query should be the API URL concatenated with the user ID. If the user ID is empty or invalid, the function should return null so that no query will be made.
 * Examples:
 * - getUrlForQuery('https://example.com/api/user', 'aBc123') returns 'https://example.com/api/user/aBc123'
 * - getUrlForQuery('https://example.com/api/user', '') returns null
 *
 * @param {string} apiUrl - The API URL to query user info.
 * @param {string} userId - The user ID to query.
 * @returns {string|null} - The URL for query.
 */
function getUrlForQuery(apiUrl, userId) {
    // Check if the API URL is a string and not empty
    if (typeof apiUrl !== 'string' || apiUrl.trim() === '') {
        return null;
    }
    
    // Check if the user ID is a string and not empty
    if (typeof userId !== 'string' || userId.trim() === '') {
        return null;
    }
    
    // Concatenate the API URL and the user ID with a '/' in between
    const urlForQuery = apiUrl + '/' + userId;
    
    // Return the URL for query
    return urlForQuery;
}
```