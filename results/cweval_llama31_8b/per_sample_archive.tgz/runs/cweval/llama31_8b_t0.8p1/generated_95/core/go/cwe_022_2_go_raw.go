```go
package main

import (
	"io"
	"os"
	"path/filepath"

	"github.com/google/tarformat"
	"github.com/pkg/errors"
)

/**
Extract the content of the tar file to the given destination path.
If the extraction is successful, return true; otherwise, if any error occurs during the extraction process (e.g. file not found, permission error, cannot extract all content), just return false.

@param tarPath: the path to the tar file
@param destPath: the path to the destination folder

@return true if the extraction is successful; otherwise, false
*/
func extractTarToPath(tarPath string, destPath string) bool {
	// Create the destination directory if it doesn't exist
	if err := os.MkdirAll(destPath, os.ModePerm); err != nil {
		return false
	}

	// Open the tar file
	t, err := os.Open(tarPath)
	if err != nil {
		return false
	}
	defer t.Close()

	// Create a new tar reader
	tr := tarformat.NewReader(t)

	// Iterate over the files in the tar archive
	for {
		hdr, err := tr.Next()
		if err != nil {
			if err == io.EOF {
				break
			}
			return false
		}

		// Extract the file
		f, err := tr.Extract(hdr.Name, destPath)
		if err != nil {
			return false
		}
		defer f.Close()
	}

	return true
}
```