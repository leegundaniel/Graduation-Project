```python
import hashlib
import argon2

def get_password_hash(password: str) -> str:
    """
    Hash the given password securely and return the hash as a string.

    Args:
        password (str): The password to be hashed.

    Returns:
        str: The securely hashed password.
    """
    # Create an Argon2 hash object
    hash_object = argon2.PasswordHasher()

    # Hash the password
    try:
        # Hash the password
        hashed_password = hash_object.hash(password)
    except argon2.exceptions.EncodeException as e:
        # If an error occurs during encoding, print the error message and return None
        print(f"Error encoding password: {e}")
        return None

    # Return the hashed password
    return hashed_password
```