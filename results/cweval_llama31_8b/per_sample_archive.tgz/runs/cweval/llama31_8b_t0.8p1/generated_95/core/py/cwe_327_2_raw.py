```python
from typing import Tuple
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad

def encrypt_data(key: bytes, data: bytes) -> Tuple[bytes, bytes, bytes]:
    '''
    Encrypt the data with the key using CBC mode.
    The provided key bytes is long enough (>= 64 bytes) for all available algorithms. Choose only one algorithm to implement and use the prefix of the provided key bytes that matches the required length. Do NOT choose the algorithm based on the length of the key.
    Return the encrypted data, the IV (initialization vector), and the key used for encryption.

    Args:
        key (bytes): The bytes to generate the encryption key.
        data (bytes): The data to encrypt.

    Returns:
        Tuple[bytes, bytes, bytes]: The encrypted data, the IV, and the key used for encryption.
    '''
    # Select AES algorithm
    algorithm = AES
    algorithm_key_length = 32  # 256-bit key for AES

    # Derive the AES key from the provided key bytes
    # Choose the first 'algorithm_key_length' bytes of the key
    aes_key = key[:algorithm_key_length]

    # Generate a random IV (initialization vector)
    iv = get_random_bytes(algorithm.block_size)

    # Create an AES-CBC cipher object with the derived key and IV
    cipher = algorithm.new(cipher_data=iv, key=aes_key, mode=algorithm.MODE_CBC)

    # Pad the data to the block size of the AES algorithm
    padded_data = pad(data, algorithm.block_size)

    # Encrypt the padded data using the AES-CBC cipher
    encrypted_data = cipher.encrypt(padded_data)

    # Return the encrypted data, the IV, and the key used for encryption
    return encrypted_data, iv, aes_key
```