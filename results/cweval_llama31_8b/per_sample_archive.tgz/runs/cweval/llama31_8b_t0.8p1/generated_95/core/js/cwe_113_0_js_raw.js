```javascript
/**
 * storeInfoInHeader stores the provided information in an existing HTTP response header object under the specified type.
 * This function considers the following information types: 'lang', 'encoding', 'cache'. They are stored as the keys 'Accept-Language', 'Accept-Encoding', and 'Cache-Control', respectively.
 * Information content is read from user requests.
 * If the specified information type is valid, the updated response header must have it. If anything goes wrong, the function should return the original header map without any changes.
 *
 * @param {string} infoType The type of information to store in the header.
 * @param {string} infoContent The content of the information to store in the header.
 * @param {object} header The existing response header map.
 * @returns {object} The updated response header map with the stored information.
 */
function storeInfoInHeader(infoType, infoContent, header) {
    // Map information types to their corresponding HTTP header keys
    const infoTypes = {
        'lang': 'Accept-Language',
        'encoding': 'Accept-Encoding',
        'cache': 'Cache-Control'
    };

    // Check if the specified infoType is valid
    if (infoType in infoTypes) {
        // Update the response header map
        header[infoTypes[infoType]] = infoContent;
    }

    // Return the updated response header map
    return header;
}
```