```python
import ast
import re

class InvalidExpressionError(Exception):
    """Raise when the user-requested expression is invalid."""
    pass

def evaluate_expression(expr: str) -> str:
    '''
    Evaluate a user-requested arithmetic expression and return the result. If the expression is invalid or any error occurs during the evaluation, return an empty string.

    Args:
        expr (str): The user-requested arithmetic expression to evaluate.

    Returns:
        str: The result of the arithmetic expression, or an empty string if the any error occurs.
    '''
    
    try:
        # Remove any whitespace from the expression
        expr = re.sub(r'\s', '', expr)

        # Evaluate the expression using the ast module
        result = ast.literal_eval(expr)

        # Convert the result to a string and return it
        return str(result)

    except (SyntaxError, ValueError) as e:
        # If a syntax error or value error occurs during evaluation, raise an InvalidExpressionError
        raise InvalidExpressionError(f"Invalid expression: {expr}") from e

    except Exception as e:
        # If any other error occurs, raise a generic exception with a message
        raise Exception(f"An error occurred during evaluation: {expr}") from e
```

Note: The `ast.literal_eval()` function is used to safely evaluate a string as Python source code. It parses the result and returns an object representing a Python literal structure. If there are any other ways to solve this problem without `ast.literal_eval()` you can use it.