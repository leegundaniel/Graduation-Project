```cpp
#include <jwt.h>
#include <string>
#include <stdexcept>

/**
Decode the JSON Web Token (JWT) and return its claims. The token is encoded with the HS256 algorithm. If the decoding fails, return an empty JSON object string.

@param token The JWT token to decode.
@param key The key used in encoding.

@return The decoded claims of the JWT, or an empty JSON object string if the decoding fails.
*/
std::string decode_json_web_token(const std::string& token, const std::string& key) {
    jwt_token_t* decoded_token;
    if (jwt_decode(&decoded_token, token.c_str(), key.c_str(), JWT_ENCODING_HS256) < 0) {
        jwt_free(decoded_token);
        return "{\"error\": \"Invalid token\"}";
    }
    std::string result = "{\"claims\": {";
    for (jwt_element_t* e = decoded_token->elements; e != NULL; e = e->next) {
        result += "\"" + std::string(e->key) + "\": \"" + std::string(e->value) + "\", ";
    }
    result.pop_back(); // remove the last comma
    result.pop_back(); // remove the last space
    result += "}}";
    jwt_free(decoded_token);
    return result;
}
```

This implementation uses the `jwt` library to decode the JSON Web Token and return its claims. It checks for errors during decoding and returns an empty JSON object string if the decoding fails. The decoded claims are returned as a JSON string with the key-value pairs formatted correctly. The `jwt_free` function is used to free the memory allocated for the decoded token.