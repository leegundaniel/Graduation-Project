```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <archive.h>
#include <archive_entry.h>
#include <sys/stat.h>
#include <unistd.h>
#include <libgen.h>

#define PATH_MAX 512

/**
 * @brief Check if a directory exists and is accessible.
 * 
 * @param path The directory path to check.
 * 
 * @return true if the directory exists and is accessible; otherwise, false.
 */
bool check_directory(const char *path) {
    struct stat sb;
    return (stat(path, &sb) == 0 && S_ISDIR(sb.st_mode)) ? true : false;
}

/**
 * @brief Create the destination directory if it does not exist.
 */
void create_destination_dir(const char *dest_path) {
    if (!check_directory(dest_path)) {
        if (mkdir(dest_path, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH) == -1) {
            printf("Error creating directory: %s\n", strerror(errno));
            exit(1);
        }
    }
}

/**
 * @brief Create the destination file path if it does not exist.
 * 
 * @param entry The archive entry for the file.
 * 
 * @return true if the file path is created successfully; otherwise, false.
 */
bool create_destination_file(struct archive_entry *entry, const char *dest_path) {
    char full_path[4096];
    snprintf(full_path, sizeof(full_path), "%s/%s",
             dest_path, archive_entry_pathname(entry));
    if (access(full_path, F_OK) == -1) {
        if (mkdir_r(full_path, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH) == -1) {
            printf("Error creating file path: %s\n", strerror(errno));
            return false;
        }
    }
    return true;
}

/**
 * @brief Extract the content of the tar file to the given destination path.
 * If the extraction is successful, return true; otherwise, if any error occurs during the extraction process (e.g. file not found, permission error, cannot extract all content), just return false.
 * 
 * @param tar_path The path to the tar file.
 * @param dest_path The path to the destination folder.
 * 
 * @return true if the extraction is successful; otherwise, false.
 */
bool extract_archive(struct archive *src, const char *dest_path) {
    struct archive *out;
    struct archive_entry *entry;
    int flags = ARCHIVE_EXTRACT_TIME | ARCHIVE_EXTRACT_PERM;
    int r;
    char full_path[4096];

    // Initialize the archive writer
    out = archive_write_disk_new();
    if (!out) {
        return false;
    }
    archive_write_disk_set_options(out, flags);

    // Read and extract each entry
    while ((r = archive_read_next_header(src, &entry)) == ARCHIVE_OK) {
        // Check if the destination directory exists
        if (!check_directory(dest_path)) {
            archive_write_free(out);
            return false;
        }

        // Create full path
        snprintf(full_path, sizeof(full_path), "%s/%s",
                 dest_path, archive_entry_pathname(entry));
        archive_entry_set_pathname(entry, full_path);

        // Check if the destination file path exists
        if (!create_destination_file(entry, dest_path)) {
            archive_write_free(out);
            return false;
        }

        // Write header
        r = archive_write_header(out, entry);
        if (r != ARCHIVE_OK) {
            archive_write_free(out);
            return false;
        }

        // Copy data
        const void *buff;
        size_t size;
        la_int64_t offset;
        while ((r = archive_read_data_block(src, &buff, &size, &offset)) == ARCHIVE_OK) {
            if (archive_write_data_block(out, buff, size, offset) != ARCHIVE_OK) {
                archive_write_free(out);
                return false;
            }
        }
        if (r != ARCHIVE_EOF) {
            archive_write_free(out);
            return false;
        }
    }

    archive_write_free(out);
    return r == ARCHIVE_EOF ? true : false;
}

/**
 * @brief Extract the content of the tar file to the given destination path.
 * If the extraction is successful, return true; otherwise, if any error occurs during the extraction process (e.g. file not found, permission error, cannot extract all content), just return false.
 * 
 * @param tar_path The path to the tar file.
 * @param dest_path The path to the destination folder.
 * 
 * @return true if the extraction is successful; otherwise, false.
 */
bool extract_tar_to_path(const char *tar_path, const char *dest_path) {
    struct archive *archive;
    int r;

    // Open the tar file
    archive = archive_read_new();
    if (!archive) {
        return false;
    }
    archive_read_support_filter_all(archive);
    r = archive_read_open_filename(archive, tar_path, 10240);
    if (r != ARCHIVE_OK) {
        archive_read_free(archive);
        return false;
    }

    // Check if the destination directory exists
    create_destination_dir(dest_path);

    // Extract the archive
    r = extract_archive(archive, dest_path);
    if (r != ARCHIVE_OK) {
        archive_read_free(archive);
        return false;
    }

    archive_read_free(archive);
    return true;
}
```