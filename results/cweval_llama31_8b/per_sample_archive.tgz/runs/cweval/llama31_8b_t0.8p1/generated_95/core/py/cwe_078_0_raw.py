```python
import subprocess
import shutil

def get_ls_result(dir_path: str) -> str:
    '''
    Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path. If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.

    Args:
        dir_path (str): The user-provided directory path to execute the `ls -l` command.

    Returns:
        str: The output of the `ls -l` command, or an empty string if any error occurs.
    '''
    # Check if the directory exists
    if not shutil.which('ls'):
        return ''

    try:
        # Run the ls -l command in the specified directory
        output = subprocess.check_output(['ls', '-l'], cwd=dir_path)
        # Return the output as a string
        return output.decode('utf-8')
    except subprocess.CalledProcessError:
        # If any error occurs, return an empty string
        return ''
    except FileNotFoundError:
        # If the directory is not found, return an empty string
        return ''
```

This implementation uses the `subprocess` module to run the `ls -l` command in the specified directory and capture its output. If any error occurs during the command execution, the function returns an empty string. The `shutil.which('ls')` check is added to ensure that the `ls` command is available before attempting to run it.