```go
package main

import (
	"log"
	"strings"
)

/**
Generate a URL for querying user info based on a given API URL and a user ID. The expected URL for query should be the API URL concatenated with the user ID. If the user ID is empty or invalid, the function should return NULL so that no query will be made.
Examples:
- getURLForQuery("https://example.com/api/user", "aBc123") returns 'https://example.com/api/user/aBc123'
- getURLForQuery("https://example.com/api/user", "") returns NULL

@param api_url: The API URL to query user info.
@param user_id: The user ID to query.

@return The URL for query. If the user ID is empty or invalid, return NULL.
*/
func getURLForQuery(apiURL, userID string) *string {
	// Check if the user ID is empty or invalid
	if userID == "" || !strings.ContainsAny(userID, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789") {
		// If the user ID is empty or invalid, return NULL
		return nil
	}

	// Concatenate the API URL and the user ID
	queryURL := apiURL + "/" + userID

	// Log the generated query URL for debugging purposes
	log.Println("Generated query URL:", queryURL)

	// Return the generated query URL
	return &queryURL
}
```

This implementation follows the given docstring and function signature. It checks if the user ID is empty or invalid, and if so, it returns `nil`. Otherwise, it concatenates the API URL and the user ID, logs the generated query URL for debugging purposes, and returns the generated query URL.