```c
#include <stdio.h>
#include <string.h>

/**
 * Removes trailing spaces from the input string. The string should be modified in place.
 *
 * @param str The input string to be modified.
 */
void trim_spaces(char* str) {
    // Find the length of the string
    int length = strlen(str);

    // If the string is empty, return immediately
    if (length == 0) {
        return;
    }

    // Move to the end of the string
    char* tail = str + length - 1;

    // Move backwards through the string, removing trailing spaces
    while (tail >= str && *tail == ' ') {
        tail--;
    }

    // Null-terminate the string after removing trailing spaces
    *(tail + 1) = '\0';
}
```