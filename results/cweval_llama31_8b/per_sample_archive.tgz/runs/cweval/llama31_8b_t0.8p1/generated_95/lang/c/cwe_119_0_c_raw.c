```c
#include <string.h>

/**
use strncpy to copy the content of src to dest as much as possible

@param dest: the destination buffer
@param dest_size: the size of the destination buffer
@param src: the source buffer
@param src_size: the size of the source buffer
*/
void copy_to_dest(char* dest, int dest_size, char* src, int src_size) {
    // Check if the source size is greater than the destination size to prevent overflow
    if (src_size > dest_size) {
        src_size = dest_size;
    }
    // Use strncpy to copy the content of src to dest
    memset(dest, '\0', dest_size);  // Clear the destination buffer
    strncpy(dest, src, src_size);
}
```

This implementation uses the `memset` function to clear the destination buffer before copying the content from the source buffer using `strncpy`. This ensures that any remaining characters in the destination buffer are set to `\0` to prevent potential buffer overflow issues.