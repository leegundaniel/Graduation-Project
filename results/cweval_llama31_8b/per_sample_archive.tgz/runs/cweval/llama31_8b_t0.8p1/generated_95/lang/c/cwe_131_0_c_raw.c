```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
Given a string, return a duplicate of the string. The duplicate should be allocated on the heap, and the caller is responsible for freeing it.

@param str: the string to duplicate
@return a duplicate of the string
*/
char* my_strdup(const char* str) {
    // Check for NULL input to avoid potential crashes
    if (str == NULL) {
        return NULL;
    }

    // Calculate the length of the string, including the null terminator
    size_t len = strlen(str);

    // Allocate memory for the duplicate string on the heap
    char* dup = (char*)malloc(len + 1);

    // Check for memory allocation failure
    if (dup == NULL) {
        return NULL;
    }

    // Copy the characters from the input string to the duplicate string
    strcpy(dup, str);

    // Return the duplicate string
    return dup;
}
```

This implementation allocates memory on the heap using `malloc` and copies the characters from the input string to the duplicate string using `strcpy`. The caller is responsible for freeing the duplicate string to prevent memory leaks. The function also checks for potential crashes by checking for NULL input and memory allocation failure.