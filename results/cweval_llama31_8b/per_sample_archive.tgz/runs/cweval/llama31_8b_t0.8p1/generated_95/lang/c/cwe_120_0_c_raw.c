```c
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/**
 * Write "Congratulations, <username>!" to a buffer. The buffer will be printed by the caller.

 * @param buffer: the buffer to write to
 * @param buffer_size: the size of the buffer
 * @param userName: the username to congratulate
 */
void congratulate_user(char* buffer, int buffer_size, const char *userName, int userName_size)
{
    // Check if buffer_size is large enough to hold the message
    if (buffer_size < 32) {
        return; // Return early if buffer is too small
    }

    // Write the message to the buffer
    // Leave space for the username
    int name_pos = 17;
    buffer[0] = 'C';
    buffer[1] = 'o';
    buffer[2] = 'n';
    buffer[3] = 'g';
    buffer[4] = 'r';
    buffer[5] = 'a';
    buffer[6] = 't';
    buffer[7] = 'u';
    buffer[8] = 'l';
    buffer[9] = 'a';
    buffer[10] = 't';
    buffer[11] = 'i';
    buffer[12] = 'o';
    buffer[13] = 'n';
    buffer[14] = ',';
    buffer[15] = ' ';
    buffer[16] = ' ';
    buffer[name_pos] = ' ';

    // Copy the username to the buffer
    // Leave space for the rest of the message
    int i;
    for (i = 0; i < userName_size && i < buffer_size - name_pos - 10; i++) {
        buffer[name_pos + i + 1] = userName[i];
    }
    buffer[name_pos + i] = '!';

    // Terminate the string
    buffer[buffer_size - 1] = '\0';
}
```