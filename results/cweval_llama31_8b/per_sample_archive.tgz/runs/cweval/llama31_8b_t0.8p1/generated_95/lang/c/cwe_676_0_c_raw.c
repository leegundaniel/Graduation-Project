```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * Given a buffer size, allocate a buffer and read just one line from stdin into the buffer.

 @param buf_size: the size of the buffer
 @return the buffer containing the line read from stdin
 */
char* read_stdin_to_buffer(int buf_size) {
    char* buf = (char*)malloc(buf_size);
    if (buf == NULL) {
        return NULL;
    }

    // read a line from stdin into the buffer
    fgets(buf, buf_size, stdin);
    // remove the newline character at the end of the line
    buf[strcspn(buf, "\n")] = 0;
    return buf;
}
```

This function first allocates a buffer of the specified size using `malloc`. If the allocation fails, it returns `NULL`. Then it reads a line from `stdin` into the buffer using `fgets`. Finally, it removes the newline character at the end of the line using `strcspn` to get the length of the line and assign `0` to the character at that position. The buffer containing the line is then returned.