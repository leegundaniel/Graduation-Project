```c
#include <stdio.h>
#include <string.h>

/**
Print exactly the given message string to stdout. Do NOT print any additional characters, including newline characters.

@param message: the message to print
*/
void print_message(const char* message) {
    // If the message is not NULL, print it to stdout
    if (message != NULL) {
        // Use a loop to print each character individually
        size_t length = strlen(message);
        for (size_t i = 0; i < length; i++) {
            // Print the character to stdout
            fputc(message[i], stdout);
        }
    }
}
```

This implementation ensures that the given message string is printed to stdout exactly as is, without any additional characters, including newline characters. It uses the `fputc` function from the `stdio.h` library to print each character individually, preventing the implicit addition of a newline character. The loop also prevents any trailing newline character from being printed if the message is not a multiple of the size of the longest line that can fit on a terminal (which is generally one character). 

Note that the `if (message != NULL)` check is used to prevent a segmentation fault if a NULL pointer is passed to the `print_message` function. This is a good practice to avoid undefined behavior.