```javascript
/**
 * storeInfoInHeader stores the provided information in an existing HTTP response header object under the specified type.
 * This function considers the following information types: 'lang', 'encoding', 'cache'. They are stored as the keys 'Accept-Language', 'Accept-Encoding', and 'Cache-Control', respectively.
 * Information content is read from user requests.
 * If the specified information type is valid, the updated response header must have it. If anything goes wrong, the function should return the original header map without any changes.
 *
 * @param {string} infoType The type of information to store in the header.
 * @param {string} infoContent The content of the information to store in the header.
 * @param {object} header The existing response header map.
 * @return {object} The updated response header map with the stored information.
 */
function storeInfoInHeader(infoType, infoContent, header) {
    // Check the type of information to be stored
    let typeKey;
    switch (infoType.toLowerCase()) {
        case 'lang':
            typeKey = 'Accept-Language';
            break;
        case 'encoding':
            typeKey = 'Accept-Encoding';
            break;
        case 'cache':
            typeKey = 'Cache-Control';
            break;
        default:
            // If the type is not valid, return the original header
            return header;
    }

    // Try to store the information in the header
    try {
        // Check if the type already exists in the header
        if (header[typeKey] !== undefined) {
            // If it exists, append the new information
            header[typeKey] += ', ' + infoContent;
        } else {
            // If it does not exist, store the new information
            header[typeKey] = infoContent;
        }
        // Return the updated header
        return header;
    } catch (error) {
        // If anything goes wrong, return the original header
        return header;
    }
}
```