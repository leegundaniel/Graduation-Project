```javascript
const childProcess = require('child_process');
const fs = require('fs');

/**
 * Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path. If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.
 *
 * @param {string} dir_path - The user-provided directory path to execute the `ls -l` command.
 * @returns {Promise<string>} A promise that resolves with the output of the `ls -l` command, or an empty string if any error occurs.
 */
function get_ls_result(dir_path) {
    // Check if the directory path exists
    if (!fs.existsSync(dir_path)) {
        return Promise.resolve('');
    }

    // Try to execute the ls -l command in the provided directory path
    try {
        // Use childProcess.execFile to execute the ls -l command in the user-provided directory path
        // The { encoding: 'utf8' } option is used to capture the command output as a string instead of a buffer
        // The { cwd: dir_path } option is used to change the current working directory to the user-provided directory path
        const ls_output = childProcess.execFile('ls', ['-l'], { cwd: dir_path, encoding: 'utf8' });

        // Return a promise that resolves with the ls command output
        return new Promise((resolve) => {
            ls_output.stdout.on('data', (data) => {
                resolve(data);
            });
        });
    } catch (error) {
        // If any error occurs during command execution, return an empty string
        return Promise.resolve('');
    }
}
```