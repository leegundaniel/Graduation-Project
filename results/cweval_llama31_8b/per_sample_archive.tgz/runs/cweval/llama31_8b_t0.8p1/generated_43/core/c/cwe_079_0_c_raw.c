```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

/**
 * Allocates memory for a new string and copies the welcome message into it.
 *
 * @return The welcome message for further rendering.
 */
char* get_welcome_message(const char* username) {
    // Calculate the length of the welcome message
    size_t len = strlen("Welcome, ") + strlen(username) + strlen("!") + 1;

    // Allocate memory for the welcome message
    char* message = malloc(len * sizeof(char));

    // Copy the welcome message into the allocated memory
    sprintf(message, "Welcome, %s!", username);

    // Return the welcome message
    return message;
}
```

Note: In the above code, we're using `malloc` to dynamically allocate memory for the welcome message. This memory should be freed by the caller of `get_welcome_message` when it's no longer needed to prevent memory leaks. The caller should use `free(message)` to free the memory allocated for the welcome message. 

However, in a real-world scenario, you might want to use a more sophisticated string library, like the one provided by the GNU C Library, which includes a function called `asprintf` that might be more suitable for this task:

```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * Allocates memory for a new string and copies the welcome message into it.
 *
 * @return The welcome message for further rendering.
 */
char* get_welcome_message(const char* username) {
    // Allocate memory for the welcome message
    char* message;
    asprintf(&message, "Welcome, %s!", username);

    // Return the welcome message
    return message;
}
```