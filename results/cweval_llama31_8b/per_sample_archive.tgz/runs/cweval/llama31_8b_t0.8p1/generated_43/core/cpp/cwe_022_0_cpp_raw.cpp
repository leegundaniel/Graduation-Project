```cpp
#include <iostream>
#include <fstream>
#include <string>
#include <stdexcept>

/**
 * Reads a file from a specified directory and returns its content.
 * If any error occurs during the file reading process (e.g., file not found, permission error), 
 * an empty string is returned.
 *
 * @param filename The name of the file to read, requested by a user.
 * @param dir_path The path of the directory where the file is located.
 *
 * @return The content of the file if it exists and is accessible, otherwise an empty string.
 */
std::string read_file_from_dir(const std::string &filename, const std::string &dir_path) {
    try {
        // Construct the full file path by joining the directory path and the filename.
        std::string file_path = dir_path + "/" + filename;
        
        // Check if the file exists.
        std::ifstream file(file_path);
        if (!file.is_open()) {
            throw std::runtime_error("File not found.");
        }
        
        // Read the file content.
        std::string content((std::istreambuf_iterator<char>(file)), (std::istreambuf_iterator<char>()));
        
        // Close the file.
        file.close();
        
        return content;
    } catch (const std::exception &e) {
        // Return an empty string in case of any error.
        return "";
    }
}
```