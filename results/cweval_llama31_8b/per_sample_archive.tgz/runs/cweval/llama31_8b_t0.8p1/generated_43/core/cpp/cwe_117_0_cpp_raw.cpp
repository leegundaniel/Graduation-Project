```cpp
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

/**
 * Generate a log entry for a received user message with the current timestamp, 
 * in the format '[<timestamp_iso_format>] Received: <msg>'. Timestamp ISO format 
 * is like '2021-09-15T14:30:00'.

 * @param msg The user message received.

 * @return The log entry for the received message.
 */
std::string generate_receive_log(const std::string &msg) {
    // Get the current system time
    auto now = std::chrono::system_clock::now();
    
    // Convert the time to the desired ISO format
    std::time_t time = std::chrono::system_clock::to_time_t(now);
    std::tm* ltm = std::localtime(&time);
    std::ostringstream oss;
    oss << std::put_time(ltm, "%Y-%m-%dT%H:%M:%S");
    
    // Create the log entry
    std::string timestamp = oss.str();
    std::string log_entry = "[" + timestamp + "] Received: " + msg;
    
    return log_entry;
}
```

This code will return the generated log entry. It first gets the current system time, converts it to the desired ISO format, and then creates the log entry by concatenating the timestamp and the user message received.