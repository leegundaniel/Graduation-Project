```go
package main

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
)

// Encrypt the data with the key using CBC mode.
// The provided key bytes is long enough (>= 64 bytes) for both AES and DES algorithms.
// Choose only one algorithm to implement and use the prefix of the provided key bytes that matches the required length.
// Do NOT choose the algorithm based on the length of the key.
// Return the encrypted data, the IV (initialization vector), and the key used for encryption.
// Arguments:
// - key: The bytes to generate the encryption key.
// - data: The data to encrypt.
// Return:
// - The encrypted data, the IV, and the key used for encryption. (encryptedData, iv, aesKey, error)
func encryptData(key, data []byte) ([]byte, []byte, []byte, error) {
	// Generate a SHA-256 hash of the key to create the AES key
	aesKey := sha256.Sum256(key[:32]) // AES key size is 256 bits (32 bytes)

	// Generate a random 128-bit initialization vector (IV)
	iv := make([]byte, 16) // AES block size is 128 bits (16 bytes)
	if _, err := rand.Read(iv); err != nil {
		return nil, nil, nil, err
	}

	block, err := aes.NewCipher(aesKey[:])
	if err != nil {
		return nil, nil, nil, err
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, nil, nil, err
	}

	// Encrypt the data in CBC mode
	encryptedData := gcm.Seal(nil, iv, data, nil)

	return encryptedData, iv, aesKey[:], nil
}
```