```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

/**
 * Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path. 
 * If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.

 * @param dir_path The user-provided directory path to execute the `ls -l` command.

 * @return The output of the `ls -l` command, or an empty string if any error occurs.
 */
char *get_ls_result(const char *dir_path) {
    // Create a pipe to redirect stdout of the ls command to our program
    int pipe_fd[2];
    if (pipe(pipe_fd) == -1) {
        perror("pipe");
        return NULL;
    }

    // Fork a new process to execute the ls command
    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        close(pipe_fd[0]);
        close(pipe_fd[1]);
        return NULL;
    }

    if (pid == 0) {
        // Child process, close the writing end of the pipe and redirect stdout to the pipe
        close(pipe_fd[1]);
        dup2(pipe_fd[0], STDOUT_FILENO);
        close(pipe_fd[0]);

        // Change directory to the user-provided path
        if (chdir(dir_path) == -1) {
            return NULL;
        }

        // Execute the ls -l command
        execl("/bin/ls", "ls", "-l", NULL);
        perror("execl");
        exit(1);
    }

    // Parent process, close the reading end of the pipe
    close(pipe_fd[0]);

    // Read the output of the ls command from the pipe
    char buffer[1024];
    ssize_t size = read(pipe_fd[1], buffer, 1024);
    if (size == -1) {
        perror("read");
        close(pipe_fd[1]);
        return NULL;
    }
    buffer[size] = '\0';

    // Close the writing end of the pipe
    close(pipe_fd[1]);

    // Wait for the child process to finish
    wait(NULL);

    // Return the output of the ls command
    return strdup(buffer);
}
```

Note: This code uses the `strdup` function to duplicate the output string. Don't forget to `free` the returned string when you're done with it to avoid memory leaks.