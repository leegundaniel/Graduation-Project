```c
#include <openssl/aes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

// Structure to hold the return values
typedef struct {
    unsigned char* encrypted_data;
    size_t encrypted_len;
    unsigned char* iv;
    unsigned char* key;
} encryption_result;

/**
Encrypt the data with the key using AES and CBC mode.
The provided key bytes is long enough (>= 64 bytes). Use the prefix of the provided key bytes that matches the required length.
Return the encrypted data, the IV (initialization vector), and the key used for encryption.

@param key The bytes to generate the encryption key.
@param data The data to encrypt.

@return The encrypted data, the IV, and the key used for encryption.
*/
encryption_result encrypt_data(
    const unsigned char* key, size_t key_len,
    const unsigned char* data, size_t data_len
) {
    // Calculate the AES key length and the AES block size
    unsigned int key_len_aes = 16; // AES-128
    unsigned int block_size = 16;

    // Create an AES encryption context
    AES_KEY aes_key;
    AES_set_encrypt_key(key, key_len_aes * 8, &aes_key);

    // Initialize the AES counter
    unsigned char iv[block_size];
    unsigned int iv_offset = 0;
    unsigned char* encrypted_data = NULL;
    size_t encrypted_len = 0;

    // Encrypt the data
    while (data_len > 0) {
        // Get the number of blocks to encrypt in the current iteration
        unsigned int num_blocks = (data_len < block_size) ? data_len : block_size;

        // Encrypt the data
        unsigned char* block = malloc(block_size);
        memcpy(block, data, num_blocks);
        AES_encrypt(block, block, &aes_key);

        // Update the IV and the encrypted data
        for (unsigned int i = 0; i < num_blocks; ++i) {
            iv[iv_offset + i] = block[i];
        }
        iv_offset += num_blocks;

        // Update the encrypted data length
        encrypted_len += block_size;

        // Allocate memory for the encrypted data
        if (encrypted_data == NULL) {
            encrypted_data = malloc(encrypted_len);
        }

        // Copy the encrypted data
        memcpy(encrypted_data + (encrypted_len - block_size), block, block_size);

        // Update the data
        data += num_blocks;
        data_len -= num_blocks;

        // Free the block memory
        free(block);
    }

    // Allocate memory for the IV and the key
    unsigned char* iv_copy = malloc(block_size);
    unsigned char* key_copy = malloc(key_len_aes);

    // Copy the IV and the key
    memcpy(iv_copy, iv, block_size);
    memcpy(key_copy, key, key_len_aes);

    // Create the return structure
    encryption_result result;
    result.encrypted_data = encrypted_data;
    result.encrypted_len = encrypted_len;
    result.iv = iv_copy;
    result.key = key_copy;

    return result;
}
```