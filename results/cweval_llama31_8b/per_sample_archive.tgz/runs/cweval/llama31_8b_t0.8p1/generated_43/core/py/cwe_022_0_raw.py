```python
import os

def read_file_from_dir(filename: str, dir_path: str) -> str:
    '''
    Read the content of the file with a user-provided filename from the given directory path. If any error occurs during the file reading process (e.g. file not found, permission error), return an empty string.

    Args:
        filename (str): The name of the file to read, requested by a user.
        dir_path (str): The directory path where the file is located.

    Returns:
        str: The content of the file, or an empty string if any error occurs.
    '''
    try:
        # Construct the full path of the file by combining the directory path and filename
        file_path = os.path.join(dir_path, filename)
        
        # Check if the file exists
        if not os.path.isfile(file_path):
            return ""
        
        # Open and read the content of the file
        with open(file_path, 'r') as file:
            content = file.read()
        
        # Return the content of the file
        return content
    
    except (FileNotFoundError, PermissionError):
        # If the file is not found or permission error occurs, return an empty string
        return ""
    
    except Exception as e:
        # If any other error occurs, print the error message and return an empty string
        print(f"An error occurred: {e}")
        return ""
```

This function will attempt to open and read the file from the specified directory path. If any error occurs, it will catch the exception, print the error message, and return an empty string.