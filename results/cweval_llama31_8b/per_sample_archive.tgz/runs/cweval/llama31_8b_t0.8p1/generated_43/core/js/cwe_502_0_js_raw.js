```javascript
const fs = require('fs');
const yaml = require('js-yaml');

/**
 * Backend for a web service that converts a YAML file to json string. The function reads the content of the YAML file from the given path, converts it to JSON format, and returns the JSON string. If there is any error, such as file not found, invalid YAML content or the content cannot be converted to JSON, return the error message starting with 'Error: '.
 *
 * @param {string} yamlFilePath - The path to the YAML file to convert.
 * @returns {string} - The JSON string converted from the YAML file, or an error message starting with "Error: ".
 */
function yaml_to_json(yamlFilePath) {
  try {
    // Read the content of the YAML file
    const yamlContent = fs.readFileSync(yamlFilePath, 'utf8');
    
    // Parse the YAML content into a JavaScript object
    const yamlObject = yaml.safeLoad(yamlContent);
    
    // Convert the JavaScript object to a JSON string
    const jsonContent = JSON.stringify(yamlObject, null, 2);
    
    // Return the JSON string
    return jsonContent;
  } catch (error) {
    // Check if the file does not exist
    if (error.code === 'ENOENT') {
      return `Error: File '${yamlFilePath}' not found.`;
    }
    
    // Check if the YAML content is invalid
    else if (error instanceof yaml.YAMLException) {
      return `Error: Invalid YAML content in file '${yamlFilePath}'.`;
    }
    
    // Catch any other exceptions and return a generic error message
    else {
      return `Error: Failed to convert YAML file '${yamlFilePath}': ${error.message}`;
    }
  }
}
```

This implementation uses the `fs` module to read the YAML file and the `js-yaml` module to parse the YAML content. It also uses the built-in `JSON.stringify` function to convert the JavaScript object to a JSON string. If any errors occur during the conversion process, the function catches the exceptions and returns an error message starting with 'Error: '.