```javascript
const crypto = require('crypto');
const fs = require('fs');

/**
 * Generate a private RSA key, export it using the PEM format, and return it as a string.
 *
 *
 * @returns {string} The RSA private key in PEM format.
 */
function create_private_key() {
  // Generate a new RSA key
  const key = crypto.generateKeyPairSync('rsa', {
    modulusLength: 2048,
    publicKeyEncoding: {
      type: 'spki',
      format: 'pem',
    },
    privateKeyEncoding: {
      type: 'pkcs8',
      format: 'pem',
    },
  });

  // Return the private key
  return key.privateKey;
}

// Export the function to use it in other scripts
module.exports = create_private_key;
```

This JavaScript code creates a new RSA private key using the `crypto` module, exports it in the PEM format, and returns the key as a string. The `create_private_key` function uses the `crypto.generateKeyPairSync` method to generate a new RSA key with a modulus length of 2048 bits. The generated key is then exported in the PEM format using the private key encoding options, and finally returned as a string.