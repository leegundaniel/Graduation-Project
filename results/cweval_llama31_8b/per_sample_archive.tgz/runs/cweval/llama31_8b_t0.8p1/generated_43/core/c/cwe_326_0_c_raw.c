```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

// Function to execute a system command and capture its output
char *execute_command(const char *command) {
    FILE *pipe = popen(command, "r");
    if (!pipe) return NULL;

    char buffer[128];
    char *output = NULL;
    size_t len = 0;

    while (fgets(buffer, sizeof(buffer), pipe)) {
        len += strlen(buffer);
        output = realloc(output, len + 1);
        if (!output) return NULL;
        strcat(output, buffer);
    }

    pclose(pipe);
    output[len] = '\0'; // Null-terminate the string
    return output;
}

// Function to create a private RSA key
char *create_private_key() {
    char *command = malloc(strlen("openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 2>/dev/null") + 1);
    strcpy(command, "openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 2>/dev/null");
    char *output = execute_command(command);
    free(command);
    return output;
}
```

This implementation uses the `popen` function to execute the OpenSSL command and capture its output. It also includes error checking and memory management to ensure that the function behaves correctly and safely. Note that the `execute_command` function returns `NULL` on error, and it is assumed that the caller will check for this condition.