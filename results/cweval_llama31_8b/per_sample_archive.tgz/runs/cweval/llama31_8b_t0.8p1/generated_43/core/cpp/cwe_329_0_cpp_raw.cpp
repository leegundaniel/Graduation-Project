```cpp
#include <openssl/aes.h>
#include <openssl/rand.h>
#include <stdexcept>
#include <vector>
#include <tuple>

// Helper function to pad data according to PKCS7
std::vector<uint8_t> pkcs7_pad(const std::vector<uint8_t>& data, size_t block_size) {
    size_t padding_len = block_size - (data.size() % block_size);
    std::vector<uint8_t> padded = data;
    padded.insert(padded.end(), padding_len, static_cast<uint8_t>(padding_len));
    return padded;
}

/**
Encrypt the data with the key using AES and CBC mode.
The provided key bytes is long enough (>= 64 bytes). Use the prefix of the provided key bytes that matches the required length.
Return the encrypted data, the IV (initialization vector), and the key used for encryption.

@param key The bytes to generate the encryption key
@param data The data to encrypt
@return tuple containing: {encrypted data, IV, key used for encryption}
*/
std::tuple<std::vector<uint8_t>, std::vector<uint8_t>, std::vector<uint8_t>>
encrypt_data(const std::vector<uint8_t>& key, const std::vector<uint8_t>& data) {
    // The key must be at least 16 bytes long for AES128, AES192, or AES256
    if (key.size() < 16) {
        throw std::invalid_argument("The provided key is too short (must be >= 16 bytes)");
    }

    // Select the key length based on the key size
    size_t key_len = key.size();
    if (key_len == 16) {
        // AES128
        AES_KEY* aes_key = new AES_KEY;
        AES_set_encrypt_key(key.data(), 128, aes_key);
    } else if (key_len == 24) {
        // AES192
        AES_KEY* aes_key = new AES_KEY;
        AES_set_encrypt_key(key.data(), 192, aes_key);
    } else if (key_len == 32) {
        // AES256
        AES_KEY* aes_key = new AES_KEY;
        AES_set_encrypt_key(key.data(), 256, aes_key);
    } else {
        // Default to AES256
        AES_KEY* aes_key = new AES_KEY;
        AES_set_encrypt_key(key.data(), 256, aes_key);
    }

    // Generate a random IV (initialization vector)
    std::vector<uint8_t> iv(16);
    RAND_bytes(iv.data(), iv.size());

    // Encrypt the padded data
    std::vector<uint8_t> padded_data = pkcs7_pad(data, 16);
    std::vector<uint8_t> encrypted_data(encrypted_data.size() + padded_data.size());
    AES_cbc_encrypt(padded_data.data(), encrypted_data.data(), padded_data.size(), aes_key, iv.data(), AES_ENCRYPT);

    // Return the encrypted data, the IV, and the key used for encryption
    delete aes_key;
    return std::make_tuple(encrypted_data, iv, key);
}
```