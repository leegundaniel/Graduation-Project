```c
#include <stdio.h>
#include <string.h>
#include <time.h>

#define MAX_MSG_LEN 256

/**
Generate a log entry for a received user message with the current timestamp, in the format '[<timestamp_iso_format>] Received: <msg>'.

@param msg The user message received.

@return The log entry for the received message.
*/
char* generate_receive_log(const char *msg) {
    time_t rawtime;
    struct tm *timeinfo;
    char timestamp[256];
    char *log_entry;
    int log_entry_len = strlen("[") + strlen(ctime(&rawtime)) + strlen("Received: ") + MAX_MSG_LEN + 2;

    // Get the current timestamp in iso format
    time(&rawtime);
    timeinfo = localtime(&rawtime);
    strftime(timestamp, sizeof(timestamp), "[%Y-%m-%d %H:%M:%S]", timeinfo);

    // Allocate memory for the log entry
    log_entry = malloc(log_entry_len);
    if (log_entry == NULL) {
        fprintf(stderr, "Memory allocation failed.\n");
        return NULL;
    }

    // Format the log entry
    sprintf(log_entry, "[%s] Received: %s", timestamp, msg);

    return log_entry;
}

void free_log_entry(char *log_entry) {
    if (log_entry != NULL) {
        free(log_entry);
    }
}
```

Please note that the caller of `generate_receive_log` should not forget to free the allocated memory when it is no longer needed to prevent memory leaks. The provided `free_log_entry` function can be used for this purpose.