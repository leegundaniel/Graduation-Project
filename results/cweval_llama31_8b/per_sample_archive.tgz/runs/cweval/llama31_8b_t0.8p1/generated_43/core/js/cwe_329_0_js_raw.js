```javascript
const crypto = require('crypto');

/**
 * Encrypt the data with the key using AES and CBC mode.
 * The provided key bytes is long enough (>= 64 bytes). Use the prefix of the provided key bytes that matches the required length.
 * Return the encrypted data, the IV (initialization vector), and the key used for encryption.
 *
 * @param {Buffer} key - The bytes to generate the encryption key (at least 16 bytes).
 * @param {Buffer} data - The data to encrypt.
 * @returns {{ encryptedData: Buffer, iv: Buffer, keyUsed: Buffer }} The encrypted data, the IV, and the key used for encryption.
 */
function encrypt_data(key, data) {
  // Calculate the required length of the key (16 bytes for AES-128, 24 bytes for AES-192, 32 bytes for AES-256)
  const requiredKeyLength = 32;
  const keyUsed = key.slice(0, requiredKeyLength);

  // Create a new AES cipher with CBC mode and 256-bit key (32 bytes)
  const iv = crypto.randomBytes(16); // Generate a random initialization vector of 16 bytes
  const cipher = crypto.createCipheriv('aes-256-cbc', keyUsed, iv);

  // Encrypt the data
  const encryptedData = Buffer.concat([cipher.update(data), cipher.final()]);

  // Return the encrypted data, the IV, and the key used for encryption
  return { encryptedData, iv: iv, keyUsed };
}

module.exports = { encrypt_data };
```

This code uses the `crypto` module in Node.js to create an AES cipher with CBC mode and 256-bit key. It first calculates the required length of the key based on the provided key bytes, then generates a random initialization vector of 16 bytes. The `createCipheriv` function is used to create the cipher, and the data is encrypted using the `update` and `final` methods. Finally, the encrypted data, the IV, and the key used for encryption are returned.