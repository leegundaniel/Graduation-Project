```cpp
#include <iostream>
#include <fstream>
#include <stdexcept>
#include <string>
#include <stdexcept>

// Function to execute a system command and return its output as a string
std::string executeCommand(const std::string& command) {
    std::string output;
    FILE* pipe = popen(command.c_str(), "r");
    if (!pipe) {
        return "Error executing command";
    }

    char buffer[128];
    while (!feof(pipe)) {
        if (fgets(buffer, 128, pipe) != NULL) {
            output += buffer;
        }
    }

    pclose(pipe);
    if (output.empty()) {
        return "Error executing command";
    }
    return output;
}

// Function to execute the OpenSSL command to generate the private key
std::string generatePrivateKey(int keyLength) {
    std::string command = "openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:" + std::to_string(keyLength) + " 2>/dev/null";
    return executeCommand(command);
}

/**
Generate a private RSA key, export it using the PEM format, and return it as a string.
Execute the command "openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:<key_length> 2>/dev/null" to generate the key.

@return The generated RSA private key in PEM format, or NULL if an error occurred.
*/
std::string create_private_key() {
    int keyLength = 2048; // Default key length
    try {
        std::string privateKey = generatePrivateKey(keyLength);
        if (privateKey.empty()) {
            return "Error generating private key";
        }
        return privateKey;
    } catch (const std::exception& e) {
        return "Error generating private key: " + std::string(e.what());
    }
}
```

Note that the `executeCommand` function is used to execute the OpenSSL command and capture its output, and the `generatePrivateKey` function is a helper function that generates the private key using OpenSSL. The `create_private_key` function is the main function that returns the generated private key in PEM format. It also includes error handling to catch any exceptions that may occur during key generation.