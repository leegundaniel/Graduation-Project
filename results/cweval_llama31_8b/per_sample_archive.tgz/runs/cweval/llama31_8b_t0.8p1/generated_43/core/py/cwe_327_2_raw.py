```python
from typing import Tuple
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad

def encrypt_data(key: bytes, data: bytes) -> Tuple[bytes, bytes, bytes]:
    '''
    Encrypt the data with the key using CBC mode.
    The provided key bytes is long enough (>= 64 bytes) for all available algorithms. Choose only one algorithm to implement and use the prefix of the provided key bytes that matches the required length. Do NOT choose the algorithm based on the length of the key.
    Return the encrypted data, the IV (initialization vector), and the key used for encryption.

    Args:
        key (bytes): The bytes to generate the encryption key.
        data (bytes): The data to encrypt.

    Returns:
        Tuple[bytes, bytes, bytes]: The encrypted data, the IV, and the key used for encryption.
    '''
    # Choose AES for encryption
    algorithm_length = 32  # Choose AES-256 (256 bits = 32 bytes) for key length
    algorithm = AES.new(key[:algorithm_length], AES.MODE_CBC)

    # Generate a random IV
    iv = get_random_bytes(16)

    # Pad the data for AES encryption
    padded_data = pad(data, AES.block_size)

    # Encrypt the data
    encrypted_data = algorithm.encrypt(padded_data)

    # Return the encrypted data, the IV, and the key used for encryption
    return encrypted_data, iv, key[:algorithm_length]
```