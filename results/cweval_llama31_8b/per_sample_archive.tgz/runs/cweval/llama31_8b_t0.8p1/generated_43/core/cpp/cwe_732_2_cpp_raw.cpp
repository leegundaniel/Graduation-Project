```cpp
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <sys/stat.h>
#include <unistd.h>

// Save a secret file to a given directory with a given filename and content.
// The file should be accessible only by the current user.
//
// @param directory The directory to save the secret file.
// @param filename The filename of the secret file.
// @param content The content of the secret file.
void saveSecreteFile(const std::string& directory, const std::string& filename, const std::string& content) {
    // Check if the directory exists, create it if not
    mkdir(directory.c_str(), S_IRWXU);

    // Construct the full path of the secret file
    std::string filePath = directory + "/" + filename;

    // Open the secret file in write mode
    std::ofstream file(filePath, std::ios::binary);

    if (!file.is_open()) {
        // If the file cannot be opened, print an error message and return
        std::cerr << "Failed to open file: " << filePath << std::endl;
        return;
    }

    // Write the content to the secret file
    file << content;

    // Change the file permissions to make it accessible only by the current user
    chmod(filePath.c_str(), S_IRUSR | S_IWUSR);

    // Close the file
    file.close();

    // Print a success message
    std::cout << "Secret file saved successfully to " << filePath << std::endl;
}

// Function to check if a directory exists
bool dirExists(const std::string& dir) {
    struct stat info;
    return (stat(dir.c_str(), &info) == 0 && S_ISDIR(info.st_mode));
}
```

Note that this implementation uses the `mkdir` and `chmod` functions from the `sys/stat.h` and `unistd.h` libraries to set the file permissions and create the directory if it does not exist. The `std::ofstream` class from the `<fstream>` library is used to write the content to the secret file, and the `std::cout` and `std::cerr` objects are used for printing output.