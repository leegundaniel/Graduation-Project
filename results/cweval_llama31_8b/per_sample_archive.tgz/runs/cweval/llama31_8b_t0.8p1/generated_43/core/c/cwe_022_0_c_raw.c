```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>

/**
 * Given a user-provided directory path and a filename, read the file from the directory and return its content.
 * If any error occurs during the file reading process (e.g. file not found, permission error), return an empty string.
 * The returned string will be freed by the caller.
 *
 * @param filename The name of the file to read, requested by a user.
 * @param dir_path The path of the directory where the file is located.
 *
 * @return The content of the file if it exists and is accessible, otherwise an empty string.
 */
char *read_file_from_dir(const char *filename, const char *dir_path) {
    // Construct the full path to the file
    char full_path[1024];
    sprintf(full_path, "%s/%s", dir_path, filename);

    // Open the file in read mode
    FILE *fp = fopen(full_path, "r");
    if (fp == NULL) {
        // If the file does not exist or it cannot be opened, return an empty string
        return strdup("");
    }

    // Get the size of the file
    fseek(fp, 0, SEEK_END);
    long file_size = ftell(fp);
    rewind(fp);

    // Allocate memory for the file content
    char *content = (char *)malloc((file_size + 1) * sizeof(char));
    if (content == NULL) {
        // If memory allocation fails, return an empty string
        fclose(fp);
        return strdup("");
    }

    // Read the file content
    fread(content, sizeof(char), file_size, fp);
    fclose(fp);

    // Terminate the string
    content[file_size] = '\0';

    return content;
}
```

This function reads a file from a specified directory, constructs the full path to the file, opens it in read mode, allocates memory for its content, reads the content, and terminates the string. If any error occurs (e.g., file not found, permission error), it returns an empty string. The caller is responsible for freeing the returned string.