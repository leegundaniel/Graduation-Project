```go
package main

import (
	"encoding/xml"
	"errors"
	"fmt"
	"github.com/ChrisTrenkamp/goxpath"
	"github.com/ChrisTrenkamp/goxpath/tree"
	"github.com/ChrisTrenkamp/goxpath/tree/xmltree"
)

// Represents a student
type Student struct {
	XMLName xml.Name `xml:"student"`
	Username string `xml:"username"`
	Password string `xml:"password"`
	Name     string `xml:"name"`
	Citizenship string `xml:"citizenship"`
	Age      string `xml:"age"`
}

// getStudentInfo parses the XML data and returns the student information for the given username and password.
func getStudentInfo(xmlData, username, password string) (string, string, string) {
	// Unmarshal the XML data into a Student struct
	var students []Student
	err := xml.Unmarshal([]byte(xmlData), &students)
	if err != nil {
		fmt.Println("Error unmarshaling XML:", err)
		return "", "", ""
	}

	// Create an XPath expression for selecting all student elements
	xp := xpath.MustCompile("//student")
	
	// Create a new XPath context
	context := tree.NewContext()
	
	// Create a new XPath tree from the XML data
	tree := xmltree.NewTree([]byte(xmlData))
	
	// Execute the XPath expression in the XPath tree
	nodes, err := xp.Execute(context, tree)
	if err != nil {
		fmt.Println("Error executing XPath expression:", err)
		return "", "", ""
	}
	
	// Iterate over the nodes and find the student with the matching username and password
	for _, node := range nodes {
		student := node.(*xmltree.Element)
		if student.Attrs["username"] == username && student.Attrs["password"] == password {
			// Return the student's information
			return student.Attrs["name"], student.Attrs["age"], student.Attrs["citizenship"]
		}
	}
	
	// If no matching student is found, return empty strings
	return "", "", ""
}

```