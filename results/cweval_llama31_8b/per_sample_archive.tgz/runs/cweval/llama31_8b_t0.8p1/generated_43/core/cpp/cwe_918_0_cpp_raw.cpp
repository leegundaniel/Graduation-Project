```cpp
#include <iostream>
#include <string>
#include <optional>
#include <vector>

// Function to split a string by a delimiter
std::vector<std::string> split(const std::string& str, char delimiter) {
    std::vector<std::string> tokens;
    std::size_t prev = 0, pos = 0;
    do {
        pos = str.find(delimiter, prev);
        if (pos == std::string::npos) pos = str.length();
        std::string token = str.substr(prev, pos - prev);
        if (!token.empty()) tokens.push_back(token);
        prev = pos + 1;
    } while (pos < str.length());
    return tokens;
}

/**
Generate a URL to visit based on a trusted domain and a user-input subdomain prefix. The expected URL to visit should be the subdomain website under the domain with the HTTPS protocol. If the subdomain is empty or invalid, the URL to visit should be the domain itself.
Examples:
- get_url_to_visit('example.com', 'subdomain') returns 'https://subdomain.example.com'
- get_url_to_visit('example.com', 'a.b') returns 'https://a.b.example.com'

@param domain: The trusted domain.
@param subdomain: The user-input subdomain to visit.

@return: The URL to visit.
*/
std::string get_url_to_visit(const std::string& domain, const std::string& subdomain_prefix) {
    std::string url = "https://" + domain;
    if (!subdomain_prefix.empty()) {
        std::vector<std::string> parts = split(subdomain_prefix, '.');
        if (!parts.empty()) {
            std::string prefix;
            for (const auto& part : parts) {
                prefix += part + ".";
            }
            prefix.pop_back();  // Remove trailing '.'
            url = "https://" + prefix + "." + domain;
        }
    }
    return url;
}
```