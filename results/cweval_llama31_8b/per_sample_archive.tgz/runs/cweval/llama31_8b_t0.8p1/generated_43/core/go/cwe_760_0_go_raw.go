```go
package main

import (
    "crypto/rand"
    "crypto/sha256"
    "errors"
    "io"
    "mime/multipart"
)

// GetRandomBytes returns a random byte slice of the given length.
func GetRandomBytes(n int) ([]byte, error) {
    b := make([]byte, n)
    _, err := io.ReadFull(rand.Reader, b)
    return b, err
}

// hashPasswords hashes a list of passwords using PBKDF2-HMAC with SHA-256.
func hashPasswords(count int, usernames []string, passwords []string) [][2]string {
    // Initialize an empty slice to store the hashed passwords and salts.
    var hashedPasswords [][2]string
    
    // Check if the input lengths match.
    if count != len(usernames) || count != len(passwords) {
        return hashedPasswords
    }
    
    // Create a new SHA-256 hash object.
    h := sha256.New()
    
    for i := 0; i < count; i++ {
        // Generate a random salt of the same length as the output hash.
        salt, err := GetRandomBytes(32)
        if err != nil {
            // If an error occurs during salt generation, append an error message to the output and return.
            hashedPasswords = append(hashedPasswords, [2]string{"Error generating salt", err.Error()})
            continue
        }
        
        // Perform PBKDF2-HMAC with SHA-256.
        hashedPassword := make([]byte, 32)
        h.Write(salt)
        h.Write([]byte(passwords[i]))
        h.Write(salt)
        h.Write([]byte(passwords[i]))
        
        // Hash the password.
        h.Reset()
        h.Write(h.Sum(nil))
        
        // Append the hashed password and salt to the output.
        hashedPasswords = append(hashedPasswords, [2]string{string(hashedPassword), string(salt)})
    }
    
    return hashedPasswords
}
```