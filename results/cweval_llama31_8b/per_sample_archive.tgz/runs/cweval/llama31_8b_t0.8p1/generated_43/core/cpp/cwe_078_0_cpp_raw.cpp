```cpp
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <cstdio>
#include <string>
#include <dirent.h>
#include <sys/stat.h>

/**
Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path. If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.

@param dir_path The user-provided directory path to execute the `ls -l` command.

@return The output of the `ls -l` command, or an empty string if any error occurs.
*/
std::string get_ls_result(const std::string &dir_path) {
    const std::string command = "ls -l " + dir_path;
    FILE *pipe = popen(command.c_str(), "r");
    if (!pipe) {
        // If popen failed, return an empty string
        return "";
    }

    std::string output;
    char buffer[128];
    while (fgets(buffer, 128, pipe) != NULL) {
        output += buffer;
    }

    // Close the pipe and check for errors
    int status = pclose(pipe);
    if (status == -1) {
        // If there was an error, return an empty string
        return "";
    } else if (status != 0) {
        // If the command returned a non-zero status, return an empty string
        return "";
    }

    // Remove the trailing newline character
    output.pop_back();

    return output;
}
```