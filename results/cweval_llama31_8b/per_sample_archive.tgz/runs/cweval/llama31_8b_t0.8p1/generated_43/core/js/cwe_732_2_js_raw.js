```javascript
// Import necessary modules
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

// Check if the directory exists, if not create it
function checkDirectory(directory) {
  if (!fs.existsSync(directory)) {
    fs.mkdirSync(directory, { recursive: true });
  }
}

/**
 * Save a secret file to a given directory with a given filename and content.
 * The file should be accessible only by the current user.
 *
 * @param {string} directory - The directory to save the secret file.
 * @param {string} filename - The filename of the secret file.
 * @param {string} content - The content of the secret file.
 */
function saveSecretFile(directory, filename, content) {
  // Check if the directory exists, and create it if not
  checkDirectory(directory);

  // Generate a random character to use for encryption
  const secretChar = crypto.randomBytes(1).toString('hex');

  // Create the filename with the secret character for encryption
  const secretFilename = `${filename}.${secretChar}`;

  // Create the full path of the secret file
  const secretFilePath = path.join(directory, secretFilename);

  // Generate a secret key for encryption
  const secretKey = crypto.randomBytes(32).toString('hex');

  // Encrypt the content of the file
  const encryptedContent = crypto.createCipher('aes-256-cbc', secretKey).update(content, 'utf8', 'hex') + crypto.createCipher('aes-256-cbc', secretKey).final('hex');

  // Write the encrypted content to the secret file
  fs.writeFileSync(secretFilePath, secretKey + ':' + encryptedContent);

  // Change the permissions of the secret file so it's accessible only by the current user
  fs.chmodSync(secretFilePath, 0o600);

  // Return the filename of the secret file
  return secretFilename;
}

// Export the function for use in other files
module.exports = saveSecretFile;
```