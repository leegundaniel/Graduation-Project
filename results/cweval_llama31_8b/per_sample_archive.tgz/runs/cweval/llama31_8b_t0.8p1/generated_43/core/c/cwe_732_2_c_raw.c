```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>

/**
 * Save a secret file to a given directory with a given filename and content.
 * The file should be accessible only by the current user.
 *
 * @param directory The directory to save the secret file.
 * @param filename The filename of the secret file.
 * @param content The content of the secret file.
 */
void save_secrete_file(const char *directory, const char *filename, const char *content) {
    // Create the directory if it does not exist
    mkdir(directory, 0755);
    
    // Construct the full path of the secret file
    char filepath[1024];
    sprintf(filepath, "%s/%s", directory, filename);
    
    // Create a new file with the specified filename and content
    int fd = open(filepath, O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if (fd == -1) {
        perror("Error opening file");
        return;
    }
    
    // Write the content to the file
    size_t len = strlen(content);
    ssize_t bytes_written = write(fd, content, len);
    if (bytes_written != len) {
        perror("Error writing to file");
        close(fd);
        return;
    }
    
    // Close the file descriptor
    close(fd);
}
```

This implementation uses `mkdir` to create the directory if it does not exist, and `open` to create a new file with the specified filename and content. The file is opened with read, write, and create permissions (O_WRONLY | O_CREAT | O_TRUNC), and with permissions 600 (0600) to make it accessible only by the current user. The content is written to the file using `write`, and the file descriptor is closed afterwards.