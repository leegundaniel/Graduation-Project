```python
from typing import Tuple
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

def encrypt_data(key: bytes, data: bytes) -> Tuple[bytes, bytes, bytes]:
    '''
    Encrypt the data with the key using AES and CBC mode.
    The provided key bytes is long enough (>= 64 bytes). Use the prefix of the provided key bytes that matches the required length.
    Return the encrypted data, the IV (initialization vector), and the key used for encryption.

    Args:
        key (bytes): The bytes to generate the encryption key.
        data (bytes): The data to encrypt.

    Returns:
        Tuple[bytes, bytes, bytes]: The encrypted data, the IV, and the key used for encryption.
    '''
    
    # Calculate the required length of the key (128 bits, or 16 bytes for AES key)
    required_key_length = 16
    
    # Use the prefix of the provided key bytes that matches the required length
    key = key[:required_key_length]
    
    # Generate a random 128-bit initialization vector (IV)
    from Crypto.Random import get_random_bytes
    iv = get_random_bytes(16)
    
    # Create an AES cipher object in CBC mode with the provided key and IV
    cipher = AES.new(key, AES.MODE_CBC, iv)
    
    # Pad the data to the block size for AES encryption
    padded_data = pad(data, AES.block_size)
    
    # Encrypt the padded data
    encrypted_data = cipher.encrypt(padded_data)
    
    # Return the encrypted data, the IV, and the key used for encryption
    return encrypted_data, iv, key
```