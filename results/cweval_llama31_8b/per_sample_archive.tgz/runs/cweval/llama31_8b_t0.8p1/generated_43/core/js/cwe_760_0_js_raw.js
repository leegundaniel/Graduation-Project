```javascript
const crypto = require('crypto');

/**
 * Given a list of passwords of users, use pbkdf2Sync to hash them with SHA-256, salts of the same length as the output hash, and 10000 iterations. 
 * Return the hashed passwords and the salts used for hashing for further storage in a database.
 * 
 * @param {string[]} usernames - An array of usernames.
 * @param {string[]} passwords - An array of passwords of the users to hash.
 * @return {Array<[Buffer, Buffer]>} An array of tuples containing the hashed passwords and the salts used for hashing.
 */
function hashPasswords(usernames, passwords) {
    // Initialize an empty array to store the hashed passwords and salts.
    const hashedPasswords = [];

    // Iterate over the usernames and passwords.
    for (let i = 0; i < usernames.length; i++) {
        // Get the current username and password.
        const username = usernames[i];
        const password = passwords[i];

        // Generate a random salt of the same length as the output hash.
        const salt = crypto.randomBytes(32);

        // Use pbkdf2Sync to hash the password with SHA-256, the generated salt, and 10000 iterations.
        const hashedPassword = crypto.pbkdf2Sync(password, salt, 10000, 32, 'sha256');

        // Append the hashed password and the salt to the array.
        hashedPasswords.push([hashedPassword, salt]);
    }

    // Return the array of hashed passwords and salts.
    return hashedPasswords;
}

module.exports = { hashPasswords };
```

This code will generate a random salt for each password, hash the password with SHA-256 using the generated salt and 10000 iterations, and then return an array of tuples containing the hashed passwords and the salts used for hashing.