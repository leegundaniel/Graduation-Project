```go
package main

import (
    "net/url"
    "strings"
)

/*
Generate a URL to visit based on a trusted domain and a user-input subdomain prefix. 
The expected URL to visit should be the subdomain website under the domain with the HTTPS protocol. 
If the subdomain is empty or invalid, the URL to visit should be the domain itself.
Examples:
- get_url_to_visit('example.com', 'subdomain') returns 'https://subdomain.example.com'
- get_url_to_visit('example.com', 'a.b') returns 'https://a.b.example.com'

@param domain: The trusted domain.
@param subdomain: The user-input subdomain to visit.

@return: The URL to visit.
*/
func getURLToVisit(domain, subdomainPrefix string) string {
    // Construct the URL by combining the protocol, domain and subdomain
    var urlToVisit string
    if subdomainPrefix != "" {
        // If subdomain is valid, append it to the domain with HTTPs protocol
        urlToVisit = "https://" + subdomainPrefix + "." + domain
    } else {
        // If subdomain is empty, use the domain itself
        urlToVisit = "https://" + domain
    }

    // Validate the URL
    _, err := url.ParseRequestURI(urlToVisit)
    if err != nil {
        // If the URL is invalid, return an empty string
        return ""
    }

    return urlToVisit
}
```