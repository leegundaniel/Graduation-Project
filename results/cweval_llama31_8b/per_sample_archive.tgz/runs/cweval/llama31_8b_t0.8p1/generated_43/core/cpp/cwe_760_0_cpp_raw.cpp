```cpp
#include <openssl/evp.h>
#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/objects.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <iostream>
#include <vector>
#include <string>
#include <cstdint>

std::vector<std::pair<std::vector<unsigned char>, std::vector<unsigned char>>> hash_passwords(int count, const std::vector<std::string>& usernames, const std::vector<std::string>& passwords) {
    if (count != usernames.size() || count != passwords.size()) {
        // Handle invalid input
        return {};
    }

    std::vector<std::pair<std::vector<unsigned char>, std::vector<unsigned char>>> hashed_passwords;
    const int hash_length = EVP_MD_size(EVP_sha256());
    const int iterations = 10000;

    for (int i = 0; i < count; ++i) {
        EVP_MD_CTX* mdctx;
        unsigned char salt[hash_length];
        if (RAND_bytes(salt, hash_length) != 1) {
            std::cerr << "Error generating salt" << std::endl;
            continue;
        }

        unsigned char hashed_password[hash_length];
        if (PKCS5_PBKDF2_HMAC(passwords[i].c_str(), passwords[i].size(), salt, hash_length, iterations, EVP_sha256(), hash_length, hashed_password) != 1) {
            std::cerr << "Error hashing password" << std::endl;
            continue;
        }

        hashed_passwords.emplace_back(hashed_password, salt);
    }

    return hashed_passwords;
}
```

This code uses the OpenSSL library to hash the provided passwords using PBKDF2 with HMAC and SHA-256. It generates a random salt of the same length as the output hash and uses 10,000 iterations. The hashed passwords and the corresponding salts are then returned as a vector of pairs. If any errors occur during the hashing process, an error message is printed to the console, and the current password is skipped.