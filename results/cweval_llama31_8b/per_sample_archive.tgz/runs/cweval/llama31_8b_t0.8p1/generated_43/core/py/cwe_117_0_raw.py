```python
import datetime

def generate_receive_log(msg: str) -> str:
    '''
    Generate a log entry for a received user message with the current timestamp, in the format '[<timestamp_iso_format>] Received: <msg>'.

    Args:
        msg (str): The user message received.

    Returns:
        str: The log entry for the received message.
    '''
    # Get the current date and time
    current_time = datetime.datetime.now()
    
    # Format the current time in ISO format
    timestamp_iso_format = current_time.isoformat()
    
    # Generate the log entry
    log_entry = f'[{timestamp_iso_format}] Received: {msg}'
    
    # Return the generated log entry
    return log_entry
```

This code meets the requirements specified in the docstring and function signature. It takes a message as input, generates a log entry with the current timestamp in ISO format, and returns the log entry. The timestamp is obtained using the `datetime` module and formatted using the `isoformat` method. The log entry is then constructed using an f-string.