```go
package main

import (
	"crypto/rand"
	"crypto/rsa"
	"encoding/pem"
	-errors "errors"
	"fmt"
	"os"
)

// Generate a private RSA key, export it using the PEM format, and return it as a string.
func CreatePrivateKey() string {
	privateKey, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		return fmt.Sprintf("Error generating RSA key: %s", err)
	}

	privateKeyPEM := &pem.Block{Type: "RSA PRIVATE KEY", Bytes: x509.MarshalPKCS1PrivateKey(privateKey)}
	privateKeyBytes := pem.EncodeToMemory(privateKeyPEM)

	return string(privateKeyBytes)
}

func main() {
	// not used
}

func x509.MarshalPKCS1PrivateKey(privateKey *rsa.PrivateKey) ([]byte, error) {
	return nil, _errors.New("not implemented")
}
```

Note: The `x509.MarshalPKCS1PrivateKey` function is not defined in the Go standard library. I've added it as a placeholder. In a real-world scenario, you would need to import the `crypto/x509` package and use its `MarshalPKCS1PrivateKey` function instead.