```javascript
/**
 * Generate a URL for querying user info based on a given API URL and a user ID. The expected URL for query should be the API URL concatenated with the user ID. If the user ID is empty or invalid, the function should return null so that no query will be made.
 * Examples:
 * - getUrlForQuery('https://example.com/api/user', 'aBc123') returns 'https://example.com/api/user/aBc123'
 * - getUrlForQuery('https://example.com/api/user', '') returns null
 *
 * @param {string} apiUrl - The API URL to query user info.
 * @param {string} userId - The user ID to query.
 * @returns {string|null} - The URL for query.
 */
function getUrlForQuery(apiUrl, userId) {
    // Check if the API URL and user ID are valid strings
    if (typeof apiUrl !== 'string' || typeof userId !== 'string') {
        return null;
    }
    
    // Remove leading and trailing whitespaces from the API URL and user ID
    apiUrl = apiUrl.trim();
    userId = userId.trim();
    
    // Check if the user ID is not empty after removing whitespaces
    if (userId === '') {
        return null;
    }
    
    // Concatenate the API URL and user ID to form the query URL
    const queryUrl = `${apiUrl}/${userId}`;
    
    return queryUrl;
}

```