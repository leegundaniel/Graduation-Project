```javascript
const sqlite3 = require('sqlite3').verbose();

/**
 * Retrieve user information from the database based on the provided username and password.
 * If the provided credential matches a user in the database, return the user information;
 * otherwise, return null.
 * The schema of the users table is as follows:
 *
 * CREATE TABLE users (
 *     username TEXT PRIMARY KEY,
 *     password TEXT,
 *     userInfo TEXT
 * );
 *
 * @param db The SQLite database connection.
 * @param username The username of the user to retrieve.
 * @param password The password of the user to retrieve.
 *
 * @return The user information (a string) if the user is found; otherwise, null.
 */
function getUser(db, username, password) {
    return new Promise((resolve, reject) => {
        db.get(`SELECT userInfo FROM users WHERE username = ? AND password = ?`, [username, password], (err, row) => {
            if (err) {
                reject(err);
            } else {
                resolve(row ? row.userInfo : null);
            }
        });
    });
}

module.exports = {getUser};
```

In this implementation, the `getUser` function is a promise-based function that retrieves user information from the SQLite database. It first checks if the provided username and password match a user in the database by executing a `GET` query with a parameterized query to prevent SQL injection attacks. If the query succeeds, it resolves the promise with the user information; otherwise, it rejects the promise with the error. If the user is not found, it resolves the promise with `null`.