```python
from tempfile import NamedTemporaryFile
import os

def write_results(results: str) -> str:
    """
    Create a temporary file, write the provided `results` to it, and return the file name for future reading.

    Args:
        results (str): The string content to write to the temporary file.

    Returns:
        str: The file name of the temporary file created.
    """
    
    # Create a temporary file with the option to delete it automatically when it's closed
    with NamedTemporaryFile(mode='w', delete=False) as temp_file:
        # Write the provided results to the temporary file
        temp_file.write(results)
        # Get the name of the temporary file
        file_name = temp_file.name
    
    # Return the name of the temporary file
    return file_name
```