```javascript
// Node.js dependencies
const crypto = require('crypto');

/**
 * Hash the given password securely and return the hash as a string.
 *
 * @param {string} password - The password to be hashed.
 * @returns {Promise<string>} The securely hashed password.
 */
async function get_password_hash(password) {
  try {
    // Generate a random salt to be used in the hashing process
    const salt = crypto.randomBytes(32).toString('hex');
    
    // Create a SHA-256 hash object
    const hash = crypto.createHmac('sha256', salt);
    
    // Update the hash object with the password
    hash.update(password);
    
    // Get the hexadecimal representation of the hash
    const hashedPassword = salt + ':' + hash.digest('hex');
    
    // Return the hashed password as a promise
    return Promise.resolve(hashedPassword);
  } catch (error) {
    // Log and return any errors that occur during the hashing process
    console.error('Error hashing password:', error);
    return Promise.resolve(null);
  }
}

// Export the get_password_hash function for use in other modules
module.exports = get_password_hash;
```

This implementation uses the `crypto` module from Node.js to securely hash the given password. The `crypto` module provides a variety of cryptographic functions, including hash functions and key derivation functions. The `randomBytes` function is used to generate a random salt, which is then used to create a SHA-256 hash object. The hash object is then updated with the password, and the resulting hexadecimal representation of the hash is returned as a promise. Any errors that occur during the hashing process are logged and returned as a null value.