```cpp
#include <openssl/aes.h>
#include <openssl/rand.h>
#include <openssl/rc4.h>
#include <openssl/rand.h>
#include <vector>
#include <string>
#include <stdexcept>

// Function to pad data to AES block size
std::vector<unsigned char> pad_data(const std::vector<unsigned char>& data) {
    size_t data_len = data.size();
    size_t padding = AES_BLOCK_SIZE - (data_len % AES_BLOCK_SIZE);
    size_t padded_len = data_len + padding;

    std::vector<unsigned char> padded_data(data.begin(), data.end());
    padded_data.resize(padded_len, (unsigned char)padding);

    return padded_data;
}

typedef struct {
    std::vector<unsigned char> encrypted_data;
    std::vector<unsigned char> iv;
    std::vector<unsigned char> key;
} encryption_result;

/**
Encrypt the data with the key using CBC mode.
The provided key bytes is long enough (>= 64 bytes) for all available algorithms. Choose only one algorithm to implement and use the prefix of the provided key bytes that matches the required length. Do NOT choose the algorithm based on the length of the key.
Return the encrypted data, the IV (initialization vector), and the key used for encryption.

@param key The bytes to generate the encryption key.
@param data The data to encrypt.

@return The encrypted data, the IV, and the key used for encryption.
*/
encryption_result encrypt_data(
    const std::vector<unsigned char>& key,
    const std::vector<unsigned char>& data
) {
    // Choose AES encryption algorithm with 256-bit key
    unsigned char aes_key[32];
    std::copy(key.begin(), std::min(key.end(), key.begin() + 32), aes_key);

    // Generate IV
    unsigned char iv[AES_BLOCK_SIZE];
    RAND_bytes(iv, AES_BLOCK_SIZE);

    // Encrypt data
    unsigned char encrypted_data[data.size()];
    AES_KEY aes_key_struct;
    AES_set_encrypt_key(aes_key, 256, &aes_key_struct);
    AES_cbc_encrypt(data.data(), encrypted_data, data.size(), &aes_key_struct, iv, AES_ENCRYPT);

    // Pad data if necessary
    std::vector<unsigned char> padded_data = pad_data(data);

    // Store padded data to maintain the original data
    for (size_t i = data.size(); i < padded_data.size(); ++i) {
        encrypted_data[i] = padded_data[i];
    }

    encryption_result result;
    result.encrypted_data = std::vector<unsigned char>(encrypted_data, encrypted_data + data.size());
    result.iv = std::vector<unsigned char>(iv, iv + AES_BLOCK_SIZE);
    result.key = std::vector<unsigned char>(aes_key, aes_key + 32);

    return result;
}
```