```cpp
#include <iostream>
#include <string>
#include <map>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <libxml/tree.h>

/**
Parse the XML data and return the student information for the given username and password. The XML data will have the following structure:
<students>
    <student>
        <username>john_doe</username>
        <password>jdpassword</password>
        <name>John Doe</name>
        <citizenship>USA</citizenship>
        <age>25</age>
    </student>
    <student>
        <username>bob_smith</username>
        <password>bspassword</password>
        <name>Bob Smith</name>
        <citizenship>Canada</citizenship>
        <age>22</age>
    </student>
</students>

We can construct a XPath query and use it to search.

@param xml_data The XML data containing the student information.
@param username The username of the student to search for.
@param password The password of the student to search for.

@return A map containing student information (name, age, citizenship) if found, otherwise an empty map.
*/
std::map<std::string, std::string> get_student_info(const std::string& xml_data, const std::string& username, const std::string& password) {
    // Parse the XML data
    xmlDocPtr doc = xmlParseDoc((const xmlChar*)xml_data.c_str());
    if (doc == NULL) {
        return {};
    }

    // Create a XPath context
    xmlXPathContextPtr ctx = xmlXPathNewContext(doc);
    if (ctx == NULL) {
        xmlFreeDoc(doc);
        return {};
    }

    // Construct the XPath query
    std::string query = "/students/student[@username='" + username + "' and @password='" + password + "']";
    const xmlChar* expression = (const xmlChar*)query.c_str();

    // Evaluate the XPath query
    xmlXPathObjectPtr result = xmlXPathEvalExpression(expression, ctx);
    if (result == NULL) {
        xmlXPathFreeContext(ctx);
        xmlFreeDoc(doc);
        return {};
    }

    // Get the first node from the result
    xmlNodeSetPtr nodes = result->nodesetval;
    if (nodes == NULL || nodes->nodeNr == 0) {
        xmlXPathFreeObject(result);
        xmlXPathFreeContext(ctx);
        xmlFreeDoc(doc);
        return {};
    }

    // Get the first node
    xmlNodePtr node = nodes->nodeTab[0];

    // Create a map to store the student information
    std::map<std::string, std::string> student_info;

    // Add the name to the map
    xmlNodePtr name_node = xmlFirstElementChild(node);
    while (name_node != NULL) {
        if (xmlStrcmp(name_node->name, (const xmlChar*)"name") == 0) {
            student_info["name"] = (const char*)xmlNodeGetContent(name_node);
            break;
        }
        name_node = name_node->next;
    }

    // Add the age to the map
    name_node = xmlFirstElementChild(node);
    while (name_node != NULL) {
        if (xmlStrcmp(name_node->name, (const xmlChar*)"age") == 0) {
            student_info["age"] = (const char*)xmlNodeGetContent(name_node);
            break;
        }
        name_node = name_node->next;
    }

    // Add the citizenship to the map
    name_node = xmlFirstElementChild(node);
    while (name_node != NULL) {
        if (xmlStrcmp(name_node->name, (const xmlChar*)"citizenship") == 0) {
            student_info["citizenship"] = (const char*)xmlNodeGetContent(name_node);
            break;
        }
        name_node = name_node->next;
    }

    // Clean up
    xmlXPathFreeObject(result);
    xmlXPathFreeContext(ctx);
    xmlFreeDoc(doc);

    // Return the student information
    return student_info;
}
```