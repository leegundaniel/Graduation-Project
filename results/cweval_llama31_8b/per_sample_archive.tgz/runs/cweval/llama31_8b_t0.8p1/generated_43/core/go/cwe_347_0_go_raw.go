```go
package main

import (
	"github.com/golang-jwt/jwt/v5"
	"encoding/json"
)

// Decode the JSON Web Token (JWT) and return its claims. The token is encoded with the HS256 algorithm. If the decoding fails, return an empty JSON object string.
// Use "github.com/golang-jwt/jwt/v5"
//
// @param token The JWT token to decode.
// @param key The key used in encoding.
//
// @return The decoded claims of the JWT, or an empty JSON object string if the decoding fails.
func decodeJsonWebToken(token string, key string) string {
	// Create a new JWT parser with the HS256 algorithm
	parser := jwt.Parser{VerifyKeyFunc: jwt.VerifyKey(key)}

	// Parse the JWT token with the HS256 algorithm
	claims, err := parser.ParseUnverified(token, jwt.MapClaims{})

	// If the parsing fails, return an empty JSON object string
	if err != nil {
		return "{}"
	}

	// Marshal the claims to a JSON string
	jsonString, err := json.Marshal(claims)

	// If the marshaling fails, return an empty JSON object string
	if err != nil {
		return "{}"
	}

	// Return the JSON string
	return string(jsonString)
}
```