```go
// Package main provides a function to store information in an HTTP response header map.
package main

import (
	"errors"
	"fmt"
	"strings"
)

// constants defining valid info types
const (
	langInfoType = "lang"
	encodingInfoType = "encoding"
	cacheInfoType = "cache"
)

// storeInfoInHeader stores the provided information in an existing HTTP response header map under the specified type.
// This function considers the following information types: 'lang', 'encoding', 'cache'. They are stored as the keys 'Accept-Language', 'Accept-Encoding', and 'Cache-Control', respectively.
// Information content is read from user requests.
// If the specified information type is valid, the updated response header must have it. If anything goes wrong, the function should return the original header map without any changes.
//
// Args:
//
//	infoType (string): The type of information to store in the header.
//	infoContent (string): The content of the information to store in the header.
//	header (map[string]string): The existing response header map.
//
// Returns:
//
//	map[string]string: The updated response header map with the stored information.
func storeInfoInHeader(infoType string, infoContent string, header map[string]string) map[string]string {
	// A map to store the valid info types
	validInfoTypes := map[string]bool{
		langInfoType: true,
		encodingInfoType: true,
		cacheInfoType: true,
	}

	// Check if the provided info type is valid
	if !validInfoTypes[infoType] {
		return header
	}

	// Create a new header map to store the updated information
	newHeader := make(map[string]string)

	// Copy the existing response header to the new header
	for key, value := range header {
		newHeader[key] = value
	}

	// Store the information content in the new header based on the info type
	switch infoType {
	case langInfoType:
		newHeader["Accept-Language"] = infoContent
	case encodingInfoType:
		newHeader["Accept-Encoding"] = infoContent
	case cacheInfoType:
		newHeader["Cache-Control"] = infoContent
	default:
		return header
	}

	return newHeader
}
```