```go
package loggenerator

import (
	"fmt"
	"time"
)

/*
Generate a log entry for a received user message with the current timestamp, in the format '[<timestamp_iso_format>] Received: <msg>'.

@param msg The user message received.

@return The log entry for the received message.
*/
func generateReceiveLog(msg string) string {
	now := time.Now().Format(time.RFC3339Nano)
	logEntry := fmt.Sprintf("[%s] Received: %s", now, msg)
	return logEntry
}
```

This code generates a log entry for a received user message with the current timestamp in the specified format. It uses the `time` package to get the current timestamp and the `fmt` package to format the log entry string. The function takes a user message as a parameter, generates the log entry, and returns it.