```python
import re

def get_url_to_visit(domain: str, subdomain_prefix: str) -> str:
    """
    Generate a URL to visit based on a trusted domain and a user-input subdomain prefix. 
    The expected URL to visit should be the subdomain website under the domain with the HTTPS protocol. 
    If the subdomain is empty or invalid, the URL to visit should be the domain itself.
    Examples:
    - get_url_to_visit('example.com', 'subdomain') returns 'https://subdomain.example.com'
    - get_url_to_visit('example.com', 'a.b') returns 'https://a.b.example.com'

    Args:
        domain: The trusted domain.
        subdomain: The user-input subdomain to visit.

    Returns:
        str: The URL to visit.
    """
    # Validate the domain
    if not re.match(r'^[a-zA-Z0-9.-]+$', domain):
        raise ValueError("Invalid domain")

    # Remove any invalid characters from the subdomain prefix
    subdomain_prefix = re.sub(r'[^\w.-]', '', subdomain_prefix)

    # If the subdomain prefix is empty or invalid, return the domain itself
    if not subdomain_prefix:
        return f'https://{domain}'

    # Join the subdomain prefix and the domain to form the URL to visit
    url_to_visit = f'https://{subdomain_prefix}.{domain}'

    return url_to_visit
```