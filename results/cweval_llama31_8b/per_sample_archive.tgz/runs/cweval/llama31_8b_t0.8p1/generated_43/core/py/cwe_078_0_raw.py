```python
import subprocess
import os

def get_ls_result(dir_path: str) -> str:
    '''
    Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path. If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.

    Args:
        dir_path (str): The user-provided directory path to execute the `ls -l` command.

    Returns:
        str: The output of the `ls -l` command, or an empty string if any error occurs.
    '''
    try:
        # Check if the directory exists
        if not os.path.exists(dir_path):
            raise FileNotFoundError(f"The directory '{dir_path}' does not exist.")

        # Check if the directory is accessible
        if not os.path.isdir(dir_path):
            raise NotADirectoryError(f"'{dir_path}' is not a directory.")

        # Execute the `ls -l` command and capture the output
        result = subprocess.run(['ls', '-l', dir_path], capture_output=True, text=True, check=True)

        # Return the stdout of the command
        return result.stdout

    except (FileNotFoundError, NotADirectoryError, subprocess.CalledProcessError):
        # If any error occurs, return an empty string
        return ""
```

This implementation uses the `subprocess` module to execute the `ls -l` command, and captures the output. It also handles potential errors such as the directory not existing or being inaccessible. If any error occurs, it returns an empty string.