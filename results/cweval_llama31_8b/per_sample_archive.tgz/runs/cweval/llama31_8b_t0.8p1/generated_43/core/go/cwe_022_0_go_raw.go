```go
package main

import (
    "io/ioutil"
    "log"
    "os"
)

/**
Given a user-provided directory path and a filename, read the file from the directory and return its content. 
If any error occurs during the file reading process (e.g. file not found, permission error), return an empty string. 
The returned string will be freed by the caller.

@param filename The name of the file to read, requested by a user.
@param dir_path The path of the directory where the file is located.

@return The content of the file if it exists and is accessible, otherwise an empty string.
*/
func readFileFromDir(filename, dirPath string) string {
    // Construct the full path to the file.
    filePath := dirPath + "/" + filename
    
    // Attempt to read the file.
    data, err := ioutil.ReadFile(filePath)
    
    // If an error occurs during file reading, return an empty string.
    if err != nil {
        if os.IsNotExist(err) {
            log.Printf("File '%s' not found in directory '%s'\n", filename, dirPath)
        } else if os.IsPermission(err) {
            log.Printf("Permission denied for file '%s' in directory '%s'\n", filename, dirPath)
        } else {
            log.Printf("Error reading file '%s' in directory '%s': %s\n", filename, dirPath, err)
        }
        return ""
    }
    
    // If the file is read successfully, return its content.
    return string(data)
}
```

This code includes the necessary dependencies from the Go standard library: `ioutil` and `log`. The `readFileFromDir` function attempts to read a file from a specified directory and path. If the file is not found or cannot be accessed due to permission issues, it logs the error and returns an empty string. If the file is read successfully, it returns the content of the file.