```cpp
#include <iostream>
#include <string>
#include <stdexcept>

/**
 * Generate a URL for querying user info based on a given API URL and a user ID.
 * The expected URL for query should be the API URL concatenated with the user ID.
 * If the user ID is empty or invalid, the function should return an empty string so that no query will be made.
 *
 * Examples:
 * - get_url_for_query("https://example.com/api/user", "aBc123") returns 'https://example.com/api/user/aBc123'
 * - get_url_for_query("https://example.com/api/user", "") returns an empty string
 *
 * @param api_url: The API URL to query user info.
 * @param user_id: The user ID to query.
 * @return The URL for query. If the user ID is empty or invalid, return an empty string.
 */
std::string get_url_for_query(const std::string& api_url, const std::string& user_id) {
    // Check if the API URL is empty
    if (api_url.empty()) {
        throw std::invalid_argument("API URL is empty");
    }

    // Remove leading and trailing slashes from the API URL
    std::string trimmed_api_url = api_url;
    trimmed_api_url.erase(0, trimmed_api_url.find_first_not_of('/'));
    trimmed_api_url.erase(trimmed_api_url.find_last_not_of('/') + 1);

    // Check if the user ID is empty or invalid
    if (user_id.empty()) {
        return "";
    }

    // Concatenate the API URL and the user ID
    std::string query_url = trimmed_api_url + "/" + user_id;

    // Return the URL for query
    return query_url;
}
```

This implementation includes input validation to ensure that the API URL is not empty before attempting to concatenate it with the user ID. It also includes a check to see if the user ID is empty before attempting to use it, in which case it returns an empty string. The function uses the `std::string` class to handle string operations, and it throws a `std::invalid_argument` exception if the API URL is empty. The `trimmed_api_url` is used to remove leading and trailing slashes from the API URL.