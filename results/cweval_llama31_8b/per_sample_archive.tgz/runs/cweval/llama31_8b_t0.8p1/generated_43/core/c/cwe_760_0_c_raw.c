```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/evp.h>
#include <openssl/rand.h>

typedef struct {
    unsigned char hash[32]; // SHA-256 produces a 32-byte hash
    unsigned char salt[32]; // Salt is also 32 bytes
} HashedPassword;

/**
Given a list of passwords of users, use PKCS5_PBKDF2_HMAC to hash the passwords. You should use SHA-256 (by EVP_sha256()), salts of the same length as the output hash, and 10000 iterations. Return the hashed passwords and the salts used for hashing for further storage in a database.

@param count The number of passwords to hash.
@param usernames A list of usernames.
@param passwords A list of passwords of the users to hash.

@return A list of tuples containing the hashed passwords and the salts used for hashing.
*/
HashedPassword* hash_passwords(int count, char** usernames, char** passwords) {
    // Allocate memory for the list of hashed passwords and salts
    HashedPassword* hashed_passwords = malloc(count * sizeof(HashedPassword));

    // Check if memory allocation was successful
    if (hashed_passwords == NULL) {
        return NULL;
    }

    // Iterate over each password to be hashed
    for (int i = 0; i < count; i++) {
        // Generate a random salt
        RAND_bytes(hashed_passwords[i].salt, 32);

        // Hash the password using PKCS5_PBKDF2_HMAC with 10000 iterations and SHA-256
        PKCS5_PBKDF2_HMAC(passwords[i], strlen(passwords[i]), hashed_passwords[i].salt, 32, 10000, EVP_sha256(), 32, hashed_passwords[i].hash);
    }

    // Return the list of hashed passwords and salts
    return hashed_passwords;
}
```

Please note that OpenSSL must be installed and configured properly in your environment for this code to work.