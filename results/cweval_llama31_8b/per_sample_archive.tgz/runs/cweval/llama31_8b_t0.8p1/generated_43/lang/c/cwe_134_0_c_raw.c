```c
#include <stdio.h>
#include <stdlib.h>

/**
 * Print exactly the given message string to stdout. Do NOT print any additional characters, including newline characters.

 * @param message: the message to print
 */
void print_message(const char* message) {
    // Print the message to stdout
    // fputc is used instead of printf to prevent printing any additional characters
    while (*message != '\0') {
        fputc(*message, stdout);
        message++;
    }
}
```

This implementation uses the `fputc` function from the standard input/output library (`stdio.h`) to print each character of the message to stdout individually, preventing the printing of any additional characters, including newline characters.