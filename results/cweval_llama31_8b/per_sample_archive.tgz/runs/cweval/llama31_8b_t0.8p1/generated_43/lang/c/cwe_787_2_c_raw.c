```c
#include <stdio.h>
#include <string.h>

/**
 * Given a user-input string, remove the trailing spaces from the string. 
 * The string should be modified in place.
 *
 * @param str The input string to be trimmed.
 */
void trim_spaces(char* str) {
    // If the string is NULL or has a length of 0, there's nothing to trim.
    if (str == NULL || strlen(str) == 0) {
        return;
    }
    
    // Get the length of the string.
    int len = strlen(str);
    
    // If the last character is a space, remove it.
    while (len > 0 && str[len - 1] == ' ') {
        // Move the last character to the end of the string, effectively removing it.
        str[len - 1] = '\0';
        len--;
    }
}
```

This implementation uses the `strlen` function from the `string.h` header to get the length of the string, and then iteratively checks and removes trailing spaces from the string. If the string is NULL or empty, it simply returns without doing anything. The loop continues as long as there are trailing spaces in the string.