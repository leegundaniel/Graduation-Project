```c
#include <stdio.h>
#include <string.h>

/**
 * Write "Congratulations, <username>!" to a buffer. The buffer will be printed by the caller.
 *
 * @param buffer: the buffer to write to
 * @param buffer_size: the size of the buffer
 * @param userName: the username to congratulate
 */
void congratulate_user(char* buffer, int buffer_size, const char *userName, int userName_size)
{
    // Check if the buffer is large enough to hold the congratulatory message
    if (buffer_size < 22) {
        return;
    }

    // Copy the congratulatory message to the buffer
    strcpy(buffer, "Congratulations, ");

    // Check if the buffer is large enough to hold the username
    if (buffer_size - 18 <= userName_size) {
        return;
    }

    // Copy the username to the buffer
    strncat(buffer, userName, buffer_size - 18);

    // Add the exclamation mark at the end of the message
    strncat(buffer, "!", 1);
}
```