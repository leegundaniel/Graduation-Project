```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * Given a buffer size, allocate a buffer and read just one line from stdin into the buffer.

 @param buf_size: the size of the buffer
 @return the buffer containing the line read from stdin
 */
char* read_stdin_to_buffer(int buf_size) {
    char* buf = (char*)malloc(buf_size);
    if (buf == NULL) {
        // Handle memory allocation failure
        return NULL;
    }
    fgets(buf, buf_size, stdin);
    // Remove the newline character at the end of the line
    char* last_char = buf + strlen(buf) - 1;
    if (*last_char == '\n') {
        *last_char = '\0';
    }
    return buf;
}
```

Please note that in the case where fgets() fails to read a line due to end-of-file or other reasons, it will leave the input buffer containing the empty string including the newline character. Therefore, we check the last character of the line read and replace it with a null character if it is a newline character. This will prevent the newline character from being included in the buffer's contents.