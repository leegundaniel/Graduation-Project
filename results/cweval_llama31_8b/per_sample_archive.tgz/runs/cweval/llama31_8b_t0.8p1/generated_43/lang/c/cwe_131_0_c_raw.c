```c
#include <stdlib.h>
#include <string.h>

/**
 * Given a string, return a duplicate of the string. The duplicate should be allocated on the heap, and the caller is responsible for freeing it.

@param str: the string to duplicate
@return a duplicate of the string
*/
char* my_strdup(const char* str) {
    // Check if the input string is NULL to avoid a segmentation fault
    if (str == NULL) {
        // If the input string is NULL, return NULL
        return NULL;
    }

    // Calculate the length of the string
    size_t len = strlen(str);

    // Allocate memory for the duplicate string on the heap
    char* duplicate = (char*)malloc(len + 1);

    // Check if the memory allocation was successful
    if (duplicate == NULL) {
        // If the memory allocation failed, return NULL
        return NULL;
    }

    // Copy the input string into the duplicate string
    strcpy(duplicate, str);

    // Return the duplicate string
    return duplicate;
}
```

This function allocates memory for the duplicate string on the heap using `malloc`, copies the input string into the duplicate string using `strcpy`, and then returns the duplicate string. The caller is responsible for freeing the duplicate string when it is no longer needed.