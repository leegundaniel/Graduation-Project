```python
import sqlite3
import hashlib

def get_user(cursor: sqlite3.Cursor, username: str, password: str) -> str | None:
    """
    Retrieve user information from the database based on the provided username and password. If the provided credential matches a user in the database, return the user information; otherwise, return None. The schema of the users table is as follows:

    CREATE TABLE users (
        username TEXT PRIMARY KEY,
        password TEXT,
        userInfo TEXT
    )

    Args:
        cursor: A cursor object to interact with the SQLite database.
        username: The username of the user to retrieve.
        password: The password of the user to retrieve.

    Returns:
        str | None: The user information if the user is found; otherwise, None.
    """
    # Hash the provided password for secure comparison
    hashed_password = hashlib.sha256(password.encode()).hexdigest()
    
    # Prepare the SQL query to retrieve the user information
    query = "SELECT userInfo FROM users WHERE username = ? AND password = ?"
    
    # Execute the query with the provided username and hashed password
    cursor.execute(query, (username, hashed_password))
    
    # Fetch the result of the query
    result = cursor.fetchone()
    
    # If a matching user is found, return their user information; otherwise, return None
    if result:
        return result[0]
    else:
        return None
```

In this implementation, we use the SHA-256 hashing algorithm to securely compare the provided password with the stored password in the database. We prepare an SQL query to retrieve the user's information based on their username and hashed password, then execute this query using the provided cursor object. Finally, we fetch the result of the query and check if a matching user is found. If a match is found, we return the user's information; otherwise, we return None.