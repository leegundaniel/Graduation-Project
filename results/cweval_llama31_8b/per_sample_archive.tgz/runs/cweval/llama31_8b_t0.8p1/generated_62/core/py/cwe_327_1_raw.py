```python
import hashlib
import argon2

class PasswordHasher:
    """
    A class for securely hashing passwords.
    """
    
    def __init__(self):
        """
        Initializes the PasswordHasher instance.
        """
        self.argon2_hasher = argon2.PasswordHasher()

    def get_password_hash(self, password: str) -> str:
        """
        Hash the given password securely and return the hash as a string.

        Args:
            password (str): The password to be hashed.

        Returns:
            str: The securely hashed password.
        """
        hashed_password = self.argon2_hasher.hash(password)
        return hashed_password

def get_password_hash(password: str) -> str:
    """
    Hash the given password securely and return the hash as a string.

    Args:
        password (str): The password to be hashed.

    Returns:
        str: The securely hashed password.
    """
    password_hasher = PasswordHasher()
    hashed_password = password_hasher.get_password_hash(password)
    return hashed_password
```

This code implements a class `PasswordHasher` that encapsulates the password hashing logic using the Argon2 algorithm. The `get_password_hash` method is the public interface for hashing a password securely and returning the hashed password as a string. The `argon2` library is used to securely hash the password.