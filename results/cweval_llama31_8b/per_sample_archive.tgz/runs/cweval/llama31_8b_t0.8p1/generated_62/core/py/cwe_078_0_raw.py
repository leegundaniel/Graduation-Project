```python
import subprocess

def get_ls_result(dir_path: str) -> str:
    '''
    Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path. If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.

    Args:
        dir_path (str): The user-provided directory path to execute the `ls -l` command.

    Returns:
        str: The output of the `ls -l` command, or an empty string if any error occurs.
    '''
    
    try:
        # Execute the ls -l command in the specified directory path and capture its output
        result = subprocess.check_output(['ls', '-l'], cwd=dir_path)
        
        # Decode the output from bytes to string and strip any trailing newlines
        output = result.decode('utf-8').strip()
        
        # Return the output of the command
        return output
    
    except subprocess.CalledProcessError:
        # If the command execution fails, return an empty string
        return ""
    
    except FileNotFoundError:
        # If a FileNotFoundError occurs, it means the directory does not exist, so return an empty string
        return ""
    
    except Exception as e:
        # For any other unexpected error, print the error message and return an empty string
        print(f"An unexpected error occurred: {e}")
        return ""
```

This code uses the subprocess module to execute the `ls -l` command in the specified directory path and capture its output. It handles potential errors such as subprocess.CalledProcessError, FileNotFoundError, and any other unexpected exceptions. If any error occurs, it returns an empty string.