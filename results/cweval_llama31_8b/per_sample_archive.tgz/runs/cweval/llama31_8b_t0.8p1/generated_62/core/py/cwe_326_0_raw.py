```python
from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes
import base64

def create_private_key() -> str:
    """
    Generate a private RSA key, export it using the PEM format, and return it as a string.

    Returns:
        str: The RSA private key in PEM format.
    """
    # Generate a random key size of 2048 bits
    key = RSA.generate(2048)

    # Export the private key in PEM format
    private_key_pem = key.export_key('PEM')

    # Convert the private key to a string
    private_key_str = private_key_pem.decode('utf-8')

    # Return the private key as a string
    return private_key_str
```

This function uses the `Crypto.PublicKey` module to generate a new RSA key, and then exports the private key in PEM format. The private key is then decoded from bytes to a string using the `decode` method. The function finally returns the private key as a string.