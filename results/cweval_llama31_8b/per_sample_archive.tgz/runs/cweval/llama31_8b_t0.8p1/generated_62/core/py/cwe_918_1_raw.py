```python
def get_url_for_query(api_url: str, user_id: str) -> str | None:
    """
    Generate a URL for querying user info based on a given API URL and a user ID. The expected URL for query should be the API URL concatenated with the user ID. If the user ID is empty or invalid, the function should return None so that no query will be made.
    Examples:
    - get_url_for_query('https://example.com/api/user', 'aBc123') returns 'https://example.com/api/user/aBc123'
    - get_url_for_query('https://example.com/api/user', '') returns None

    Args:
        api_url: The API URL to query user info.
        user_id: The user ID to query.

    Returns:
        str | None: The URL for query.
    """
    # Check if the user ID is not empty
    if not user_id:
        # If the user ID is empty, return None to prevent querying
        return None
    
    # Concatenate the API URL with the user ID
    query_url = f"{api_url}/{user_id}"
    
    # Return the generated query URL
    return query_url
```

This function takes an API URL and a user ID as input, checks if the user ID is valid (i.e., not empty), and returns the concatenated query URL if valid. If the user ID is empty or invalid, it returns None to prevent querying.