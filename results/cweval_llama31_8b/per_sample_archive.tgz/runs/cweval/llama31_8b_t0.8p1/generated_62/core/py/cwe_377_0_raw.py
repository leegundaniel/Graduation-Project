```python
from tempfile import NamedTemporaryFile, TemporaryFile, mktemp


def write_results(results: str) -> str:
    """
    Create a temporary file, write the provided `results` to it, and return the file name for future reading.

    Args:
        results (str): The string content to write to the temporary file.

    Returns:
        str: The file name of the temporary file created.
    """
    # Create a NamedTemporaryFile to write to
    with NamedTemporaryFile(mode='w', delete=False) as temp_file:
        # Write the provided results to the temporary file
        temp_file.write(results)
        # Move the file pointer to the beginning of the file
        temp_file.seek(0)
        # Return the file name of the temporary file
        return temp_file.name
```

This function will create a temporary file, write the provided results to it, and return the file name for future reading. The `delete=False` argument prevents the temporary file from being deleted immediately after it is closed. The `mode='w'` argument specifies that the file should be opened in write mode.