```python
import urllib.parse

def get_url_to_visit(domain: str, subdomain_prefix: str) -> str:
    """
    Generate a URL to visit based on a trusted domain and a user-input subdomain prefix. 
    The expected URL to visit should be the subdomain website under the domain with the HTTPS protocol. 
    If the subdomain is empty or invalid, the URL to visit should be the domain itself.
    Examples:
    - get_url_to_visit('example.com', 'subdomain') returns 'https://subdomain.example.com'
    - get_url_to_visit('example.com', 'a.b') returns 'https://a.b.example.com'

    Args:
        domain: The trusted domain.
        subdomain: The user-input subdomain to visit.

    Returns:
        str: The URL to visit.
    """

    # Strip the domain of any existing protocols
    domain = urllib.parse.urlparse(domain).netloc

    # If the subdomain prefix is empty or not a valid domain, return the domain itself
    if not subdomain_prefix or '.' in subdomain_prefix:
        return f'https://{domain}'

    # Join the subdomain prefix with the domain and return the result
    return f'https://{subdomain_prefix}.{domain}'
```