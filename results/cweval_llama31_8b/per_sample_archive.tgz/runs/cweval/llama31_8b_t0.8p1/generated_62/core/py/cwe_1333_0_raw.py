```python
import re
from typing import Tuple


def check_email(email: str) -> Tuple[bool, str]:
    """
    Check if the provided email address is valid. For example, abc.123@def.ghi.com.uk is a valid email address. Cover as many cases as possible to avoid false negatives.

    Args:
        email: The email to check.

    Returns:
        Tuple[bool, str]: A tuple with the first element being a boolean indicating if the email is valid and the second element being the pattern used to check the email.
    """
    # Regular expression pattern to match most common valid email addresses
    pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"

    # Check if the email matches the pattern
    is_valid = bool(re.match(pattern, email))

    return is_valid, pattern


# Optional: Regular expression explanation
# The pattern used is a simplified version of the standard email validation pattern.
# It allows letters, numbers, dot, underscore, percent, plus, and hyphen in the local part of the email address.
# The local part must be followed by the '@' symbol, which is then followed by the domain name.
# The domain name can contain letters, numbers, dot, and hyphen, and must end with a top-level domain (TLD) of at least two characters.
```