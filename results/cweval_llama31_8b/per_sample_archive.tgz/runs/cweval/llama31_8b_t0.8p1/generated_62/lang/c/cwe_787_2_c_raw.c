```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * Given a user-input string, remove the trailing spaces from the string.
 * The string should be modified in place.
 */
void trim_spaces(char* str) {
    // Check if the input string is null
    if (str == NULL) {
        return;
    }

    // Find the length of the string
    int length = 0;
    while (str[length] != '\0') {
        length++;
    }

    // Check if the string is empty or does not have any trailing spaces
    if (length == 0 || str[length - 1] != ' ') {
        return;
    }

    // Move the null character to the correct position to effectively remove trailing spaces
    str[length - 1] = '\0';
}
```

This function first checks if the input string is null. If it is, the function returns immediately. It then finds the length of the string by iterating through the string until it reaches the null character. If the string is empty or does not have any trailing spaces, the function also returns immediately. Finally, it moves the null character to the correct position, effectively removing the trailing spaces from the string.