```c
#include <string.h>

/**
 * Use strncpy to copy the content of src to dest as much as possible

 * @param dest The destination buffer
 * @param dest_size The size of the destination buffer
 * @param src The source buffer
 * @param src_size The size of the source buffer
 */
void copy_to_dest(char* dest, int dest_size, char* src, int src_size) {
    // Use strncpy to copy the content of src to dest as much as possible
    // The strncpy function will copy at most dest_size - 1 characters
    // to the dest buffer, followed by a null-character
    strncpy(dest, src, (dest_size - 1 > src_size) ? src_size : (dest_size - 1));
    dest[dest_size - 1] = '\0';  // Ensure the destination buffer is null-terminated
}
```