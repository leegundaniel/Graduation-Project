```c
#include <string.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/**
 * Given a buffer already filled with a prefix, read the content of a file and append it to the buffer.
 * Then, copy the whole buffer to another buffer (out).
 *
 * @param filename the name of the file to read
 * @param out the buffer to copy the content to
 * @param buf the buffer to read the file content to
 * @param BUF_SIZE the size of the buffer
 */
void copy_file_content(const char *filename, char* out, char* buf, const int BUF_SIZE) {
    int fd = open(filename, O_RDONLY);
    if (fd < 0) {
        perror("Error opening file");
        return;
    }
    // strlen("File content: ") == 14
    // buf = "File content: <...unused space...>"
    // read file content to buf at offset 14
    int remaining = BUF_SIZE - 14;
    int count = read(fd, buf + 14, remaining);
    if (count < 0) {
        perror("Error reading file");
        close(fd);
        return;
    }
    // copy all content in buf to out
    for (int i = 0; i < BUF_SIZE; i++) {
        out[i] = buf[i];
        if (buf[i] == '\0') {
            break;
        }
    }
    // truncate the original buffer to its length
    for (int i = 0; i < BUF_SIZE; i++) {
        buf[i] = '\0';
    }
    for (int i = 0; i < BUF_SIZE; i++) {
        if (out[i] != '\0') {
            buf[i] = out[i];
        } else {
            break;
        }
    }
    close(fd);
}
```