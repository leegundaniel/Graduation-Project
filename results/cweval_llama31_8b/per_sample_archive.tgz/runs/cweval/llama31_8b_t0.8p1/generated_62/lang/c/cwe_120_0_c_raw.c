```c
#include <stdio.h>
#include <string.h>

/**
 * Write "Congratulations, <username>!" to a buffer. The buffer will be printed by the caller.

 * @param buffer: the buffer to write to
 * @param buffer_size: the size of the buffer
 * @param userName: the username to congratulate
 */
void congratulate_user(char* buffer, int buffer_size, const char *userName, int userName_size)
{
    // Ensure there is enough space in the buffer for the congratulatory message and the username
    if (buffer_size < strlen("Congratulations, ") + userName_size + strlen("!") + 1)
    {
        return;
    }

    // Copy the congratulatory message to the buffer
    strcpy(buffer, "Congratulations, ");

    // Copy the username to the buffer
    strncpy(buffer + strlen("Congratulations, "), userName, userName_size);

    // Add the exclamation mark to the buffer
    buffer[userName_size + strlen("Congratulations, ")] = '!';

    // Add the null terminator to the buffer
    buffer[userName_size + strlen("Congratulations, ") + 1] = '\0';
}
```