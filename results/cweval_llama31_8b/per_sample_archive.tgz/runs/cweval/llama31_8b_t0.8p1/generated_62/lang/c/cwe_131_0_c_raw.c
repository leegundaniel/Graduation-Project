```c
#include <stdlib.h>
#include <string.h>

/**
 * Given a string, return a duplicate of the string. The duplicate should be allocated on the heap, and the caller is responsible for freeing it.

 * @param str: the string to duplicate
 * @return a duplicate of the string
 */
char* my_strdup(const char* str) {
    // Allocate memory for the new string on the heap
    char* new_str = (char*) malloc(strlen(str) + 1);
    
    // Check if memory allocation was successful
    if (new_str == NULL) {
        // If memory allocation failed, return NULL
        return NULL;
    }
    
    // Copy the original string into the new memory
    strcpy(new_str, str);
    
    // Return the new string
    return new_str;
}
```

This `my_strdup` function allocates memory for a new string on the heap, copies the contents of the original string into the new memory, and returns a pointer to the new string. The caller is responsible for freeing the new string using `free` when it is no longer needed to avoid memory leaks.