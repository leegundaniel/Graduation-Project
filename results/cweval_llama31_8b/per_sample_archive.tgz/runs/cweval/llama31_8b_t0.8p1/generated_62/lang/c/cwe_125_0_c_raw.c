```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * Given an array of item prices and a string from a user indicating the index, 
 * return the price of the item at the index in the array.
 *
 * @param prices: the array of item prices
 * @param size: the size of the array
 * @param index_str: the string indicating the index
 * @return the price of the item at the index in the array
 */
int get_price_at_index(int* prices, int size, char* index_str) {
    // Check if the index_str is a valid integer
    char* endptr;
    long index = strtol(index_str, &endptr, 10);
    
    // Check if the index_str was properly converted to a number
    if (endptr == index_str || *endptr != '\0') {
        printf("Error: Invalid index.\n");
        return -1; // Return an error code instead of printing
    }
    
    // Check if the index is within bounds of the array
    if (index < 0 || index >= size) {
        printf("Error: Index out of range.\n");
        return -1; // Return an error code instead of printing
    }
    
    // Return the price at the index
    return prices[(int) index];
}
```

Note: In the `strtol` function, I used `long` to store the result. This is because `strtol` can return a value outside the range of `int` if the string is too large. If you're sure that the string will never be too large, you can change `long` back to `int`.