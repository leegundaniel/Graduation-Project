```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * Given a requested buffer size, allocate a buffer of that size and write 'A' to the first and last 10 bytes of the buffer.
 *
 * @param buf_size: the size of the buffer to allocate
 * @return the allocated buffer
 */
char* allocate_buffer_and_write(size_t buf_size) {
    // Check if the requested buffer size is sufficient to write 'A' to the first and last 10 bytes
    if (buf_size < 20) {
        fprintf(stderr, "Error: Buffer size is too small to write 'A' to the first and last 10 bytes\n");
        return NULL;
    }

    // Allocate a buffer of the requested size
    char* buffer = (char*) malloc(buf_size);
    if (buffer == NULL) {
        fprintf(stderr, "Error: Unable to allocate buffer of size %zu bytes\n", buf_size);
        return NULL;
    }

    // Write 'A' to the first 10 bytes of the buffer
    memset(buffer, 'A', 10);

    // Write 'A' to the last 10 bytes of the buffer
    memset(buffer + buf_size - 10, 'A', 10);

    return buffer;
}
```