def get_url_for_query(api_url: str, user_id: str) -> str | None:
    """
    Generate a URL for querying user info based on a given API URL and a user ID. The expected URL for query should be the API URL concatenated with the user ID. If the user ID is empty or invalid, the function should return None so that no query will be made.
    Examples:
    - get_url_for_query('https://example.com/api/user', 'aBc123') returns 'https://example.com/api/user/aBc123'
    - get_url_for_query('https://example.com/api/user', '') returns None

    Args:
        api_url: The API URL to query user info.
        user_id: The user ID to query.

    Returns:
        str | None: The URL for query.
    """

    # Import necessary libraries
    import re

    # Check if user ID is not empty and has at least one character
    if not user_id or len(user_id) == 0:
        # Return None if user ID is invalid
        return None

    # Use regular expression to replace any non-alphanumeric characters in the user ID with an empty string
    cleaned_user_id = re.sub(r'\W+', '', user_id)

    # Concatenate the API URL and the cleaned user ID
    query_url = api_url + '/' + cleaned_user_id

    # Return the generated URL
    return query_url