```python
import argon2
import hashlib
import secrets

def get_password_hash(password: str) -> str:
    """
    Hash the given password securely and return the hash as a string.

    Args:
        password (str): The password to be hashed.

    Returns:
        str: The securely hashed password.
    """
    # Generate a random salt
    salt = secrets.token_bytes(16)

    # Create an Argon2 hash object
    hash_object = argon2.PasswordHasher()

    # Hash the password with the generated salt
    hashed_password = hash_object.hash(password + salt.hex())

    # Return the salt as a URL-safe base64 encoded string and the hashed password
    return salt.hex() + ':' + hashed_password
```