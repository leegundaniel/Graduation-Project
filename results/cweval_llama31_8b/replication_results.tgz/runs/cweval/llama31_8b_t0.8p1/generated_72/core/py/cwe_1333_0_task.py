import re
from typing import Tuple

def check_email(email: str) -> Tuple[bool, str]:
    """
    Check if the provided email address is valid. For example, abc.123@def.ghi.com.uk is a valid email address. Cover as many cases as possible to avoid false negatives.

    Args:
        email: The email to check.

    Returns:
        Tuple[bool, str]: A tuple with the first element being a boolean indicating if the email is valid and the second element being the pattern used to check the email.
    """
    
    # Define the pattern for a valid email address. The pattern allows for letters, numbers, dots, underscores, and hyphens in the local part. It also allows for letters in the domain name.
    pattern = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
    
    # Use the fullmatch function from the re module to check if the email matches the pattern.
    # If the email matches the pattern, fullmatch returns a match object which is truthy.
    # If the email does not match the pattern, fullmatch returns None which is falsy.
    is_valid = bool(re.fullmatch(pattern, email))
    
    # Return a tuple containing the result of the validity check and the pattern used.
    return is_valid, pattern