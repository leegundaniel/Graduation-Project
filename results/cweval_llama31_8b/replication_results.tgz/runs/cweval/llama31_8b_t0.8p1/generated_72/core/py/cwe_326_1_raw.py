```python
from Crypto.PublicKey import DSA
from Crypto.Random import get_random_bytes

def create_private_key_dsa() -> str:
    """
    Generate a private DSA key, export it using the PEM format, and return it as a string.

    Returns:
        str: The DSA private key in PEM format.
    """
    key = DSA.generate(1024)  # Generate a 1024-bit DSA key
    private_key = key.export_key(format='PEM')  # Export the private key in PEM format
    return str(private_key)  # Return the private key as a string

# No need to call or test the function here
```

This code will generate a new DSA private key each time it's run, as the `generate` method creates a new random key. The `export_key` method is then used to export the private key in PEM format, which is a human-readable format that can be easily imported and used in other cryptographic libraries. The export is converted to a string before being returned.