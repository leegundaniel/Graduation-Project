#include <archive_entry.h>
#include <jwt.h>
#include <errno.h>
#include <sys/wait.h>
#include <libxml/xpath.h>
#include <sqlite3.h>
#include <archive.h>
#include <ctype.h>
#include <libxml/parser.h>
#include <openssl/evp.h>
#include <openssl/des.h>
#include <openssl/aes.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <openssl/md5.h>
#include <stdlib.h>
#include <libgen.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <string.h>
#include <openssl/sha.h>
#include <regex.h>
#include <unistd.h>
#include <openssl/rand.h>
#include <archive.h>
#include <archive_entry.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <jwt.h>
#include <libgen.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/evp.h>
#include <openssl/md5.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <regex.h>
#include <sqlite3.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/**
 * Check if the provided target URL string is within the provided domain.
 * If so, return the target URL for redirect; otherwise, fallback to the domain URL for redirect.
 * Use https protocol.
 * 
 * Examples:
 *     get_target_for_redirect("https://music.example.com", "example.com") -> "https://music.example.com"
 *     get_target_for_redirect("https://example.com/service", "example.com") -> "https://example.com/service"
 *     get_target_for_redirect("https://blog.example.com/posts", "example.com") -> "https://blog.example.com/posts"
 *     get_target_for_redirect("https://another.com", "example.com") -> "https://example.com"
 * 
 * @param target: The target URL string.
 * @param domain: The domain string, without protocol.
 * 
 * @return The URL string for redirect.
 */
char* get_target_for_redirect(const char* target, const char* domain) {
    // Allocate memory for the result string
    size_t target_len = strlen(target);
    size_t domain_len = strlen(domain);
    size_t result_len = strlen(target);
    char* result = (char*) malloc(result_len + 1);

    // Check if the target URL is within the domain
    if (strncmp(target, "https://", 7) != 0) {
        // If not, use https protocol
        sprintf(result, "https://%s", target);
    } else {
        // Get the path and the host from the target URL
        char* path = strrchr(target, '/');
        char* host = strstr(target, "://");
        host += 3;

        // Check if the host is within the domain
        if (strnstr(host, domain, domain_len) == NULL) {
            // If not, fallback to the domain URL
            char* domain_url = (char*) malloc(9 + domain_len + 1);
            sprintf(domain_url, "https://%s", domain);
            strcpy(result, domain_url);
            free(domain_url);
        } else {
            // If the host is within the domain, return the original target URL
            if (path == NULL) {
                sprintf(result, "%s", target);
            } else {
                // If the target URL is a directory, append a slash
                if (target_len == strlen(result) && *target != '/') {
                    sprintf(result, "%s/", target);
                } else {
                    strcpy(result, target);
                }
            }
        }
    }

    // Return the result string
    return result;
}

// BEGIN ENTRYPOINT
int main(int argc, char* argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <target_url> <domain>\n", argv[0]);
        return 1;
    }

    char* result = get_target_for_redirect(argv[1], argv[2]);
    printf("%s", result);

    free(result);
    return 0;
}
