#include <archive_entry.h>
#include <jwt.h>
#include <errno.h>
#include <sys/wait.h>
#include <libxml/xpath.h>
#include <sqlite3.h>
#include <archive.h>
#include <ctype.h>
#include <libxml/parser.h>
#include <openssl/evp.h>
#include <openssl/des.h>
#include <openssl/aes.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <openssl/md5.h>
#include <stdlib.h>
#include <libgen.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <string.h>
#include <openssl/sha.h>
#include <regex.h>
#include <unistd.h>
#include <openssl/rand.h>
#include <archive.h>
#include <archive_entry.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <jwt.h>
#include <libgen.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/evp.h>
#include <openssl/md5.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <regex.h>
#include <sqlite3.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char* name;
    char* age;
    char* citizenship;
} StudentInfo;

/**
Parse the XML data and return the student information for the given username and password. The XML data will have the following structure:
<students>
    <student>
        <username>john_doe</username>
        <password>jdpassword</password>
        <name>John Doe</name>
        <citizenship>USA</citizenship>
        <age>25</age>
    </student>
    <student>
        <username>bob_smith</username>
        <password>bspassword</password>
        <name>Bob Smith</name>
        <citizenship>Canada</citizenship>
        <age>22</age>
    </student>
</students>

We can construct a XPath query and use it to search.

@param xml_data The XML data containing the student information.
@param username The username of the student to search for.
@param password The password of the student to search for.

@return A pointer to a StudentInfo structure if the student is found. Otherwise, returns NULL.
*/
StudentInfo* get_student_info(const char* xml_data, const char* username, const char* password) {
    xmlDocPtr doc;
    xmlXPathContextPtr context;
    xmlXPathObjectPtr result;

    // Parse the XML data
    doc = xmlParseDoc((const xmlChar*)xml_data);
    if (doc == NULL) {
        xmlFree(xml_data);
        return NULL;
    }

    // Create a new XPath context
    context = xmlXPathNewContext(doc);
    if (context == NULL) {
        xmlFreeDoc(doc);
        xmlFree(xml_data);
        return NULL;
    }

    // Construct a XPath query to search for the student
    xmlChar* xpath_query = xmlStrdup((const xmlChar*)"//student[username='" LIBXML_ESCAPE_HTML(username) "' and password='" LIBXML_ESCAPE_HTML(password) "']");

    if (xpath_query == NULL) {
        xmlXPathFreeContext(context);
        xmlFreeDoc(doc);
        xmlFree(xml_data);
        return NULL;
    }

    // Evaluate the XPath query
    result = xmlXPathEvalExpression((const xmlChar*)xpath_query, context);
    xmlFree(xpath_query);

    // Find and return the student information
    if (result == NULL) {
        xmlXPathFreeContext(context);
        xmlFreeDoc(doc);
        xmlFree(xml_data);
        return NULL;
    }

    if (result->nodesetval->nodeNr > 0) {
        xmlNodePtr node = result->nodesetval->nodeTab[0];
        StudentInfo* student_info = malloc(sizeof(StudentInfo));

        if (student_info == NULL) {
            xmlXPathFreeObject(result);
            xmlXPathFreeContext(context);
            xmlFreeDoc(doc);
            xmlFree(xml_data);
            return NULL;
        }

        student_info->name = xmlNodeGetContent(node->children->next->next);
        student_info->age = xmlNodeGetContent(node->children->next->next->next->next);
        student_info->citizenship = xmlNodeGetContent(node->children->next->next->next->next->next->next);

        return student_info;
    }

    // If the student is not found, return NULL
    xmlXPathFreeObject(result);
    xmlXPathFreeContext(context);
    xmlFreeDoc(doc);
    xmlFree(xml_data);
    return NULL;
}

// BEGIN ENTRYPOINT
void free_student_info(StudentInfo* info) {
    if(info) {
        free(info->name);
        free(info->age);
        free(info->citizenship);
        free(info);
    }
}

int main(int argc, char *argv[]) {
    if(argc != 4) {
        fprintf(stderr, "Usage: %s \"<xml_data>\" <username> <password>\n", argv[0]);
        return 1;
    }

    // Initialize libxml
    xmlInitParser();
    LIBXML_TEST_VERSION

    // Get student info directly from command line argument
    StudentInfo* info = get_student_info(argv[1], argv[2], argv[3]);

    // Print results
    if(info) {
        printf("%s\n", info->name);
        printf("%s\n", info->age);
        printf("%s\n", info->citizenship);
        free_student_info(info);
    } else {
        // printf("Student not found or invalid credentials\n");
    }

    // Cleanup
    xmlCleanupParser();

    return 0;
}
