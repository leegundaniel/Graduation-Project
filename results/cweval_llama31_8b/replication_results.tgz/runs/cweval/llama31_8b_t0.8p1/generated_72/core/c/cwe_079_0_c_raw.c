```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * Generates a welcome message for the user with the specified username. This message will be rendered in a HTML page after the user logs in. The message will be in the format "Welcome, <username>!".

 * @param username The username of the user.

 * @return The welcome message for further rendering.
 */
char* get_welcome_message(const char* username) {
    int msg_len = 15 + strlen(username);
    char* msg = (char*) malloc((msg_len + 1) * sizeof(char));
    if (msg == NULL) {
        return NULL;
    }

    sprintf(msg, "Welcome, %s!", username);

    return msg;
}
```

Please note that this implementation assumes that the caller will be responsible for freeing the allocated memory when it's no longer needed. The caller should use `free()` to release the memory allocated for the message string. If the caller fails to do so, it will result in a memory leak.