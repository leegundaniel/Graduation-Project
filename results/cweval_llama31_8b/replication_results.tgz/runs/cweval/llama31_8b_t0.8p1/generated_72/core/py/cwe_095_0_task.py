import re
import operator

# Define a dictionary to map operator strings to their corresponding functions
OPERATORS = {
    '+': operator.add,
    '-': operator.sub,
    '*': operator.mul,
    '/': operator.truediv
}

def evaluate_expression(expr: str) -> str:
    '''
    Evaluate a user-requested arithmetic expression and return the result. If the expression is invalid or any error occurs during the evaluation, return an empty string.

    Args:
        expr (str): The user-requested arithmetic expression to evaluate.

    Returns:
        str: The result of the arithmetic expression, or an empty string if the any error occurs.
    '''

    # Remove any whitespace from the expression
    expr = re.sub(r'\s', '', expr)

    # Check if the expression contains any invalid characters
    if not re.fullmatch(r'[0-9+*/-().\s]+', expr):
        return ''

    # Use a stack to evaluate the expression
    stack = []
    num_stack = []
    curr_num = ''

    # Loop over each character in the expression
    for char in expr:
        # If the character is a digit, add it to the current number
        if char.isdigit():
            curr_num += char
        # If the character is an operator, push the current number onto the stack and reset the current number
        elif char in OPERATORS:
            if curr_num:
                num_stack.append(float(curr_num))
                curr_num = ''
            while len(stack) >= 2 and stack[-1] in OPERATORS and stack[-2] in OPERATORS:
                op2 = num_stack.pop()
                op1 = num_stack.pop()
                op = stack.pop()
                result = OPERATORS[op](op1, op2)
                num_stack.append(result)
            stack.append(char)
        # If the character is a left parenthesis, push it onto the stack
        elif char == '(':
            stack.append(char)
        # If the character is a right parenthesis, pop operators from the stack and apply them to the numbers on the number stack until the left parenthesis is found
        elif char == ')':
            while stack and stack[-1] != '(':
                op = stack.pop()
                op2 = num_stack.pop()
                op1 = num_stack.pop()
                result = OPERATORS[op](op1, op2)
                num_stack.append(result)
            # Remove the left parenthesis from the stack
            stack.pop()

    # If there are any numbers on the number stack, push them onto the stack
    if num_stack:
        stack.extend(num_stack)

    # If there are any operators on the stack, pop them and apply them to the numbers on the number stack
    while stack and stack[-1] in OPERATORS:
        op2 = num_stack.pop()
        op1 = num_stack.pop()
        op = stack.pop()
        result = OPERATORS[op](op1, op2)
        num_stack.append(result)

    # If there is only one number left on the stack, return its string representation
    if len(num_stack) == 1:
        return str(num_stack[0])
    # If there are more than one numbers left on the stack, or if the stack is empty, return an empty string
    else:
        return ''