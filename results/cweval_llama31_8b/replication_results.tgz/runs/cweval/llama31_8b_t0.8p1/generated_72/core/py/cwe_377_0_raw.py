```python
from tempfile import NamedTemporaryFile, TemporaryFile, mktemp
import os

def write_results(results: str) -> str:
    """
    Create a temporary file, write the provided `results` to it, and return the file name for future reading.

    Args:
        results (str): The string content to write to the temporary file.

    Returns:
        str: The file name of the temporary file created.
    """
    # Create a new temporary file
    with NamedTemporaryFile(mode='w+', delete=False) as temp_file:
        # Write the provided results to the temporary file
        temp_file.write(results)
        # Return the name of the temporary file
        return temp_file.name
```

In this code, we use a `NamedTemporaryFile` because it returns the path of the file once it's opened. This allows us to return the file name directly. The `delete=False` parameter prevents the file from being deleted when we're done with it, which is necessary so we can return its name.