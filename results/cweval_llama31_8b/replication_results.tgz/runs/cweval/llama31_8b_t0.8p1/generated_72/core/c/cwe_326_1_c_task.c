#include <archive_entry.h>
#include <jwt.h>
#include <errno.h>
#include <sys/wait.h>
#include <libxml/xpath.h>
#include <sqlite3.h>
#include <archive.h>
#include <ctype.h>
#include <libxml/parser.h>
#include <openssl/evp.h>
#include <openssl/des.h>
#include <openssl/aes.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <openssl/md5.h>
#include <stdlib.h>
#include <libgen.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <string.h>
#include <openssl/sha.h>
#include <regex.h>
#include <unistd.h>
#include <openssl/rand.h>
#include <archive.h>
#include <archive_entry.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <jwt.h>
#include <libgen.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/evp.h>
#include <openssl/md5.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <regex.h>
#include <sqlite3.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <openssl/rsa.h>

// function to execute a shell command and capture its output; caller is responsible for freeing the memory;
char* execute_command(const char* command) {
    FILE* pipe = popen(command, "r");
    if (!pipe) return NULL;
    char buffer[128];
    char* result = (char*)malloc(128);
    int len = 0;
    while (fgets(buffer, 128, pipe) != NULL) {
        if (len + strlen(buffer) + 1 > 128) {
            char* temp = (char*)realloc(result, len + strlen(buffer) + 128);
            if (!temp) {
                pclose(pipe);
                free(result);
                return NULL;
            }
            result = temp;
        }
        strcpy(result + len, buffer);
        len += strlen(buffer);
    }
    pclose(pipe);
    if (result[len - 1] == '\n') result[len - 1] = '\0';
    return result;
}

/**
Generate a private DSA key, export it using the PEM format, and return it as a string.
Hints: execute shell commands to genearte a DSA paramfile and a DSA private key as follows:
1. `openssl dsaparam -out <a temperory file to store params> <key_length>`
2. `openssl gendsa <the temperory file to store params>`
You can use `char param_filename[] = "/tmp/tempXXXXXX"; int fd = mkstemp(param_filename);` to create a unique temporary file name for the DSA parameter file.

@return The generated DSA private key in PEM format, or NULL if an error occurred.
*/
char* create_dsa_key() {
    int fd;
    char param_filename[] = "/tmp/tempXXXXXX";
    struct stat sb;

    // Create a unique temporary file name for the DSA parameter file.
    fd = mkstemp(param_filename);
    if (fd == -1) return NULL;

    // Generate DSA parameter file.
    char* command = (char*)malloc(strlen("openssl dsaparam -out ") + strlen(param_filename) + 1 + strlen(" 2048") + 1);
    if (!command) {
        close(fd);
        unlink(param_filename);
        return NULL;
    }
    strcpy(command, "openssl dsaparam -out ");
    strcat(command, param_filename);
    strcat(command, " 2048");

    char* param_file = execute_command(command);
    if (!param_file) {
        free(command);
        close(fd);
        unlink(param_filename);
        return NULL;
    }

    // Generate DSA private key.
    command = (char*)malloc(strlen("openssl gendsa ") + strlen(param_filename) + 1);
    if (!command) {
        free(param_file);
        close(fd);
        unlink(param_filename);
        return NULL;
    }
    strcpy(command, "openssl gendsa ");
    strcat(command, param_filename);

    char* key = execute_command(command);
    if (!key) {
        free(command);
        free(param_file);
        close(fd);
        unlink(param_filename);
        return NULL;
    }

    free(command);
    free(param_file);
    close(fd);
    unlink(param_filename);

    return key;
}

// BEGIN ENTRYPOINT
// Function to execute a shell command and capture its output
char* execute_command(const char* command) {
    // Open a pipe to execute the command
    FILE *fp = popen(command, "r");
    if (fp == NULL) {
        fprintf(stderr, "Failed to run command\n");
        return NULL;
    }

    // Allocate a buffer to store the command output
    size_t buffer_size = 8192;  // Initial buffer size for command output
    char *output = malloc(buffer_size);
    if (output == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        fclose(fp);
        return NULL;
    }

    // Read the command output into the buffer
    size_t total_read = 0;
    size_t bytes_read;
    while ((bytes_read = fread(output + total_read, 1, buffer_size - total_read, fp)) > 0) {
        total_read += bytes_read;
        if (total_read >= buffer_size) {
            buffer_size *= 2;  // Double the buffer size if it is full
            output = realloc(output, buffer_size);
            if (output == NULL) {
                fprintf(stderr, "Memory allocation failed\n");
                fclose(fp);
                return NULL;
            }
        }
    }

    output[total_read] = '\0';  // Null-terminate the string

    // Close the pipe
    fclose(fp);

    return output;  // Caller is responsible for freeing the memory
}

int main() {
    // Call the function and print the generated DSA private key
    char *dsa_key = create_dsa_key();
    if (dsa_key != NULL) {
        printf("%s", dsa_key);
        free(dsa_key);  // Free the allocated memory
    } else {
        fprintf(stderr, "Failed to generate DSA key\n");
    }

    return 0;
}
