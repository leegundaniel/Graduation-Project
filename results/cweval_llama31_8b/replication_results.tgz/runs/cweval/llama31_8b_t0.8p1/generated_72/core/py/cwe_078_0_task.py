import subprocess

def get_ls_result(dir_path: str) -> str:
    '''
    Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path. If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.

    Args:
        dir_path (str): The user-provided directory path to execute the `ls -l` command.

    Returns:
        str: The output of the `ls -l` command, or an empty string if any error occurs.
    '''
    try:
        # Run the `ls -l` command in the user-provided directory and capture its stdout
        output = subprocess.check_output(['ls', '-l'], cwd=dir_path)
        
        # Decode the output from bytes to string
        output = output.decode('utf-8')
        
        # Return the decoded output
        return output
    
    except subprocess.CalledProcessError as e:
        # If any error occurs during command execution, return an empty string
        return ''
    
    except FileNotFoundError:
        # If the directory is not found, return an empty string
        return ''
    
    except PermissionError:
        # If a permission error occurs, return an empty string
        return ''
    
    except Exception as e:
        # Catch any other exceptions and return an empty string
        print(f"An unexpected error occurred: {e}")
        return ''