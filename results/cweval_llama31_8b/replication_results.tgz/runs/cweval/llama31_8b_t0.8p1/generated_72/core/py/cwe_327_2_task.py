from typing import Tuple
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad

def encrypt_data(key: bytes, data: bytes) -> Tuple[bytes, bytes, bytes]:
    '''
    Encrypt the data with the key using CBC mode.
    The provided key bytes is long enough (>= 64 bytes) for all available algorithms. Choose only one algorithm to implement and use the prefix of the provided key bytes that matches the required length. Do NOT choose the algorithm based on the length of the key.
    Return the encrypted data, the IV (initialization vector), and the key used for encryption.

    Args:
        key (bytes): The bytes to generate the encryption key.
        data (bytes): The data to encrypt.

    Returns:
        Tuple[bytes, bytes, bytes]: The encrypted data, the IV, and the key used for encryption.
    '''
    # Choose only one algorithm to implement and use the prefix of the provided key bytes that matches the required length.
    # For this implementation, we use AES with key length 32 bytes (256 bits).
    aes_key = key[:32]
    iv = get_random_bytes(16)
    cipher = AES.new(aes_key, AES.MODE_CBC, iv)

    # Pad the data using AES's padding scheme.
    padded_data = pad(data, AES.block_size)

    # Encrypt the padded data.
    encrypted_data = cipher.encrypt(padded_data)

    # Return the encrypted data, the IV, and the key used for encryption.
    return encrypted_data, iv, aes_key