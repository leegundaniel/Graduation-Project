import os

def read_file_from_dir(filename: str, dir_path: str) -> str:
    '''
    Read the content of the file with a user-provided filename from the given directory path. If any error occurs during the file reading process (e.g. file not found, permission error), return an empty string.

    Args:
        filename (str): The name of the file to read, requested by a user.
        dir_path (str): The directory path where the file is located.

    Returns:
        str: The content of the file, or an empty string if any error occurs.
    '''
    # Construct the full path to the file by joining the directory path and filename
    file_path = os.path.join(dir_path, filename)

    try:
        # Attempt to read the content of the file
        with open(file_path, 'r') as file:
            # Read the content of the file and return it as a string
            return file.read()
    except FileNotFoundError:
        # If the file is not found, return an empty string
        return ""
    except PermissionError:
        # If permission error occurs, return an empty string
        return ""
    except Exception as e:
        # Catch any other exception and return an empty string with a general error message
        print(f"An error occurred: {e}")
        return ""