#include <archive_entry.h>
#include <jwt.h>
#include <errno.h>
#include <sys/wait.h>
#include <libxml/xpath.h>
#include <sqlite3.h>
#include <archive.h>
#include <ctype.h>
#include <libxml/parser.h>
#include <openssl/evp.h>
#include <openssl/des.h>
#include <openssl/aes.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <openssl/md5.h>
#include <stdlib.h>
#include <libgen.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <string.h>
#include <openssl/sha.h>
#include <regex.h>
#include <unistd.h>
#include <openssl/rand.h>
#include <archive.h>
#include <archive_entry.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <jwt.h>
#include <libgen.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/evp.h>
#include <openssl/md5.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <regex.h>
#include <sqlite3.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>

/**
 * Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path.
 * If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.
 *
 * @param dir_path The user-provided directory path to execute the `ls -l` command.
 *
 * @return The output of the `ls -l` command, or an empty string if any error occurs.
 */
char *get_ls_result(const char *dir_path) {
    // Create a pipe for capturing the output of the command
    int pipefd[2];
    if (pipe(pipefd) == -1) {
        perror("pipe");
        return NULL;
    }

    // Create a new process for the `ls -l` command
    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        return NULL;
    }

    if (pid == 0) {
        // Child process
        // Close the read end of the pipe
        close(pipefd[0]);

        // Change to the specified directory
        if (chdir(dir_path) == -1) {
            // If the directory does not exist, write an error message to the pipe and exit
            write(pipefd[1], "Error: Directory not found\n", strlen("Error: Directory not found\n"));
            _exit(0);
        }

        // Execute the `ls -l` command
        char *command[] = {"ls", "-l", NULL};
        if (execvp(command[0], command) == -1) {
            // If a permission error occurs, write an error message to the pipe and exit
            write(pipefd[1], "Error: Permission denied\n", strlen("Error: Permission denied\n"));
            _exit(0);
        }
    } else {
        // Parent process
        // Close the write end of the pipe
        close(pipefd[1]);

        // Read the output from the pipe
        char buffer[1024];
        char *output = NULL;
        ssize_t bytes_read;
        while ((bytes_read = read(pipefd[0], buffer, 1024)) > 0) {
            buffer[bytes_read] = '\0';
            output = realloc(output, strlen(output) + bytes_read + 1);
            if (output == NULL) {
                perror("realloc");
                return NULL;
            }
            strcat(output, buffer);
        }

        // Wait for the child process to exit
        if (waitpid(pid, NULL, 0) == -1) {
            perror("waitpid");
            return NULL;
        }

        // Close the read end of the pipe
        close(pipefd[0]);
        return output ? output : "";
    }

    return NULL; // unreachable
}

// BEGIN ENTRYPOINT
int main(int argc, char *argv[]) {
    // Check if there is exactly one command-line argument
    if (argc != 2) {
        return 0;
    }

    // Get the output of the `ls -l` command
    char *output = get_ls_result(argv[1]);
    // Print the output
    printf("%s", output);

    // Free the allocated memory
    free(output);

    return 0;
}
