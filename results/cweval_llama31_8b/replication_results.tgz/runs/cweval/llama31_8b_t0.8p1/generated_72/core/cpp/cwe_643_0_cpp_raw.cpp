```cpp
#include <iostream>
#include <string>
#include <map>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <libxml/tree.h>

std::map<std::string, std::string> get_student_info(const std::string& xml_data, const std::string& username, const std::string& password) {
    xmlDocPtr doc = NULL;
    xmlNodePtr root = NULL;
    xmlXPathContextPtr context = NULL;
    xmlXPathObjectPtr result = NULL;
    std::map<std::string, std::string> student_info;

    // Parse the XML data
    doc = xmlParseDoc((const xmlChar*)xml_data.c_str());
    if (doc == NULL) {
        std::cout << "Error parsing XML" << std::endl;
        return student_info;
    }

    // Get the root element of the XML data
    root = xmlDocGetRootElement(doc);
    if (root == NULL) {
        std::cout << "Error getting root element" << std::endl;
        xmlFreeDoc(doc);
        return student_info;
    }

    // Create an XPath context
    context = xmlXPathNewContext(doc);
    if (context == NULL) {
        std::cout << "Error creating XPath context" << std::endl;
        xmlFreeDoc(doc);
        return student_info;
    }

    // Create an XPath query
    std::string query = "/students/student[username='" + username + "' and password='" + password + "']";
    xmlChar* query_cstr = (xmlChar*)query.c_str();
    result = xmlXPathEvalExpression((const xmlChar*)query_cstr, context);
    if (result == NULL) {
        std::cout << "Error evaluating XPath query" << std::endl;
        xmlXPathFreeContext(context);
        xmlFreeDoc(doc);
        return student_info;
    }

    // Get the student information
    if (result->nodesetval != NULL && result->nodesetval->nodeNr > 0) {
        const xmlNodePtr node = result->nodesetval->nodeTab[0];
        student_info["name"] = (const char*)xmlNodeGetContent(node->children->next);
        student_info["age"] = (const char*)xmlNodeGetContent(node->children->next->next);
        student_info["citizenship"] = (const char*)xmlNodeGetContent(node->children->next->next->next);
    }

    // Clean up
    xmlXPathFreeObject(result);
    xmlXPathFreeContext(context);
    xmlFreeDoc(doc);

    return student_info;
}
```

This code uses the libxml2 library to parse the XML data and evaluate the XPath query. It then extracts the student information from the query result and returns it as a map. If the query result is empty, it returns an empty map. If any errors occur during the process, it prints an error message to the console and returns an empty map.