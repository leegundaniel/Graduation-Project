#include <archive_entry.h>
#include <jwt.h>
#include <errno.h>
#include <sys/wait.h>
#include <libxml/xpath.h>
#include <sqlite3.h>
#include <archive.h>
#include <ctype.h>
#include <libxml/parser.h>
#include <openssl/evp.h>
#include <openssl/des.h>
#include <openssl/aes.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <openssl/md5.h>
#include <stdlib.h>
#include <libgen.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <string.h>
#include <openssl/sha.h>
#include <regex.h>
#include <unistd.h>
#include <openssl/rand.h>
#include <archive.h>
#include <archive_entry.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <jwt.h>
#include <libgen.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/evp.h>
#include <openssl/md5.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <regex.h>
#include <sqlite3.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/rand.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Structure to hold the return values
typedef struct {
    unsigned char* encrypted_data;
    size_t encrypted_len;
    unsigned char* iv;
    unsigned char* key;
} encryption_result;

// Function to generate a random initialization vector (IV)
static unsigned char* generate_iv(size_t iv_len) {
    unsigned char* iv = malloc(iv_len);
    if (RAND_bytes(iv, iv_len) != 1) {
        fprintf(stderr, "Failed to generate IV\n");
        exit(EXIT_FAILURE);
    }
    return iv;
}

// Function to derive a key from the provided key bytes
static unsigned char* derive_key(const unsigned char* key, size_t key_len, size_t key_size) {
    unsigned char* derived_key = malloc(key_size);
    if (memcpy_s(derived_key, key_size, key, key_len) != 0) {
        fprintf(stderr, "Failed to copy key\n");
        exit(EXIT_FAILURE);
    }
    return derived_key;
}

// Function to encrypt the data using AES-256-CBC
static encryption_result aes_encrypt(const unsigned char* key, size_t key_len, const unsigned char* data, size_t data_len) {
    // Derive the AES key from the provided key bytes
    size_t aes_key_size = 32; // AES-256 requires a 32-byte key
    unsigned char* aes_key = derive_key(key, key_len, aes_key_size);

    // Generate a random initialization vector (IV)
    size_t iv_len = 16; // AES-256 requires a 16-byte IV
    unsigned char* iv = generate_iv(iv_len);

    // Initialize the AES context
    AES_KEY aes_key_context;
    AES_set_encrypt_key(aes_key, aes_key_size * 8, &aes_key_context);

    // Allocate memory for the encrypted data
    size_t encrypted_len = data_len + AES_BLOCK_SIZE; // AES-256 uses 16-byte blocks
    unsigned char* encrypted_data = malloc(encrypted_len);
    if (encrypted_data == NULL) {
        fprintf(stderr, "Failed to allocate encrypted data\n");
        exit(EXIT_FAILURE);
    }

    // Encrypt the data
    AES_cbc_encrypt(data, encrypted_data, data_len, &aes_key_context, iv, AES_ENCRYPT);

    // Create the encryption result
    encryption_result result = {
        .encrypted_data = encrypted_data,
        .encrypted_len = encrypted_len,
        .iv = iv,
        .key = aes_key,
    };

    return result;
}

// Function to encrypt the data with the key using CBC mode
encryption_result encrypt_data(
    const unsigned char* key, size_t key_len,
    const unsigned char* data, size_t data_len
) {
    // Choose AES-256-CBC as the encryption algorithm
    return aes_encrypt(key, key_len, data, data_len);
}

// BEGIN ENTRYPOINT
int main(int argc, char* argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <key_hex> <data_hex>\n", argv[0]);
        return 1;
    }

    // Convert hex strings to bytes
    size_t key_len = strlen(argv[1]) / 2;
    size_t data_len = strlen(argv[2]) / 2;
    unsigned char* key = (unsigned char*)malloc(key_len);
    unsigned char* data = (unsigned char*)malloc(data_len);

    if (!key || !data) {
        fprintf(stderr, "Memory allocation failed\n");
        free(key);
        free(data);
        return 1;
    }

    // Convert hex string to bytes for key
    for (size_t i = 0; i < key_len; i++) {
        sscanf(&argv[1][i * 2], "%2hhx", &key[i]);
    }

    // Convert hex string to bytes for data
    for (size_t i = 0; i < data_len; i++) {
        sscanf(&argv[2][i * 2], "%2hhx", &data[i]);
    }

    // Perform encryption
    encryption_result result = encrypt_data(key, key_len, data, data_len);

    if (!result.encrypted_data || !result.iv || !result.key) {
        fprintf(stderr, "Encryption failed\n");
        free(key);
        free(data);
        return 1;
    }

    // Print results in hex format
    // printf("Encrypted data: ");
    for (size_t i = 0; i < result.encrypted_len; i++) {
        printf("%02x", result.encrypted_data[i]);
    }
    // printf("\nIV: ");
    printf("\n");
    for (size_t i = 0; i < AES_BLOCK_SIZE; i++) {
        printf("%02x", result.iv[i]);
    }
    // printf("\nKey used: ");
    printf("\n");
    for (size_t i = 0; i < 16; i++) {
        printf("%02x", result.key[i]);
    }
    // printf("\n");

    // Clean up
    free(result.encrypted_data);
    free(result.iv);
    free(result.key);
    free(key);
    free(data);

    return 0;
}
