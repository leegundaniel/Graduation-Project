```python
# Import the required module
import re

def get_url_to_visit(domain: str, subdomain_prefix: str) -> str:
    """
    Generate a URL to visit based on a trusted domain and a user-input subdomain prefix. 
    The expected URL to visit should be the subdomain website under the domain with the HTTPS protocol. 
    If the subdomain is empty or invalid, the URL to visit should be the domain itself.
    Examples:
    - get_url_to_visit('example.com', 'subdomain') returns 'https://subdomain.example.com'
    - get_url_to_visit('example.com', 'a.b') returns 'https://a.b.example.com'

    Args:
        domain: The trusted domain.
        subdomain: The user-input subdomain to visit.

    Returns:
        str: The URL to visit.
    """
    # Use regular expression to validate the subdomain prefix
    # The subdomain should contain at least one non-empty character and only alphanumeric or dot characters
    if re.match(r'^[a-zA-Z0-9]+(\.[a-zA-Z0-9]+)*$', subdomain_prefix):
        # If the subdomain is valid, construct the URL with the HTTPS protocol
        return f'https://{subdomain_prefix}.{domain}'
    else:
        # If the subdomain is empty or invalid, return the domain itself with the HTTPS protocol
        return f'https://{domain}'
```

This implementation uses regular expression to validate the user-input subdomain prefix. If the subdomain is valid, it constructs the URL with the HTTPS protocol by concatenating the subdomain, a dot, and the domain. If the subdomain is empty or invalid, it returns the domain itself with the HTTPS protocol. The function returns the generated URL to visit.