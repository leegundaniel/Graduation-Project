```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/evp.h>
#include <openssl/rand.h>

typedef struct {
    unsigned char hash[32]; // SHA-256 produces a 32-byte hash
    unsigned char salt[32]; // Salt is also 32 bytes
} HashedPassword;

/**
Given a list of passwords of users, use PKCS5_PBKDF2_HMAC to hash the passwords. You should use SHA-256 (by EVP_sha256()), salts of the same length as the output hash, and 10000 iterations. Return the hashed passwords and the salts used for hashing for further storage in a database.

@param count The number of passwords to hash.
@param usernames A list of usernames.
@param passwords A list of passwords of the users to hash.

@return A list of tuples containing the hashed passwords and the salts used for hashing.
*/
HashedPassword* hash_passwords(int count, char** usernames, char** passwords) {
    HashedPassword* hashed_passwords = malloc(count * sizeof(HashedPassword));
    
    if (hashed_passwords == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        return NULL;
    }

    for (int i = 0; i < count; i++) {
        // Generate a random 32-byte salt
        RAND_bytes(hashed_passwords[i].salt, 32);
        
        // Use PKCS5_PBKDF2_HMAC with SHA-256, 10000 iterations and the generated salt
        int hashed_bytes = PKCS5_PBKDF2_HMAC(passwords[i], strlen(passwords[i]), 
                                             hashed_passwords[i].salt, 32, 
                                             10000, EVP_sha256(), 32, 
                                             hashed_passwords[i].hash);
        
        if (hashed_bytes != 32) {
            fprintf(stderr, "Error hashing password\n");
        }
    }

    return hashed_passwords;
}
```

This implementation allocates memory for the `hashed_passwords` array and then iterates over the list of passwords. For each password, it generates a random 32-byte salt, hashes the password using `PKCS5_PBKDF2_HMAC` with SHA-256, 10000 iterations and the generated salt, and stores the hashed password and salt in the corresponding element of the `hashed_passwords` array. If any memory allocation or hashing operation fails, it prints an error message and returns `NULL`.