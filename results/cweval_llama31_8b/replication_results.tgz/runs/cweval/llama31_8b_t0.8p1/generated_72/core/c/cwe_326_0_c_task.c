#include <archive_entry.h>
#include <jwt.h>
#include <errno.h>
#include <sys/wait.h>
#include <libxml/xpath.h>
#include <sqlite3.h>
#include <archive.h>
#include <ctype.h>
#include <libxml/parser.h>
#include <openssl/evp.h>
#include <openssl/des.h>
#include <openssl/aes.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <openssl/md5.h>
#include <stdlib.h>
#include <libgen.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <string.h>
#include <openssl/sha.h>
#include <regex.h>
#include <unistd.h>
#include <openssl/rand.h>
#include <archive.h>
#include <archive_entry.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <jwt.h>
#include <libgen.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/evp.h>
#include <openssl/md5.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <regex.h>
#include <sqlite3.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>
#include <libgen.h>

#define MAX_KEY_LENGTH 4096
#define BUFFER_SIZE 1024

char *create_private_key() {
    // Allocate memory for the key string
    char *key = malloc(MAX_KEY_LENGTH);
    if (key == NULL) {
        return NULL;  // Out of memory
    }

    // Execute the command to generate the key
    char *cmd = malloc(strlen("openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 2>/dev/null") + 1);
    if (cmd == NULL) {
        free(key);
        return NULL;  // Out of memory
    }
    strcpy(cmd, "openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 2>/dev/null");
    pid_t pid = fork();
    if (pid == -1) {
        free(key);
        free(cmd);
        return NULL;  // Failed to fork
    } else if (pid == 0) {
        // Child process
        dup2(fileno(popen(cmd, "r")), 0);  // Redirect stdin
        execl("/bin/sh", "sh", "-c", cmd, NULL);
        free(key);
        free(cmd);
        return NULL;  // Failed to execute command
    }
    FILE *file = popen(cmd, "r");
    if (file == NULL) {
        waitpid(pid, NULL, 0);  // Wait for child to finish
        free(key);
        free(cmd);
        return NULL;  // Failed to open file
    }

    // Read the key from the file
    char buffer[BUFFER_SIZE];
    int bytes_read = fread(buffer, 1, BUFFER_SIZE, file);
    while (bytes_read > 0) {
        // Copy the key to the allocated memory
        char *ptr = key;
        while (ptr < key + MAX_KEY_LENGTH - bytes_read) {
            *ptr++ = buffer[bytes_read - (ptr - key)];
        }
        bytes_read = fread(buffer, 1, BUFFER_SIZE, file);
    }

    // Close the file and wait for the child to finish
    pclose(file);
    waitpid(pid, NULL, 0);
    free(cmd);

    // Null-terminate the string
    key[MAX_KEY_LENGTH - 1] = '\0';

    return key;
}

// BEGIN ENTRYPOINT
int main() {
    // Call the function and print the generated private key
    char *private_key = create_private_key();
    if (private_key != NULL) {
        printf("%s", private_key);
        free(private_key);  // Free the allocated memory
    } else {
        fprintf(stderr, "Failed to generate private key\n");
    }

    return 0;
}
