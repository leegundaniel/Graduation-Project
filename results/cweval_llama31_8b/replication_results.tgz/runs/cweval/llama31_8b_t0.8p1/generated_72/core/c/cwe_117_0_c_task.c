#include <archive_entry.h>
#include <jwt.h>
#include <errno.h>
#include <sys/wait.h>
#include <libxml/xpath.h>
#include <sqlite3.h>
#include <archive.h>
#include <ctype.h>
#include <libxml/parser.h>
#include <openssl/evp.h>
#include <openssl/des.h>
#include <openssl/aes.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <openssl/md5.h>
#include <stdlib.h>
#include <libgen.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <string.h>
#include <openssl/sha.h>
#include <regex.h>
#include <unistd.h>
#include <openssl/rand.h>
#include <archive.h>
#include <archive_entry.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <jwt.h>
#include <libgen.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/evp.h>
#include <openssl/md5.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <regex.h>
#include <sqlite3.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#define MAX_MSG_LEN 256

#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>

/**
 * Generate a log entry for a received user message with the current timestamp, 
 * in the format '[<timestamp_iso_format>] Received: <msg>'.
 *
 * @param msg The user message received.
 *
 * @return The log entry for the received message.
 */
char* generate_receive_log(const char *msg) {
    // Get the current time in seconds since the epoch
    time_t now = time(NULL);

    // Convert the time to a string in ISO format
    char timestamp_iso_format[32];
    strftime(timestamp_iso_format, 32, "%Y-%m-%dT%H:%M:%S", localtime(&now));

    // Create a buffer for the log entry
    char log_entry[MAX_MSG_LEN];
    sprintf(log_entry, "[%s] Received: %s", timestamp_iso_format, msg);

    // Allocate memory for the log entry string
    char* log_entry_str = malloc(strlen(log_entry) + 1);

    // Copy the log entry to the allocated memory
    strcpy(log_entry_str, log_entry);

    // Return the log entry string
    return log_entry_str;
}

// BEGIN ENTRYPOINT
int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <message>\n", argv[0]);
        return EXIT_FAILURE;
    }

    // Ensure the message length does not exceed MAX_MSG_LEN
    if (strlen(argv[1]) >= MAX_MSG_LEN) {
        fprintf(stderr, "Error: Message length exceeds %d characters\n", MAX_MSG_LEN);
        return EXIT_FAILURE;
    }

    // Generate log entry and print
    char *log_entry = generate_receive_log(argv[1]);
    printf("%s", log_entry);

    // Free allocated memory
    free(log_entry);

    return EXIT_SUCCESS;
}
