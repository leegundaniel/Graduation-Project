```python
from Crypto.PublicKey import RSA
import os

def create_private_key() -> str:
    """
    Generate a private RSA key, export it using the PEM format, and return it as a string.

    Returns:
        str: The RSA private key in PEM format.
    """
    # Generate a new RSA private key with a key size of 2048 bits
    key = RSA.generate(2048)

    # Export the private key to a PEM-formatted string
    private_key = key.export_key(format='PEM')

    # Decode the PEM-formatted string from bytes to a string
    private_key = private_key.decode('utf-8')

    # Remove any extra newlines
    private_key = os.linesep.join([s for s in private_key.splitlines() if s])

    # Return the private key
    return private_key
```