```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * Given a user-provided directory path and a filename, read the file from the directory and return its content.
 * If any error occurs during the file reading process (e.g. file not found, permission error), return an empty string.
 * The returned string will be freed by the caller.
 *
 * @param filename The name of the file to read, requested by a user.
 * @param dir_path The path of the directory where the file is located.
 *
 * @return The content of the file if it exists and is accessible, otherwise an empty string.
 */
char *read_file_from_dir(const char *filename, const char *dir_path) {
    // Construct the full path of the file by joining the directory path and the filename
    char full_path[1024];
    sprintf(full_path, "%s/%s", dir_path, filename);

    // Open the file in read mode
    FILE *file = fopen(full_path, "r");
    if (file == NULL) {
        // If the file cannot be opened, return an empty string
        return strdup("");
    }

    // Initialize the buffer to store the file content
    char buffer[1024];
    char *content = NULL;
    size_t length = 0;

    // Read the file content line by line
    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        // Allocate more memory if needed
        char *new_content = realloc(content, length + strlen(buffer) + 1);
        if (new_content == NULL) {
            fclose(file);
            free(content);
            return strdup("");
        }
        // Append the new line to the content
        content = new_content;
        strcat(content + length, buffer);
        length += strlen(buffer);
    }

    // Close the file
    fclose(file);

    // Remove the newline character at the end of the content
    if (length > 0 && content[length - 1] == '\n') {
        content[length - 1] = '\0';
    }

    return content;
}
```

This implementation reads the file line by line to avoid loading the entire file into memory at once. It uses `realloc` to dynamically allocate more memory if needed. The returned string will be freed by the caller. If any error occurs during the file reading process, an empty string is returned.