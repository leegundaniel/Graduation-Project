```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * Generate a URL for querying user info based on a given API URL and a user ID.
 * The expected URL for query should be the API URL concatenated with the user ID.
 * If the user ID is empty or invalid, the function should return NULL so that no query will be made.
 *
 * Examples:
 * - get_url_for_query("https://example.com/api/user", "aBc123") returns 'https://example.com/api/user/aBc123'
 * - get_url_for_query("https://example.com/api/user", "") returns NULL
 *
 * @param api_url: The API URL to query user info.
 * @param user_id: The user ID to query.
 *
 * @return The URL for query. If the user ID is empty or invalid, return NULL.
 */
char* get_url_for_query(const char* api_url, const char* user_id) {
    if (user_id == NULL || strlen(user_id) == 0) {
        return NULL;
    }

    int api_url_len = strlen(api_url);
    int url_len = api_url_len + strlen(user_id) + 1; // +1 for the '/' between api_url and user_id

    char* url = (char*) malloc((url_len + 1) * sizeof(char));
    if (url == NULL) {
        return NULL;
    }

    strcpy(url, api_url);
    strcat(url, "/");
    strcat(url, user_id);

    return url;
}

// Note: This implementation does not handle the case where the API URL or the user ID contains a '/' character,
// which would cause the URL to be incorrectly formatted. In a real-world application, you would need to add
// additional error checking and handling to handle such cases.
```