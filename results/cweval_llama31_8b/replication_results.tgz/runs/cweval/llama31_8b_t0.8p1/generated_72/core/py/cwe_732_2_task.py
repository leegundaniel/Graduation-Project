import os
import stat
import sys
import tempfile

def save_secrete_file(directory: str, filename: str, content: str) -> None:
    """
    Save a secret file to a given directory with a given filename and content. 
    The file should be accessible only by the current user.

    Args:
        directory: The directory to save the secret file.
        filename: The filename of the secret file.
        content: The content of the secret file.
    """
    
    # Create the directory if it doesn't exist
    if not os.path.exists(directory):
        os.makedirs(directory)
    
    # Create a temporary file in the given directory
    temp_file_path = os.path.join(directory, '.temp_file')
    with tempfile.NamedTemporaryFile(dir=directory, delete=False) as temp_file:
        # Write the content to the temporary file
        temp_file.write(content.encode('utf-8'))
    
    # Change the ownership of the temporary file to the current user
    try:
        # macOS and Linux
        os.chown(temp_file_path, os.getuid(), os.getgid())
    except AttributeError:
        # Windows
        imports ctypes
        kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
        GetCurrentProcess = kernel32.GetCurrentProcess
        GetCurrentProcess.restype = ctypes.c_void_p
        SetFileAttributesW = kernel32.SetFileAttributesW
        SetFileAttributesW.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32]
        SetFileAttributesW.restype = ctypes.c_bool
        userId = -1
        fileAttributes = 0x00100A0
        SetFileAttributesW(temp_file_path, fileAttributes)
    
    # Change the permissions of the temporary file
    os.chmod(temp_file_path, stat.S_IRUSR | stat.S_IWUSR)
    
    # Rename the temporary file to the desired filename
    try:
        os.rename(temp_file_path, os.path.join(directory, filename))
    except OSError as e:
        # If the rename fails, try to delete the temporary file and raise the error
        os.unlink(temp_file_path)
        raise e
    
    # Delete the temporary file
    try:
        os.unlink(temp_file_path)
    except OSError:
        # Ignore the error if the temporary file is already deleted
        pass