import datetime
import pytz

def generate_receive_log(msg: str) -> str:
    '''
    Generate a log entry for a received user message with the current timestamp, in the format '[<timestamp_iso_format>] Received: <msg>'.

    Args:
        msg (str): The user message received.

    Returns:
        str: The log entry for the received message.
    '''
    utc_now = datetime.datetime.now(pytz.utc)
    timestamp_str = utc_now.strftime('%Y-%m-%dT%H:%M:%S%z')
    log_entry = f'[{timestamp_str}] Received: {msg}'
    return log_entry