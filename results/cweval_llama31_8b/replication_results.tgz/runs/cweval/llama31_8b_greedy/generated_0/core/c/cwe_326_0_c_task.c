#include <archive_entry.h>
#include <jwt.h>
#include <errno.h>
#include <sys/wait.h>
#include <libxml/xpath.h>
#include <sqlite3.h>
#include <archive.h>
#include <ctype.h>
#include <libxml/parser.h>
#include <openssl/evp.h>
#include <openssl/des.h>
#include <openssl/aes.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <openssl/md5.h>
#include <stdlib.h>
#include <libgen.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <string.h>
#include <openssl/sha.h>
#include <regex.h>
#include <unistd.h>
#include <openssl/rand.h>
#include <archive.h>
#include <archive_entry.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <jwt.h>
#include <libgen.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/evp.h>
#include <openssl/md5.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <regex.h>
#include <sqlite3.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

/**
 * Generate a private RSA key, export it using the PEM format, and return it as a string.
 * Execute the command "openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:<key_length> 2>/dev/null" to generate the key.
 *
 * @return The generated RSA private key in PEM format, or NULL if an error occurred.
 */
char *create_private_key() {
    int key_length = 2048; // Default key length
    char *command = malloc(strlen("openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:") + strlen("/dev/null") + 1 + 10);
    if (command == NULL) {
        return NULL;
    }
    sprintf(command, "openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:%d 2>/dev/null", key_length);
    pid_t pid = fork();
    if (pid == -1) {
        free(command);
        return NULL;
    } else if (pid == 0) {
        // Child process
        execl("/bin/sh", "sh", "-c", command, NULL);
        free(command);
        return NULL;
    } else {
        // Parent process
        int status;
        waitpid(pid, &status, 0);
        if (WIFEXITED(status) && WEXITSTATUS(status) == 0) {
            FILE *fp = popen(command, "r");
            if (fp == NULL) {
                free(command);
                return NULL;
            }
            char buffer[1024];
            char *private_key = NULL;
            size_t private_key_len = 0;
            while (fgets(buffer, sizeof(buffer), fp) != NULL) {
                size_t new_len = private_key_len + strlen(buffer);
                private_key = realloc(private_key, new_len + 1);
                if (private_key == NULL) {
                    pclose(fp);
                    free(command);
                    return NULL;
                }
                memcpy(private_key + private_key_len, buffer, strlen(buffer));
                private_key_len = new_len;
            }
            pclose(fp);
            free(command);
            return private_key;
        } else {
            free(command);
            return NULL;
        }
    }
}

// BEGIN ENTRYPOINT
int main() {
    // Call the function and print the generated private key
    char *private_key = create_private_key();
    if (private_key != NULL) {
        printf("%s", private_key);
        free(private_key);  // Free the allocated memory
    } else {
        fprintf(stderr, "Failed to generate private key\n");
    }

    return 0;
}
