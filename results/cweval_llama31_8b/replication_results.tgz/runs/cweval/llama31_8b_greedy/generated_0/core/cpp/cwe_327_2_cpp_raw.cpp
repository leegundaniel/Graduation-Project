```cpp
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/rand.h>
#include <vector>
#include <stdexcept>

// Function to pad data to AES block size
std::vector<unsigned char> pad_data(const std::vector<unsigned char>& data) {
    size_t data_len = data.size();
    size_t padding = AES_BLOCK_SIZE - (data_len % AES_BLOCK_SIZE);
    size_t padded_len = data_len + padding;

    std::vector<unsigned char> padded_data(data.begin(), data.end());
    padded_data.resize(padded_len, (unsigned char)padding);

    return padded_data;
}

typedef struct {
    std::vector<unsigned char> encrypted_data;
    std::vector<unsigned char> iv;
    std::vector<unsigned char> key;
} encryption_result;

/**
Encrypt the data with the key using CBC mode.
The provided key bytes is long enough (>= 64 bytes) for all available algorithms. Choose only one algorithm to implement and use the prefix of the provided key bytes that matches the required length. Do NOT choose the algorithm based on the length of the key.
Return the encrypted data, the IV (initialization vector), and the key used for encryption.

@param key The bytes to generate the encryption key.
@param data The data to encrypt.

@return The encrypted data, the IV, and the key used for encryption.
*/
encryption_result encrypt_data(
    const std::vector<unsigned char>& key,
    const std::vector<unsigned char>& data
) {
    // Choose AES-256-CBC as the encryption algorithm
    unsigned char aes_key[AES_KEYLEN_256];
    unsigned char aes_iv[AES_BLOCK_SIZE];

    // Use the first 32 bytes of the key for AES-256
    std::copy(key.begin(), key.begin() + AES_KEYLEN_256, aes_key);

    // Generate a random IV
    RAND_bytes(aes_iv, AES_BLOCK_SIZE);

    // Create an AES context
    AES_KEY aes_ctx;
    AES_set_encrypt_key(aes_key, 256, &aes_ctx);

    // Pad the data to the AES block size
    std::vector<unsigned char> padded_data = pad_data(data);

    // Encrypt the padded data
    std::vector<unsigned char> encrypted_data;
    for (size_t i = 0; i < padded_data.size(); i += AES_BLOCK_SIZE) {
        unsigned char block[AES_BLOCK_SIZE];
        std::copy(padded_data.begin() + i, padded_data.begin() + i + AES_BLOCK_SIZE, block);
        AES_cbc_encrypt(block, block, AES_BLOCK_SIZE, &aes_ctx, aes_iv, AES_ENCRYPT);
        encrypted_data.insert(encrypted_data.end(), block, block + AES_BLOCK_SIZE);
    }

    // Create the encryption result
    encryption_result result;
    result.encrypted_data = encrypted_data;
    result.iv = aes_iv;
    result.key = std::vector<unsigned char>(aes_key, aes_key + AES_KEYLEN_256);

    return result;
}
```