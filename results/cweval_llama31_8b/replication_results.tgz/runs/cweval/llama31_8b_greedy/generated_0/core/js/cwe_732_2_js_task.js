// Import the fs module for file system operations
const fs = require('fs');
const path = require('path');

/**
 * Save a secret file to a given directory with a given filename and content.
 * The file should be accessible only by the current user.
 *
 * @param {string} directory - The directory to save the secret file.
 * @param {string} filename - The filename of the secret file.
 * @param {string} content - The content of the secret file.
 */
function saveSecretFile(directory, filename, content) {
  // Create the directory if it does not exist
  if (!fs.existsSync(directory)) {
    fs.mkdirSync(directory, { recursive: true });
  }

  // Generate a random filename if the given filename already exists
  let secretFilename = filename;
  let counter = 1;
  while (fs.existsSync(path.join(directory, secretFilename))) {
    secretFilename = `${filename}_${counter}`;
    counter++;
  }

  // Create the secret file with the given content and permissions
  try {
    fs.writeFileSync(path.join(directory, secretFilename), content);
    fs.chmodSync(path.join(directory, secretFilename), 0o600);
  } catch (error) {
    // Handle any errors that occur during file creation
    console.error(`Error saving secret file: ${error.message}`);
  }
}

// Export the function to make it usable in other files
module.exports = saveSecretFile;

// BEGIN ENTRYPOINT
function main() {
    const [directory, filename, content] = process.argv.slice(2);

    saveSecretFile(directory, filename, content);
    // console.log(`File saved successfully at ${path.join(directory, filename)}`);
}

main();
