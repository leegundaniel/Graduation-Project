```go
package main

import (
	"encoding/xml"
	"fmt"
	"github.com/ChrisTrenkamp/goxpath"
	"github.com/ChrisTrenkamp/goxpath/tree"
	"github.com/ChrisTrenkamp/goxpath/tree/xmltree"
)

// Student represents a student in the XML data.
type Student struct {
	XMLName xml.Name `xml:"student"`
	Username string `xml:"username"`
	Password string `xml:"password"`
	Name string `xml:"name"`
	Citizenship string `xml:"citizenship"`
	Age string `xml:"age"`
}

// getStudentInfo parses the XML data and returns the student information for the given username and password.
func getStudentInfo(xmlData, username, password string) (string, string, string) {
	// Unmarshal the XML data into a Student slice.
	var students []Student
	err := xml.Unmarshal([]byte(xmlData), &students)
	if err != nil {
		fmt.Println(err)
		return "", "", ""
	}

	// Iterate over the students to find the one with the matching username and password.
	for _, student := range students {
		if student.Username == username && student.Password == password {
			return student.Name, student.Age, student.Citizenship
		}
	}

	// If no matching student is found, return empty strings.
	return "", "", ""
}
```

This implementation uses the `encoding/xml` package to unmarshal the XML data into a slice of `Student` structs. It then iterates over the students to find the one with the matching username and password. If a matching student is found, it returns the student's name, age, and citizenship. If no matching student is found, it returns empty strings.