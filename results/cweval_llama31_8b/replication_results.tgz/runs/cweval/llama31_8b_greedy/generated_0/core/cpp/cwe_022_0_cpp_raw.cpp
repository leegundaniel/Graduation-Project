```cpp
#include <iostream>
#include <fstream>
#include <string>
#include <stdexcept>

/**
 * Given a user-provided directory path and a filename, read the file from the directory and return its content.
 * If any error occurs during the file reading process (e.g. file not found, permission error), return an empty string.
 *
 * @param filename The name of the file to read, requested by a user.
 * @param dir_path The path of the directory where the file is located.
 *
 * @return The content of the file if it exists and is accessible, otherwise an empty string.
 */
std::string read_file_from_dir(const std::string &filename, const std::string &dir_path) {
    try {
        // Construct the full path of the file by joining the directory path and the filename
        std::string file_path = dir_path + "/" + filename;

        // Open the file in read mode
        std::ifstream file(file_path);

        // Check if the file is successfully opened
        if (!file.is_open()) {
            throw std::runtime_error("Failed to open the file");
        }

        // Read the content of the file
        std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());

        // Close the file
        file.close();

        // Return the content of the file
        return content;
    } catch (const std::exception &e) {
        // If any error occurs during the file reading process, return an empty string
        return "";
    }
}
```