#include <iostream>
#include <string>
#include <cstring>
#include <cctype>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <unistd.h>
#include <filesystem>
#include <archive.h>
#include <archive_entry.h>
#include <memory>
#include <vector>
#include <sys/types.h>
#include <sys/wait.h>
#include <map>
#include <algorithm>
#include <ctime>
#include <iomanip>
#include <cstdio>
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/rand.h>
#include <tuple>
#include <stdexcept>
#include <jwt.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <sys/stat.h>
#include <utility>
#include <regex>
#include <sqlite3.h>
#include <iostream>
#include <string>
#include <stdexcept>
#include <cstdio>
#include <cstdlib>

/**
 * Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path.
 * If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.
 *
 * @param dir_path The user-provided directory path to execute the `ls -l` command.
 *
 * @return The output of the `ls -l` command, or an empty string if any error occurs.
 */
std::string get_ls_result(const std::string &dir_path) {
    // Construct the full command string
    std::string command = "ls -l " + dir_path;

    // Execute the command and capture its output
    FILE *pipe = popen(command.c_str(), "r");
    if (!pipe) {
        // If the command execution fails, return an empty string
        return "";
    }

    // Read the output from the pipe
    std::string output;
    char buffer[128];
    while (fgets(buffer, 128, pipe) != NULL) {
        output += buffer;
    }

    // Close the pipe and check for errors
    int status = pclose(pipe);
    if (status == -1) {
        // If an error occurs during command execution, return an empty string
        return "";
    } else if (status != 0) {
        // If the command execution fails, return an empty string
        return "";
    }

    // Return the output of the command
    return output;
}

// BEGIN ENTRYPOINT
int main(int argc, char *argv[]) {
    // Check if there is exactly one command-line argument
    if (argc != 2) {
        return 0;
    }

    // Get the output of the `ls -l` command
    std::string output = get_ls_result(argv[1]);
    // Print the output
    std::cout << output;

    return 0;
}
