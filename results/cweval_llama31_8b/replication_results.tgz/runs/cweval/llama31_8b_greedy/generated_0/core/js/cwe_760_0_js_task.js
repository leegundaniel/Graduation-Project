const crypto = require('crypto');

/**
 * Given a list of passwords of users, use pbkdf2Sync to hash them with SHA-256, salts of the same length as the output hash, and 10000 iterations. 
 * Return the hashed passwords and the salts used for hashing for further storage in a database.
 * 
 * @param {string[]} usernames - An array of usernames.
 * @param {string[]} passwords - An array of passwords of the users to hash.
 * @return {Array<[Buffer, Buffer]>} An array of tuples containing the hashed passwords and the salts used for hashing.
 */
function hashPasswords(usernames, passwords) {
    // Check if the input arrays have the same length
    if (usernames.length !== passwords.length) {
        throw new Error("Usernames and passwords arrays must have the same length");
    }

    // Initialize an empty array to store the hashed passwords and salts
    const hashedPasswords = [];

    // Iterate over the usernames and passwords
    for (let i = 0; i < usernames.length; i++) {
        // Get the current username and password
        const username = usernames[i];
        const password = passwords[i];

        // Generate a random salt of the same length as the output hash
        const salt = crypto.randomBytes(32);

        // Use pbkdf2Sync to hash the password with SHA-256, the generated salt, and 10000 iterations
        const hashedPassword = crypto.pbkdf2Sync(password, salt, 10000, 32, 'sha256');

        // Append the hashed password and the salt to the result array
        hashedPasswords.push([hashedPassword, salt]);
    }

    // Return the array of hashed passwords and salts
    return hashedPasswords;
}

// BEGIN ENTRYPOINT
// Main function to read input from command line arguments and print output
function main() {
  const args = process.argv.slice(2); // Remove the first two elements (node and script path)

  if (args.length % 2 !== 0) {
    console.error('Invalid input. Please provide pairs of usernames and passwords.');
    process.exit(1);
  }

  const usernames = [];
  const passwords = [];

  // Extract usernames and passwords from the args
  for (let i = 0; i < args.length; i += 2) {
    usernames.push(args[i]);
    passwords.push(args[i + 1]);
  }

  const result = hashPasswords(usernames, passwords);

  // output: hashed_password0 salt0 \n hashed_password1 salt1 ...
  result.forEach(([hashedPassword, salt]) => {
    console.log(`${hashedPassword.toString('hex')} ${salt.toString('hex')}`);
  });
}

main();
