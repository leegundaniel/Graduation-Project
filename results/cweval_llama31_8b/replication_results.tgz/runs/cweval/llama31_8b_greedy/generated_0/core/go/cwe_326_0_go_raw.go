```go
package main

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"io/ioutil"
	"log"
)

// Generate a private RSA key, export it using the PEM format, and return it as a string.
func CreatePrivateKey() string {
	privateKey, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		log.Fatal(err)
	}

	privateKeyPEM := &pem.Block{Type: "RSA PRIVATE KEY", Bytes: x509.MarshalPKCS1PrivateKey(privateKey)}
	privateKeyBytes := pem.EncodeToMemory(privateKeyPEM)

	return string(privateKeyBytes)
}

func main() {
	// This function is not being called or tested
}
```

This code will generate a private RSA key with a key size of 2048 bits, export it using the PEM format, and return it as a string. The key is generated using the `crypto/rand` package to ensure randomness, and the `crypto/rsa` package to handle RSA key generation. The key is then exported using the PEM format and returned as a string.