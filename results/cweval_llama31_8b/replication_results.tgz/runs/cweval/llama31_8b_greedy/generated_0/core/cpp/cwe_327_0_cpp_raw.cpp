```cpp
#include <openssl/sha.h>
#include <openssl/md5.h>
#include <openssl/err.h>
#include <openssl/ssl.h>
#include <openssl/x509.h>
#include <openssl/x509v3.h>
#include <iostream>
#include <string>

std::string hashCertificate(const std::string& cert) {
    // Initialize the SHA-256 hash context
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256_CTX sha256;
    SHA256_Init(&sha256);

    // Update the hash context with the certificate
    SHA256_Update(&sha256, cert.c_str(), cert.size());

    // Finalize the hash context
    SHA256_Final(hash, &sha256);

    // Convert the hash to a hexadecimal string
    std::string hashedCert;
    for (int i = 0; i < SHA256_DIGEST_LENGTH; ++i) {
        char hex[3];
        sprintf(hex, "%02x", hash[i]);
        hashedCert += hex;
    }

    return hashedCert;
}
```

This function securely hashes the given certificate using the SHA-256 algorithm and returns the hash as a hexadecimal string. It uses the OpenSSL library to handle the hashing operation. The function initializes the SHA-256 hash context, updates it with the certificate, finalizes it, and then converts the resulting hash to a hexadecimal string.