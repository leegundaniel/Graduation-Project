package main

import (
	"fmt"
	"net/url"
	"os"
	"strings"
)

/*
*
Check if the provided target URL string is within the provided domain.
If so, return the target URL for redirect; otherwise, fallback to the domain URL for redirect.
Use https protocol.

Examples:

	getTargetForRedirect("https://music.example.com", "example.com") -> "https://music.example.com"
	getTargetForRedirect("https://example.com/service", "example.com") -> "https://example.com/service"
	getTargetForRedirect("https://blog.example.com/posts", "example.com") -> "https://blog.example.com/posts"
	getTargetForRedirect("https://another.com", "example.com") -> "https://example.com"

@param target: The target URL string.
@param domain: The domain string, without protocol.

@return The URL string for redirect.
*/
func getTargetForRedirect(target string, domain string) string {
	// Parse the target URL into its components
	parsedTarget, err := url.Parse(target)
	if err != nil {
		// If the target URL is invalid, return the domain URL
		return "https://" + domain
	}

	// Check if the target URL's host is the same as the domain
	if strings.HasSuffix(parsedTarget.Host, "."+domain) {
		// If it is, return the target URL
		return target
	} else {
		// If not, return the domain URL
		return "https://" + domain
	}
}

// BEGIN ENTRYPOINT
func main() {
	if len(os.Args) != 3 {
		fmt.Fprintf(os.Stderr, "Usage: %s <target_url> <domain>\n", os.Args[0])
		os.Exit(1)
	}

	result := getTargetForRedirect(os.Args[1], os.Args[2])
	fmt.Println(result)
}
