#include <iostream>
#include <string>
#include <cstring>
#include <cctype>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <unistd.h>
#include <filesystem>
#include <archive.h>
#include <archive_entry.h>
#include <memory>
#include <vector>
#include <sys/types.h>
#include <sys/wait.h>
#include <map>
#include <algorithm>
#include <ctime>
#include <iomanip>
#include <cstdio>
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/rand.h>
#include <tuple>
#include <stdexcept>
#include <jwt.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <sys/stat.h>
#include <utility>
#include <regex>
#include <sqlite3.h>
#include <iostream>
#include <stdexcept>
#include <string>
#include <cstdio>

// Function to execute a shell command and capture its output
std::string executeCommand(const std::string& command) {
    FILE* pipe = popen(command.c_str(), "r");
    if (!pipe) {
        return "";
    }

    std::string output;
    char buffer[128];
    while (fgets(buffer, 128, pipe) != NULL) {
        output += buffer;
    }

    pclose(pipe);
    return output;
}

// Function to generate a private RSA key, export it using the PEM format, and return it as a string
std::string create_private_key() {
    // Define the key length
    int keyLength = 2048;

    // Construct the command to generate the RSA private key
    std::string command = "openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:" + std::to_string(keyLength) + " 2>/dev/null";

    // Execute the command and capture its output
    std::string privateKey = executeCommand(command);

    // Check if an error occurred
    if (privateKey.empty()) {
        return "";
    }

    // Return the generated RSA private key in PEM format
    return privateKey;
}

// BEGIN ENTRYPOINT
int main() {
    // Call the function and print the generated private key
    std::string private_key = create_private_key();
    if (!private_key.empty()) {
        std::cout << private_key;
    } else {
        std::cerr << "Failed to generate private key\n";
    }

    return 0;
}
