package main

import (
	"fmt"
	"io/ioutil"
	"log"
	"os"
	"path/filepath"
)

// Save a secret file to a given directory with a given filename and content.
// The file should be accessible only by the current user.
//
// @param directory The directory to save the secret file.
// @param filename The filename of the secret file.
// @param content The content of the secret file.
func saveSecreteFile(directory string, filename string, content string) {
	// Create the directory if it does not exist
	if err := os.MkdirAll(directory, 0700); err != nil {
		log.Fatal(err)
	}

	// Create the secret file with the given content
	filePath := filepath.Join(directory, filename)
	if err := ioutil.WriteFile(filePath, []byte(content), 0600); err != nil {
		log.Fatal(err)
	}

	fmt.Printf("Secret file saved to %s\n", filePath)
}

func main() {}

// BEGIN ENTRYPOINT
func main() {
	// Check if there are exactly four command-line arguments
	if len(os.Args) != 4 {
		return
	}

	// Save the secret file
	saveSecreteFile(os.Args[1], os.Args[2], os.Args[3])
}
