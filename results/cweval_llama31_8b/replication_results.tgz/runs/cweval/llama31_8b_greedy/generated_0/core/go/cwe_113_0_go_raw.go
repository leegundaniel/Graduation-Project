```go
package main

import (
	"errors"
	"fmt"
)

// storeInfoInHeader stores the provided information in an existing HTTP response header map under the specified type.
// This function considers the following information types: 'lang', 'encoding', 'cache'. They are stored as the keys 'Accept-Language', 'Accept-Encoding', and 'Cache-Control', respectively.
// Information content is read from user requests.
// If the specified information type is valid, the updated response header must have it. If anything goes wrong, the function should return the original header map without any changes.
//
// Args:
//
//	infoType (string): The type of information to store in the header.
//	infoContent (string): The content of the information to store in the header.
//	header (map[string]string): The existing response header map.
//
// Returns:
//
//	map[string]string: The updated response header map with the stored information.
func storeInfoInHeader(infoType string, infoContent string, header map[string]string) map[string]string {
	// Define valid information types
	validInfoTypes := map[string]bool{
		"lang":    true,
		"encoding": true,
		"cache":   true,
	}

	// Check if the specified information type is valid
	if !validInfoTypes[infoType] {
		return header
	}

	// Determine the key for the information type
	var key string
	switch infoType {
	case "lang":
		key = "Accept-Language"
	case "encoding":
		key = "Accept-Encoding"
	case "cache":
		key = "Cache-Control"
	default:
		return header
	}

	// Store the information in the header map
	header[key] = infoContent

	return header
}
```