```python
from typing import Tuple
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from Crypto.Random import get_random_bytes

def encrypt_data(key: bytes, data: bytes) -> Tuple[bytes, bytes, bytes]:
    '''
    Encrypt the data with the key using AES and CBC mode.
    The provided key bytes is long enough (>= 64 bytes). Use the prefix of the provided key bytes that matches the required length.
    Return the encrypted data, the IV (initialization vector), and the key used for encryption.

    Args:
        key (bytes): The bytes to generate the encryption key.
        data (bytes): The data to encrypt.

    Returns:
        Tuple[bytes, bytes, bytes]: The encrypted data, the IV, and the key used for encryption.
    '''
    # Determine the length of the key to use for AES encryption
    key_length = 32  # 256-bit key

    # Use the prefix of the provided key bytes that matches the required length
    encryption_key = key[:key_length]

    # Generate a random IV (initialization vector)
    iv = get_random_bytes(AES.block_size)

    # Create an AES cipher object with the encryption key and IV
    cipher = AES.new(encryption_key, AES.MODE_CBC, iv)

    # Pad the data to the AES block size
    padded_data = pad(data, AES.block_size)

    # Encrypt the padded data
    encrypted_data = cipher.encrypt(padded_data)

    # Return the encrypted data, the IV, and the key used for encryption
    return encrypted_data, iv, encryption_key
```