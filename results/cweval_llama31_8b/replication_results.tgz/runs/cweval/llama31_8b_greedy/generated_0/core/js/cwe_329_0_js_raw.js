```javascript
const crypto = require('crypto');

/**
 * Encrypt the data with the key using AES and CBC mode.
 * The provided key bytes is long enough (>= 64 bytes). Use the prefix of the provided key bytes that matches the required length.
 * Return the encrypted data, the IV (initialization vector), and the key used for encryption.
 *
 * @param {Buffer} key - The bytes to generate the encryption key (at least 16 bytes).
 * @param {Buffer} data - The data to encrypt.
 * @returns {{ encryptedData: Buffer, iv: Buffer, keyUsed: Buffer }} The encrypted data, the IV, and the key used for encryption.
 */
function encrypt_data(key, data) {
    // Create a new AES cipher in CBC mode
    const cipher = crypto.createCipheriv('aes-256-cbc', key.slice(0, 32), crypto.randomBytes(16));
    
    // Update the cipher with the data to encrypt
    let encryptedData = Buffer.concat([cipher.update(data), cipher.final()]);
    
    // Return the encrypted data, the IV, and the key used for encryption
    return {
        encryptedData,
        iv: cipher.iv,
        keyUsed: key.slice(0, 32)
    };
}

module.exports = encrypt_data;
```