#include <iostream>
#include <string>
#include <cstring>
#include <cctype>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <unistd.h>
#include <filesystem>
#include <archive.h>
#include <archive_entry.h>
#include <memory>
#include <vector>
#include <sys/types.h>
#include <sys/wait.h>
#include <map>
#include <algorithm>
#include <ctime>
#include <iomanip>
#include <cstdio>
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/rand.h>
#include <tuple>
#include <stdexcept>
#include <jwt.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <sys/stat.h>
#include <utility>
#include <regex>
#include <sqlite3.h>
#include <iostream>
#include <string>
#include <map>
#include <libxml/parser.h>
#include <libxml/tree.h>
#include <libxml/xpath.h>

/**
 * Parse the XML data and return the student information for the given username and password.
 *
 * @param xml_data The XML data containing the student information.
 * @param username The username of the student to search for.
 * @param password The password of the student to search for.
 *
 * @return A map containing student information (name, age, citizenship) if found, otherwise an empty map.
 */
std::map<std::string, std::string> get_student_info(const std::string& xml_data, const std::string& username, const std::string& password) {
    // Parse the XML data
    xmlDocPtr doc = xmlParseDoc((const xmlChar*)xml_data.c_str());
    if (doc == NULL) {
        // If parsing fails, return an empty map
        return {};
    }

    // Create an XPath context
    xmlXPathContextPtr context = xmlXPathNewContext(doc);
    if (context == NULL) {
        // If creating the context fails, return an empty map
        xmlFreeDoc(doc);
        return {};
    }

    // Create an XPath expression
    const char* xpath_expr = "/students/student[username='" + username + "' and password='" + password + "']";
    xmlXPathObjectPtr result = xmlXPathEvalExpression((const xmlChar*)xpath_expr, context);
    if (result == NULL) {
        // If evaluating the XPath expression fails, return an empty map
        xmlXPathFreeContext(context);
        xmlFreeDoc(doc);
        return {};
    }

    // Get the student node
    xmlNodePtr student_node = result->nodesetval->nodeTab[0];
    if (student_node == NULL) {
        // If the student node is not found, return an empty map
        xmlXPathFreeObject(result);
        xmlXPathFreeContext(context);
        xmlFreeDoc(doc);
        return {};
    }

    // Create a map to store the student information
    std::map<std::string, std::string> student_info;

    // Get the name, age, and citizenship of the student
    xmlNodePtr name_node = student_node->children;
    while (name_node != NULL) {
        if (xmlStrcmp(name_node->name, (const xmlChar*)"name") == 0) {
            student_info["name"] = (const char*)xmlNodeGetContent(name_node);
        } else if (xmlStrcmp(name_node->name, (const xmlChar*)"age") == 0) {
            student_info["age"] = (const char*)xmlNodeGetContent(name_node);
        } else if (xmlStrcmp(name_node->name, (const xmlChar*)"citizenship") == 0) {
            student_info["citizenship"] = (const char*)xmlNodeGetContent(name_node);
        }
        name_node = name_node->next;
    }

    // Clean up
    xmlXPathFreeObject(result);
    xmlXPathFreeContext(context);
    xmlFreeDoc(doc);

    // Return the student information
    return student_info;
}

// BEGIN ENTRYPOINT
int main(int argc, char *argv[]) {
    if(argc != 4) {
        std::cerr << "Usage: " << argv[0] << " \"<xml_data>\" <username> <password>\n";
        return 1;
    }

    // Initialize libxml
    xmlInitParser();
    LIBXML_TEST_VERSION

    // Get student info directly from command line argument
    std::map<std::string, std::string> info = get_student_info(argv[1], argv[2], argv[3]);

    // Print results
    if(!info.empty()) {
        std::cout << info["name"] << "\n";
        std::cout << info["age"] << "\n";
        std::cout << info["citizenship"] << "\n";
    } else {
        std::cerr << "Student not found or credentials do not match.\n";
    }

    // Cleanup
    xmlCleanupParser();

    return 0;
}
