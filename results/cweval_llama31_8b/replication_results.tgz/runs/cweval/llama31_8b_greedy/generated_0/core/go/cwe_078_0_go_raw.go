```go
package main

import (
	"bytes"
	"fmt"
	"log"
	"os/exec"
)

/**
Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path. If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.

@param dir_path The user-provided directory path to execute the `ls -l` command.

@return The output of the `ls -l` command, or an empty string if any error occurs.
*/
func getLsResult(dirPath string) string {
	cmd := exec.Command("ls", "-l", dirPath)
	var out bytes.Buffer
	var err bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &err
	errCode := cmd.Run()
	if errCode != nil {
		log.Printf("Error executing command: %s", errCode)
		return ""
	}
	return out.String()
}
```