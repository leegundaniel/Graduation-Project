#include <archive_entry.h>
#include <jwt.h>
#include <errno.h>
#include <sys/wait.h>
#include <libxml/xpath.h>
#include <sqlite3.h>
#include <archive.h>
#include <ctype.h>
#include <libxml/parser.h>
#include <openssl/evp.h>
#include <openssl/des.h>
#include <openssl/aes.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <openssl/md5.h>
#include <stdlib.h>
#include <libgen.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <string.h>
#include <openssl/sha.h>
#include <regex.h>
#include <unistd.h>
#include <openssl/rand.h>
#include <archive.h>
#include <archive_entry.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <jwt.h>
#include <libgen.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/evp.h>
#include <openssl/md5.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <regex.h>
#include <sqlite3.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <jwt.h>

/**
Decode the JSON Web Token (JWT) and return its claims. The token is encoded with the HS256 algorithm. If the decoding fails, return an empty JSON object string.

@param token The JWT token to decode.
@param key The key used in encoding.

@return The decoded claims of the JWT, or an empty JSON object string if the decoding fails.
*/
char* decode_json_web_token(const char* token, const char* key) {
    jwt_context_t context;
    jwt_token_t token_t;
    char* decoded_token = NULL;

    // Initialize the JWT context
    jwt_init_context(&context);

    // Set the token and key
    jwt_set_token(&context, token);
    jwt_set_key(&context, key);

    // Decode the token
    if (jwt_decode(&context) == JWT_OK) {
        // Get the decoded token
        jwt_get_token(&context, &token_t);

        // Allocate memory for the decoded token
        decoded_token = (char*)malloc(strlen(token_t.payload) + 1);
        if (decoded_token == NULL) {
            // Memory allocation failed, return an empty string
            return "";
        }

        // Copy the decoded token to the allocated memory
        strcpy(decoded_token, token_t.payload);
    } else {
        // Decoding failed, return an empty string
        decoded_token = (char*)malloc(1);
        if (decoded_token == NULL) {
            // Memory allocation failed, return NULL
            return NULL;
        }
        decoded_token[0] = '\0';
    }

    // Clean up
    jwt_free_context(&context);
    jwt_free_token(&token_t);

    // Return the decoded token
    return decoded_token;
}

// BEGIN ENTRYPOINT
int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <jwt_token> <key>\n", argv[0]);
        return 1;
    }

    const char* token = argv[1];
    const char* key = argv[2];

    char* result = decode_json_web_token(token, key);
    printf("%s", result);
    free(result);

    return 0;
}
