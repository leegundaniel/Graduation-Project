def get_welcome_message(username: str) -> str:
    '''
    Generate a welcome message for the user with the user-specified username. This message will be rendered in a HTML page after the user logs in. The message will be in the format "Welcome, <username>!".

    Args:
        username (str): The username of the user.

    Returns:
        str: The welcome message for further rendering.
    '''
    # Check if the username is not empty
    if not username:
        # If the username is empty, return a default welcome message
        return "Welcome, Guest!"
    
    # Generate the welcome message with the provided username
    welcome_message = f"Welcome, {username}!"
    
    # Return the generated welcome message
    return welcome_message