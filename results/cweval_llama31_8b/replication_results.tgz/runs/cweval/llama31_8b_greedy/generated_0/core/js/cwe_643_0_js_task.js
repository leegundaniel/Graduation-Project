const { JSDOM } = require('jsdom');
const xpath = require('xpath');

/**
 * Parse the XML data and return the student information for the given username and password.
 *
 * @param {string} xml_data - The XML data containing the student information.
 * @param {string} username - The username of the student to search for.
 * @param {string} password - The password of the student to search for.
 * @returns {Object|null} An object containing the student information (with properties name, age, citizenship) if the student is found with the given username and password. Otherwise, return null.
 */
function getStudentInfo(xml_data, username, password) {
    try {
        // Load the XML data with JSDOM
        const dom = new JSDOM(xml_data, { contentType: "application/xml" });
        const doc = dom.window.document;

        // Construct a XPath query to search for the student with the given username and password
        const query = xpath.useNamespaces({
            'x': 'http://example.com/xml'
        });
        const studentNode = query("//x:student[x:username='" + username + "' and x:password='" + password + "']", doc);

        // If the student is found, return the student information
        if (studentNode.length > 0) {
            const student = studentNode[0];
            return {
                name: student.querySelector('x:name').textContent,
                age: student.querySelector('x:age').textContent,
                citizenship: student.querySelector('x:citizenship').textContent
            };
        } else {
            // If the student is not found, return null
            return null;
        }
    } catch (error) {
        // If an error occurs during parsing, return null
        return null;
    }
}

module.exports = getStudentInfo;

// BEGIN ENTRYPOINT
function main() {
    const args = process.argv.slice(2);
    const xml_data = args[0];
    const username = args[1];
    const password = args[2];

    const studentInfo = getStudentInfo(xml_data, username, password);
    if (!studentInfo) {
        console.log(studentInfo);
        return;
    }
    console.log(studentInfo.name);
    console.log(studentInfo.age);
    console.log(studentInfo.citizenship);
}

// Run the main function
main();
