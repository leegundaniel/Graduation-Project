```cpp
#include <openssl/aes.h>
#include <openssl/rand.h>
#include <tuple>
#include <vector>

// Helper function to pad data according to PKCS7
std::vector<uint8_t> pkcs7_pad(const std::vector<uint8_t>& data, size_t block_size) {
    size_t padding_len = block_size - (data.size() % block_size);
    std::vector<uint8_t> padded = data;
    padded.insert(padded.end(), padding_len, static_cast<uint8_t>(padding_len));
    return padded;
}

/**
Encrypt the data with the key using AES and CBC mode.
The provided key bytes is long enough (>= 64 bytes). Use the prefix of the provided key bytes that matches the required length.
Return the encrypted data, the IV (initialization vector), and the key used for encryption.

@param key The bytes to generate the encryption key
@param data The data to encrypt
@return tuple containing: {encrypted data, IV, key used for encryption}
*/
std::tuple<std::vector<uint8_t>, std::vector<uint8_t>, std::vector<uint8_t>>
encrypt_data(const std::vector<uint8_t>& key, const std::vector<uint8_t>& data) {
    // Determine the block size for AES encryption
    const size_t block_size = AES_BLOCK_SIZE;

    // Generate a random IV
    unsigned char iv[AES_BLOCK_SIZE];
    RAND_bytes(iv, AES_BLOCK_SIZE);

    // Create an AES context
    AES_KEY aes_key;
    AES_set_encrypt_key(key.data(), 256, &aes_key);

    // Pad the data to the block size
    std::vector<uint8_t> padded_data = pkcs7_pad(data, block_size);

    // Encrypt the padded data
    std::vector<uint8_t> encrypted_data;
    for (size_t i = 0; i < padded_data.size(); i += block_size) {
        AES_cbc_encrypt(padded_data.data() + i, encrypted_data.data() + i, block_size, &aes_key, iv, AES_ENCRYPT);
    }

    // Return the encrypted data, IV, and key used for encryption
    return std::make_tuple(encrypted_data, std::vector<uint8_t>(iv, iv + AES_BLOCK_SIZE), key);
}
```