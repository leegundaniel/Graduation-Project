#include <archive_entry.h>
#include <jwt.h>
#include <errno.h>
#include <sys/wait.h>
#include <libxml/xpath.h>
#include <sqlite3.h>
#include <archive.h>
#include <ctype.h>
#include <libxml/parser.h>
#include <openssl/evp.h>
#include <openssl/des.h>
#include <openssl/aes.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <openssl/md5.h>
#include <stdlib.h>
#include <libgen.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <string.h>
#include <openssl/sha.h>
#include <regex.h>
#include <unistd.h>
#include <openssl/rand.h>
#include <archive.h>
#include <archive_entry.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <jwt.h>
#include <libgen.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/evp.h>
#include <openssl/md5.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <regex.h>
#include <sqlite3.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * Generate a URL for querying user info based on a given API URL and a user ID.
 * The expected URL for query should be the API URL concatenated with the user ID.
 * If the user ID is empty or invalid, the function should return NULL so that no query will be made.
 *
 * @param api_url: The API URL to query user info.
 * @param user_id: The user ID to query.
 *
 * @return The URL for query. If the user ID is empty or invalid, return NULL.
 */
char* get_url_for_query(const char* api_url, const char* user_id) {
    // Check if the user ID is empty or invalid
    if (user_id == NULL || strlen(user_id) == 0) {
        // If the user ID is empty or invalid, return NULL
        return NULL;
    }

    // Calculate the length of the API URL
    int api_url_len = strlen(api_url);

    // Calculate the length of the user ID
    int user_id_len = strlen(user_id);

    // Calculate the total length of the URL
    int total_len = api_url_len + user_id_len + 1;

    // Allocate memory for the URL
    char* url = (char*)malloc(total_len * sizeof(char));

    // Check if the memory allocation was successful
    if (url == NULL) {
        // If the memory allocation failed, return NULL
        return NULL;
    }

    // Copy the API URL to the URL
    strcpy(url, api_url);

    // Append the user ID to the URL
    strcat(url, user_id);

    // Return the URL
    return url;
}

// BEGIN ENTRYPOINT
int main(int argc, char* argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <api_url> <user_id>\n", argv[0]);
        return 1;
    }

    // Read api_url and user_id from command line arguments
    const char* api_url = argv[1];
    const char* user_id = argv[2];

    // Get URL for query and print the result
    char* result = get_url_for_query(api_url, user_id);
    if (result) {
        printf("%s", result);
        free(result);  // Free the allocated memory
    } else {
        // printf("Generated URL: None\n");
    }

    return 0;
}
