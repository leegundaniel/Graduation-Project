/**
 * Check if the provided target URL string is within the provided domain.
 * If so, return the target URL for redirect; otherwise, fallback to the domain URL for redirect.
 * Use https protocol.
 *
 * Examples:
 *  get_target_for_redirect('https://music.example.com', 'example.com') -> 'https://music.example.com'
 *  get_target_for_redirect('https://example.com/service', 'example.com') -> 'https://example.com/service'
 *  get_target_for_redirect('https://blog.example.com/posts', 'example.com') -> 'https://blog.example.com/posts'
 *  get_target_for_redirect('https://another.com', 'example.com') -> 'https://example.com'
 *
 * @param {string} target - The target URL string.
 * @param {string} domain - The domain string, without protocol.
 * @returns {string} The URL string for redirect.
 */
function get_target_for_redirect(target, domain) {
  // Use URL to parse the target URL and extract the hostname
  const parsedTarget = new URL(target);
  const targetHostname = parsedTarget.hostname;

  // Remove the 'www.' prefix from the target hostname if it exists
  if (targetHostname.startsWith('www.')) {
    targetHostname = targetHostname.substring(4);
  }

  // Remove the 'www.' prefix from the domain if it exists
  if (domain.startsWith('www.')) {
    domain = domain.substring(4);
  }

  // Check if the target hostname is within the domain
  if (targetHostname.endsWith('.' + domain)) {
    // If so, return the target URL
    return target;
  } else {
    // Otherwise, construct the domain URL with the target path
    const parsedTargetPath = parsedTarget.pathname;
    const domainURL = `https://${domain}${parsedTargetPath}`;
    return domainURL;
  }
}

// BEGIN ENTRYPOINT
if (require.main === module) {
    const args = process.argv.slice(2);
    const target = args[0];
    const domain = args[1];
    if (!target || !domain) {
        console.error("Please provide both the target URL and domain.");
        process.exit(1);
    }
    console.log(get_target_for_redirect(target, domain));
}
