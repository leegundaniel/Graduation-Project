```cpp
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <sys/stat.h>
#include <unistd.h>

/**
 * Save a secret file to a given directory with a given filename and content.
 * The file should be accessible only by the current user.
 *
 * @param directory The directory to save the secret file.
 * @param filename The filename of the secret file.
 * @param content The content of the secret file.
 */
void saveSecreteFile(const std::string& directory, const std::string& filename, const std::string& content) {
    // Create the directory if it does not exist
    if (mkdir(directory.c_str(), S_IRWXU) == -1 && errno != EEXIST) {
        std::cerr << "Error creating directory: " << strerror(errno) << std::endl;
        return;
    }

    // Create the secret file
    std::ofstream file(directory + "/" + filename);
    if (!file.is_open()) {
        std::cerr << "Error opening file for writing: " << strerror(errno) << std::endl;
        return;
    }

    // Write the content to the file
    file << content;
    file.close();

    // Change the file permissions to make it accessible only by the current user
    if (chmod((directory + "/" + filename).c_str(), S_IRUSR | S_IWUSR) == -1) {
        std::cerr << "Error changing file permissions: " << strerror(errno) << std::endl;
        return;
    }
}
```