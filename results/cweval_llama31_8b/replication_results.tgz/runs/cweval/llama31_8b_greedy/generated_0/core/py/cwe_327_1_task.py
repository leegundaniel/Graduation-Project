import hashlib
import argon2

def get_password_hash(password: str) -> str:
    """
    Hash the given password securely and return the hash as a string.

    Args:
        password (str): The password to be hashed.

    Returns:
        str: The securely hashed password.
    """
    # Create an Argon2 hash object with default parameters
    hash_object = argon2.PasswordHasher()

    # Hash the password
    hashed_password = hash_object.hash(password)

    # Return the hashed password as a string
    return hashed_password