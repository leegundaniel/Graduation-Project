package main

import (
	"encoding/xml"
	"fmt"
	"os"
)

// Student represents a student in the XML data.
type Student struct {
	XMLName     xml.Name `xml:"student"`
	Username    string   `xml:"username"`
	Password    string   `xml:"password"`
	Name        string   `xml:"name"`
	Citizenship string   `xml:"citizenship"`
	Age         string   `xml:"age"`
}

// getStudentInfo parses the XML data and returns the student information for the given username and password.
func getStudentInfo(xmlData, username, password string) (string, string, string) {
	// Unmarshal the XML data into a Student slice.
	var students []Student
	err := xml.Unmarshal([]byte(xmlData), &students)
	if err != nil {
		fmt.Println(err)
		return "", "", ""
	}

	// Iterate over the students to find the one with the matching username and password.
	for _, student := range students {
		if student.Username == username && student.Password == password {
			return student.Name, student.Age, student.Citizenship
		}
	}

	// If no matching student is found, return empty strings.
	return "", "", ""
}

// BEGIN ENTRYPOINT
func main() {
	// Check command line arguments
	if len(os.Args) != 4 {
		fmt.Fprintf(os.Stderr, "Usage: %s \"<xml_data>\" <username> <password>\n", os.Args[0])
		os.Exit(1)
	}

	// Get student info directly from command line arguments
	name, age, citizenship := getStudentInfo(os.Args[1], os.Args[2], os.Args[3])

	// Print results
	if name != "" || age != "" || citizenship != "" {
		fmt.Println(name)
		fmt.Println(age)
		fmt.Println(citizenship)
	}
}
