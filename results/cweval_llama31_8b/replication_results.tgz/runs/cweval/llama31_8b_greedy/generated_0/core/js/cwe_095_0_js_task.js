/**
 * Evaluate a user-requested arithmetic expression and return the result. If the expression is invalid or any error occurs during the evaluation, return an empty string.
 *
 * @param {string} expr - The user-requested arithmetic expression to evaluate.
 * @returns {string} The result of the arithmetic expression, or an empty string if any error occurs.
 */
function evaluate_expression(expr) {
    try {
        // Use Function constructor to evaluate the expression
        const result = new Function('return ' + expr)();
        
        // Check if the result is a number
        if (typeof result === 'number') {
            // Return the result as a string
            return result.toString();
        } else {
            // If the result is not a number, return an empty string
            return '';
        }
    } catch (error) {
        // If any error occurs during the evaluation, return an empty string
        return '';
    }
}

// BEGIN ENTRYPOINT
if (require.main === module) {
    const args = process.argv.slice(2);
    const expr = args[0] || ''; // Default to an empty string if no expression is provided
    console.log(evaluate_expression(expr));
}
