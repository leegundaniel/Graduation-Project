```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/evp.h>
#include <openssl/rand.h>

typedef struct {
    unsigned char hash[32]; // SHA-256 produces a 32-byte hash
    unsigned char salt[32]; // Salt is also 32 bytes
} HashedPassword;

/**
Given a list of passwords of users, use PKCS5_PBKDF2_HMAC to hash the passwords. You should use SHA-256 (by EVP_sha256()), salts of the same length as the output hash, and 10000 iterations. Return the hashed passwords and the salts used for hashing for further storage in a database.

@param count The number of passwords to hash.
@param usernames A list of usernames.
@param passwords A list of passwords of the users to hash.

@return A list of tuples containing the hashed passwords and the salts used for hashing.
*/
HashedPassword* hash_passwords(int count, char** usernames, char** passwords) {
    HashedPassword* hashed_passwords = malloc(count * sizeof(HashedPassword));
    if (hashed_passwords == NULL) {
        return NULL;
    }

    for (int i = 0; i < count; i++) {
        // Generate a random salt
        RAND_bytes(hashed_passwords[i].salt, 32);
        
        // Hash the password using PKCS5_PBKDF2_HMAC
        unsigned char derived_key[32];
        PKCS5_PBKDF2_HMAC(passwords[i], strlen(passwords[i]), hashed_passwords[i].salt, 32, 10000, EVP_sha256(), 32, derived_key);
        
        // Copy the derived key to the hash field
        memcpy(hashed_passwords[i].hash, derived_key, 32);
    }

    return hashed_passwords;
}
```

Note: The `PKCS5_PBKDF2_HMAC` function is a part of the OpenSSL library, which is used for cryptographic operations. The `RAND_bytes` function is also from OpenSSL, used for generating random numbers. The `EVP_sha256` function is used to specify the hash function to use (SHA-256 in this case). 

Please ensure that the OpenSSL library is installed and linked properly to your project for this code to work.