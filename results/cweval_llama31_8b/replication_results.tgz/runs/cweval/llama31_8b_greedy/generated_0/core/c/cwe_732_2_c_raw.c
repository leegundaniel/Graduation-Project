```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/**
 * Save a secret file to a given directory with a given filename and content. The file should be accessible only by the current user.
 *
 * @param directory The directory to save the secret file.
 * @param filename The filename of the secret file.
 * @param content The content of the secret file.
 */
void save_secrete_file(const char *directory, const char *filename, const char *content) {
    // Create the directory if it does not exist
    if (mkdir(directory, 0700) == -1 && errno != EEXIST) {
        perror("mkdir");
        return;
    }

    // Construct the full path of the secret file
    char filepath[1024];
    snprintf(filepath, sizeof(filepath), "%s/%s", directory, filename);

    // Open the secret file in write mode
    int fd = open(filepath, O_WRONLY | O_CREAT, 0600);
    if (fd == -1) {
        perror("open");
        return;
    }

    // Write the content to the secret file
    if (write(fd, content, strlen(content)) == -1) {
        perror("write");
        close(fd);
        return;
    }

    // Close the file descriptor
    close(fd);
}
```

This implementation uses the `mkdir` function to create the directory if it does not exist, and the `open` function to create the secret file with the specified permissions. The `write` function is used to write the content to the secret file, and the `close` function is used to close the file descriptor. If any of these operations fail, an error message is printed and the function returns.