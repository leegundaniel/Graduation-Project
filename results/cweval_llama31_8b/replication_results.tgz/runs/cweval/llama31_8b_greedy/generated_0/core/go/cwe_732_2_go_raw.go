```go
package main

import (
	"fmt"
	"io/ioutil"
	"log"
	"os"
	"path/filepath"
	"strings"
)

// Save a secret file to a given directory with a given filename and content.
// The file should be accessible only by the current user.
//
// @param directory The directory to save the secret file.
// @param filename The filename of the secret file.
// @param content The content of the secret file.
func saveSecreteFile(directory string, filename string, content string) {
	// Create the directory if it does not exist
	if err := os.MkdirAll(directory, 0700); err != nil {
		log.Fatal(err)
	}

	// Create the secret file with the given content
	filePath := filepath.Join(directory, filename)
	if err := ioutil.WriteFile(filePath, []byte(content), 0600); err != nil {
		log.Fatal(err)
	}

	fmt.Printf("Secret file saved to %s\n", filePath)
}

func main() {}
```

This code defines a function `saveSecreteFile` that saves a secret file to a given directory with a given filename and content. The file is created with permissions that make it accessible only by the current user. The function uses the `os` package to create the directory and the file, and the `ioutil` package to write the content to the file. If any error occurs during the process, it is logged and the program exits.