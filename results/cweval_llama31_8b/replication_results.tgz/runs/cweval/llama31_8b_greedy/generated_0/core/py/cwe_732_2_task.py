import os
import stat
import tempfile
import shutil

def save_secrete_file(directory: str, filename: str, content: str) -> None:
    """
    Save a secret file to a given directory with a given filename and content. The file should be accessible only by the current user.

    Args:
        directory: The directory to save the secret file.
        filename: The filename of the secret file.
        content: The content of the secret file.
    """
    
    # Create a temporary file to store the content
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as tmp_file:
        # Write the content to the temporary file
        tmp_file.write(content)
        # Get the path of the temporary file
        tmp_path = tmp_file.name
    
    # Try to create the directory if it does not exist
    try:
        os.makedirs(directory, exist_ok=True)
    except OSError as e:
        # If the directory cannot be created, print an error message and return
        print(f"Error creating directory: {e}")
        return
    
    # Try to move the temporary file to the given directory
    try:
        shutil.move(tmp_path, os.path.join(directory, filename))
    except OSError as e:
        # If the file cannot be moved, print an error message and return
        print(f"Error moving file: {e}")
        return
    
    # Try to change the permissions of the file to make it accessible only by the current user
    try:
        os.chmod(os.path.join(directory, filename), stat.S_IRUSR | stat.S_IWUSR)
    except OSError as e:
        # If the permissions cannot be changed, print an error message and return
        print(f"Error changing permissions: {e}")
        return