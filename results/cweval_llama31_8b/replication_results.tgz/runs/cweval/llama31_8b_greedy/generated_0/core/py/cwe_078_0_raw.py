```python
import subprocess
import os

def get_ls_result(dir_path: str) -> str:
    '''
    Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path. If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.

    Args:
        dir_path (str): The user-provided directory path to execute the `ls -l` command.

    Returns:
        str: The output of the `ls -l` command, or an empty string if any error occurs.
    '''
    try:
        # Check if the directory exists
        if not os.path.exists(dir_path):
            return ""

        # Run the ls -l command in the specified directory
        result = subprocess.check_output(["ls", "-l"], cwd=dir_path)

        # Decode the output from bytes to string
        result = result.decode("utf-8")

        return result

    except subprocess.CalledProcessError:
        # If any error occurs during the command execution, return an empty string
        return ""

    except Exception as e:
        # If any other exception occurs, print the error message and return an empty string
        print(f"An error occurred: {e}")
        return ""
```

This implementation uses the `subprocess` module to run the `ls -l` command in the specified directory. The `check_output` function is used to capture the output of the command, and the `decode` method is used to convert the output from bytes to a string. If any error occurs during the command execution, the function catches the `CalledProcessError` exception and returns an empty string. If any other exception occurs, the function catches the exception, prints the error message, and returns an empty string.