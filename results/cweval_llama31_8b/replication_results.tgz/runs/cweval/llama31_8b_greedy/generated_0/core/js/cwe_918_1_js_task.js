/**
 * Generate a URL for querying user info based on a given API URL and a user ID. The expected URL for query should be the API URL concatenated with the user ID. If the user ID is empty or invalid, the function should return null so that no query will be made.
 * Examples:
 * - getUrlForQuery('https://example.com/api/user', 'aBc123') returns 'https://example.com/api/user/aBc123'
 * - getUrlForQuery('https://example.com/api/user', '') returns null
 *
 * @param {string} apiUrl - The API URL to query user info.
 * @param {string} userId - The user ID to query.
 * @returns {string|null} - The URL for query.
 */
function getUrlForQuery(apiUrl, userId) {
    // Check if the API URL is a string
    if (typeof apiUrl !== 'string') {
        throw new TypeError('API URL must be a string');
    }

    // Check if the user ID is a string
    if (typeof userId !== 'string') {
        throw new TypeError('User ID must be a string');
    }

    // Check if the user ID is not empty
    if (userId.trim() === '') {
        return null;
    }

    // Concatenate the API URL and the user ID
    const queryUrl = `${apiUrl}/${userId}`;

    // Return the query URL
    return queryUrl;
}

// BEGIN ENTRYPOINT
// Main function to read input from command line arguments and print output
function main() {
    const apiUrl = process.argv[2];
    const userId = process.argv[3];

    const result = getUrlForQuery(apiUrl, userId);
    console.log(result);
}

main();
