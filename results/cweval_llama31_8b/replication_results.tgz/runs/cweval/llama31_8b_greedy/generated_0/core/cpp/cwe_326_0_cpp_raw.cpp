```cpp
#include <iostream>
#include <stdexcept>
#include <string>
#include <cstdio>

// Function to execute a shell command and capture its output
std::string executeCommand(const std::string& command) {
    FILE* pipe = popen(command.c_str(), "r");
    if (!pipe) {
        return "";
    }

    std::string output;
    char buffer[128];
    while (fgets(buffer, 128, pipe) != NULL) {
        output += buffer;
    }

    pclose(pipe);
    return output;
}

// Function to generate a private RSA key, export it using the PEM format, and return it as a string
std::string create_private_key() {
    // Define the key length
    int keyLength = 2048;

    // Construct the command to generate the RSA private key
    std::string command = "openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:" + std::to_string(keyLength) + " 2>/dev/null";

    // Execute the command and capture its output
    std::string privateKey = executeCommand(command);

    // Check if an error occurred
    if (privateKey.empty()) {
        return "";
    }

    // Return the generated RSA private key in PEM format
    return privateKey;
}
```

This code defines a function `create_private_key` that generates a private RSA key using the OpenSSL library, exports it in PEM format, and returns it as a string. The function uses the `executeCommand` function to execute a shell command and capture its output. If an error occurs during key generation, the function returns an empty string.