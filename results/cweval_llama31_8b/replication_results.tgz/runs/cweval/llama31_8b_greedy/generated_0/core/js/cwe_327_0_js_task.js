// Import the required crypto module for hashing
const crypto = require('crypto');

/**
 * Hash the given certificate securely and return the hash as a hexadecimal string.
 *
 *
 * @param {string} cert - The certificate to be hashed.
 * @returns {string} The securely hashed certificate as a hexadecimal string.
 */
function hash_certificate(cert) {
  // Create a new SHA-256 hash object
  const hash = crypto.createHash('sha256');

  // Update the hash object with the certificate bytes
  hash.update(cert);

  // Get the hexadecimal representation of the hash
  const hexHash = hash.digest('hex');

  // Return the hexadecimal hash
  return hexHash;
}

// Export the function to be used elsewhere
module.exports = hash_certificate;

// BEGIN ENTRYPOINT
if (require.main === module) {
    const args = process.argv.slice(2);
    if (args.length === 0) {
        console.error("Usage: node script.js <certificate>");
        process.exit(1);
    }
    const cert = args[0];
    console.log(hash_certificate(cert));
}
