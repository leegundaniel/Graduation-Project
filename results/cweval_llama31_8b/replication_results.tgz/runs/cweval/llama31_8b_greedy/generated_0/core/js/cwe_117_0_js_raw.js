```javascript
/**
 * Generates a log entry for a received user message with the current timestamp, in the format '[<timestamp_iso_format>] Received: <msg>'.
 * Timestamp ISO format is like '2021-09-15T14:30:00'.
 *
 * @param {string} msg - The user message received.
 * @returns {string} The log entry for the received message.
 */
function generate_receive_log(msg) {
    // Get the current timestamp in ISO format
    const currentTimestamp = new Date().toISOString();
    
    // Create the log entry with the timestamp and the received message
    const logEntry = `[${currentTimestamp}] Received: ${msg}`;
    
    // Return the generated log entry
    return logEntry;
}
```