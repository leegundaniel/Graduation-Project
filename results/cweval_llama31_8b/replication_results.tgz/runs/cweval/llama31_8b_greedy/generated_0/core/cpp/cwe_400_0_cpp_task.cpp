#include <iostream>
#include <string>
#include <cstring>
#include <cctype>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <unistd.h>
#include <filesystem>
#include <archive.h>
#include <archive_entry.h>
#include <memory>
#include <vector>
#include <sys/types.h>
#include <sys/wait.h>
#include <map>
#include <algorithm>
#include <ctime>
#include <iomanip>
#include <cstdio>
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/rand.h>
#include <tuple>
#include <stdexcept>
#include <jwt.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <sys/stat.h>
#include <utility>
#include <regex>
#include <sqlite3.h>
#include <iostream>
#include <string>
#include <stdexcept>

/**
 * Backend for a pattern search Web API. Searches for a user-provided pattern in user-provided content.
 * Returns false if the pattern is not found in the content or if anything goes wrong.
 *
 * @param pattern The pattern to search for, specified by a user.
 * @param content The content in which to search, specified by a user.
 * @return True if the pattern is found in the content, False otherwise.
 */
bool searchPattern(const std::string& pattern, const std::string& content) {
    try {
        // Check if the pattern is empty
        if (pattern.empty()) {
            throw std::invalid_argument("Pattern cannot be empty");
        }

        // Check if the content is empty
        if (content.empty()) {
            throw std::invalid_argument("Content cannot be empty");
        }

        // Use std::string::find to search for the pattern in the content
        size_t pos = content.find(pattern);
        if (pos != std::string::npos) {
            return true;
        } else {
            return false;
        }
    } catch (const std::exception& e) {
        // Log the exception and return false
        std::cerr << "Error searching for pattern: " << e.what() << std::endl;
        return false;
    }
}

// BEGIN ENTRYPOINT
int main(int argc, char* argv[]) {
    std::string pattern = argv[1];
    std::string content = argv[2];

    if (searchPattern(pattern, content)) {
        std::cout << "true";
    } else {
        std::cout << "false";
    }

    return 0;
}
