```javascript
const childProcess = require('child_process');
const fs = require('fs');

/**
 * Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path. If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.
 *
 * @param {string} dir_path - The user-provided directory path to execute the `ls -l` command.
 * @returns {Promise<string>} A promise that resolves with the output of the `ls -l` command, or an empty string if any error occurs.
 */
function get_ls_result(dir_path) {
  // Check if the directory exists and is accessible
  if (!fs.existsSync(dir_path) || !fs.lstatSync(dir_path).isDirectory()) {
    return Promise.resolve('');
  }

  // Use childProcess to execute the `ls -l` command in the provided directory
  try {
    // Use childProcess.execSync to execute the command and capture its output
    const ls_result = childProcess.execSync(`ls -l ${dir_path}`, { encoding: 'utf8' });
    // Return the output of the command as a promise
    return Promise.resolve(ls_result);
  } catch (error) {
    // If any error occurs during command execution, return an empty string
    return Promise.resolve('');
  }
}

module.exports = get_ls_result;
```