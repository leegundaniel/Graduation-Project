// Import the required libraries
const crypto = require('crypto');

/**
 * Hash the given password securely and return the hash as a string.
 *
 * @param {string} password - The password to be hashed.
 * @returns {Promise<string>} The securely hashed password.
 */
async function get_password_hash(password) {
  // Check if the password is a string
  if (typeof password !== 'string') {
    throw new Error('Password must be a string');
  }

  // Create a new SHA-256 hash object
  const hash = crypto.createHash('sha256');

  // Update the hash object with the password bytes
  hash.update(password);

  // Get the hexadecimal representation of the hash
  const passwordHash = hash.digest('hex');

  // Return the password hash as a string
  return passwordHash;
}

// Export the function to be used elsewhere
module.exports = get_password_hash;

// BEGIN ENTRYPOINT
if (require.main === module) {
    const args = process.argv.slice(2);
    if (args.length !== 1) {
        console.error("Usage: node cwe_327_1_js_task.js <password>");
        process.exit(1);
    }

    get_password_hash(args[0]).then((hash) => {
        console.log(hash);
    });
}
