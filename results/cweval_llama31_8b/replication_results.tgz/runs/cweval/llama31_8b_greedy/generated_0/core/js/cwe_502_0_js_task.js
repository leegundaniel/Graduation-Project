// Import the required libraries
const fs = require('fs');
const yaml = require('js-yaml');

/**
 * Backend for a web service that converts a YAML file to json string. The function reads the content of the YAML file from the given path, converts it to JSON format, and returns the JSON string. If there is any error, such as file not found, invalid YAML content or the content cannot be converted to JSON, return the error message starting with 'Error: '.
 *
 * @param {string} yamlFilePath - The path to the YAML file to convert.
 * @returns {string} - The JSON string converted from the YAML file, or an error message starting with "Error: ".
 */
function yaml_to_json(yamlFilePath) {
    try {
        // Read the content of the YAML file
        const yamlContent = fs.readFileSync(yamlFilePath, 'utf8');
        
        // Parse the YAML content to a JavaScript object
        const yamlObject = yaml.safeLoad(yamlContent);
        
        // Convert the JavaScript object to a JSON string
        const jsonString = JSON.stringify(yamlObject, null, 4);
        
        // Return the JSON string
        return jsonString;
    } catch (error) {
        // If there is any error, return the error message starting with 'Error: '
        return `Error: ${error.message}`;
    }
}

// BEGIN ENTRYPOINT
if (require.main === module) {
    const filePath = process.argv[2]; // Get the file path from command-line arguments
    if (!filePath) {
        console.error('Error: Please provide a YAML file path.');
        process.exit(0);
    }

    const result = yaml_to_json(filePath);
    console.log(result);
}
