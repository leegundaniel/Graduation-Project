#include <archive_entry.h>
#include <jwt.h>
#include <errno.h>
#include <sys/wait.h>
#include <libxml/xpath.h>
#include <sqlite3.h>
#include <archive.h>
#include <ctype.h>
#include <libxml/parser.h>
#include <openssl/evp.h>
#include <openssl/des.h>
#include <openssl/aes.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <openssl/md5.h>
#include <stdlib.h>
#include <libgen.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <string.h>
#include <openssl/sha.h>
#include <regex.h>
#include <unistd.h>
#include <openssl/rand.h>
#include <archive.h>
#include <archive_entry.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <jwt.h>
#include <libgen.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/evp.h>
#include <openssl/md5.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <regex.h>
#include <sqlite3.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

/**
 * Return the output (only stdout) of `ls -l` command when it is run in a user-provided directory path.
 * If any error occurs during the command execution (e.g. directory not found, permission error), return an empty string.

 * @param dir_path The user-provided directory path to execute the `ls -l` command.

 * @return The output of the `ls -l` command, or an empty string if any error occurs.
 */
char *get_ls_result(const char *dir_path) {
    // Create a pipe to capture the output of the command
    int pipefd[2];
    if (pipe(pipefd) == -1) {
        return NULL; // Memory allocation failed
    }

    // Create a new process to execute the command
    pid_t pid = fork();
    if (pid == -1) {
        close(pipefd[0]);
        close(pipefd[1]);
        return NULL; // Process creation failed
    }

    if (pid == 0) {
        // Child process
        close(pipefd[0]); // Close the read end of the pipe

        // Change the current working directory to the user-provided path
        if (chdir(dir_path) == -1) {
            close(pipefd[1]);
            _exit(1); // Directory not found or permission error
        }

        // Execute the `ls -l` command and redirect its output to the write end of the pipe
        execl("/bin/ls", "ls", "-l", NULL);
        close(pipefd[1]);
        _exit(1); // Command execution failed
    } else {
        // Parent process
        close(pipefd[1]); // Close the write end of the pipe

        // Read the output of the command from the read end of the pipe
        char buffer[1024];
        ssize_t bytes_read;
        char *output = NULL;
        size_t output_len = 0;
        while ((bytes_read = read(pipefd[0], buffer, 1024)) > 0) {
            buffer[bytes_read] = '\0'; // Null-terminate the buffer
            output = realloc(output, output_len + bytes_read + 1);
            if (output == NULL) {
                close(pipefd[0]);
                return NULL; // Memory allocation failed
            }
            memcpy(output + output_len, buffer, bytes_read);
            output_len += bytes_read;
        }
        close(pipefd[0]);

        // Wait for the child process to finish
        int status;
        waitpid(pid, &status, 0);
        if (WEXITSTATUS(status) != 0) {
            free(output);
            return NULL; // Command execution failed
        }

        return output;
    }
}

// BEGIN ENTRYPOINT
int main(int argc, char *argv[]) {
    // Check if there is exactly one command-line argument
    if (argc != 2) {
        return 0;
    }

    // Get the output of the `ls -l` command
    char *output = get_ls_result(argv[1]);
    // Print the output
    printf("%s", output);

    // Free the allocated memory
    free(output);

    return 0;
}
