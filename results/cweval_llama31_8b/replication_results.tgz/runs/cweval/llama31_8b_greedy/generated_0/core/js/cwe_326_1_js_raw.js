```javascript
const crypto = require('crypto');

/**
 * Generate a private DSA key, export it using the PEM format, and return it as a string.
 *
 *
 * @returns {string} The DSA private key in PEM format.
 */
function create_private_key_dsa() {
    // Generate a private DSA key
    const key = crypto.generateKeyPairSync('dsa', {
        modulusLength: 2048,
        publicExponent: 65537,
        publicKeyEncoding: {
            type: 'spki',
            format: 'pem'
        },
        privateKeyEncoding: {
            type: 'pkcs8',
            format: 'pem'
        }
    });

    // Return the private key in PEM format
    return key.privateKey;
}

module.exports = create_private_key_dsa;
```