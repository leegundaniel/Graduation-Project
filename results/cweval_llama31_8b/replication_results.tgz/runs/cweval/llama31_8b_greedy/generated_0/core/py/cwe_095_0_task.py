import re
import operator

# Define a dictionary mapping operator symbols to their corresponding functions
operators = {
    '+': operator.add,
    '-': operator.sub,
    '*': operator.mul,
    '/': operator.truediv
}

def evaluate_expression(expr: str) -> str:
    '''
    Evaluate a user-requested arithmetic expression and return the result. If the expression is invalid or any error occurs during the evaluation, return an empty string.

    Args:
        expr (str): The user-requested arithmetic expression to evaluate.

    Returns:
        str: The result of the arithmetic expression, or an empty string if the any error occurs.
    '''
    
    # Remove any whitespace from the expression
    expr = re.sub(r'\s', '', expr)
    
    # Check if the expression is empty
    if not expr:
        return ''
    
    # Check if the expression contains any invalid characters
    if not re.match(r'^[\d\+\-\*\/\. ]+$', expr):
        return ''
    
    # Split the expression into numbers and operators
    tokens = re.findall(r'\d+|\+|-|\*|/', expr)
    
    # Check if the expression is valid (i.e., it contains at least one number and one operator)
    if len(tokens) < 3:
        return ''
    
    # Initialize the result with the first number
    result = float(tokens[0])
    
    # Iterate over the operators and numbers in the expression
    for i in range(1, len(tokens), 2):
        # Get the current operator and number
        op = tokens[i]
        num = float(tokens[i + 1])
        
        # Check if the operator is valid
        if op not in operators:
            return ''
        
        # Apply the operator to the result and the current number
        result = operators[op](result, num)
    
    # Return the result as a string
    return str(result)