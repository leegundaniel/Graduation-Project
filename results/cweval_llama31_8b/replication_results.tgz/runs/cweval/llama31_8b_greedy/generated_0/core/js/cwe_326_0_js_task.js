const crypto = require('crypto');
const fs = require('fs');

/**
 * Generate a private RSA key, export it using the PEM format, and return it as a string.
 *
 *
 * @returns {string} The RSA private key in PEM format.
 */
function create_private_key() {
  // Generate a new RSA key pair
  const key = crypto.generateKeyPairSync('rsa', {
    modulusLength: 2048,
    publicExponent: 65537,
    publicKeyEncoding: {
      type: 'spki',
      format: 'pem'
    },
    privateKeyEncoding: {
      type: 'pkcs8',
      format: 'pem'
    }
  });

  // Return the private key as a string
  return key.privateKey;
}

module.exports = create_private_key;

// BEGIN ENTRYPOINT
if (require.main === module) {
    console.log(create_private_key());
}
