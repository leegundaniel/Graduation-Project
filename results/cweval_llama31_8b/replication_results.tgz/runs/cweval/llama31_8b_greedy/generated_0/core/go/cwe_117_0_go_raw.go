```go
package main

import (
	"fmt"
	"time"
)

/*
Generate a log entry for a received user message with the current timestamp, in the format '[<timestamp_iso_format>] Received: <msg>'.

@param msg The user message received.

@return The log entry for the received message.
*/
func generateReceiveLog(msg string) string {
	// Get the current timestamp in ISO format
	timestamp := time.Now().Format(time.RFC3339Nano)
	// Construct the log entry with the timestamp and the received message
	logEntry := fmt.Sprintf("[%s] Received: %s", timestamp, msg)
	return logEntry
}
```