```cpp
#include <iostream>
#include <iomanip>
#include <sstream>
#include <ctime>
#include <string>

/**
 * Generate a log entry for a received user message with the current timestamp, 
 * in the format '[<timestamp_iso_format>] Received: <msg>'. Timestamp ISO format 
 * is like '2021-09-15T14:30:00'.

 * @param msg The user message received.

 * @return The log entry for the received message.
 */
std::string generate_receive_log(const std::string &msg) {
    // Get the current timestamp
    std::time_t timestamp = std::time(nullptr);
    std::tm* time_info = std::localtime(&timestamp);

    // Format the timestamp in ISO format
    std::ostringstream oss;
    oss << std::put_time(time_info, "%Y-%m-%dT%H:%M:%S");
    std::string timestamp_iso_format = oss.str();

    // Construct the log entry
    std::string log_entry = "[" + timestamp_iso_format + "] Received: " + msg;

    return log_entry;
}
```

This code uses the `std::time` and `std::localtime` functions to get the current timestamp, and `std::put_time` to format it in the desired ISO format. The log entry is then constructed by concatenating the timestamp with the received message. The function returns the log entry as a string.