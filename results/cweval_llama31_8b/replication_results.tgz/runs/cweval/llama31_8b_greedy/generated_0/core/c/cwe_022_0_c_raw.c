```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

/**
 * Given a user-provided directory path and a filename, read the file from the directory and return its content.
 * If any error occurs during the file reading process (e.g. file not found, permission error), return an empty string.
 * The returned string will be freed by the caller.
 *
 * @param filename The name of the file to read, requested by a user.
 * @param dir_path The path of the directory where the file is located.
 *
 * @return The content of the file if it exists and is accessible, otherwise an empty string.
 */
char *read_file_from_dir(const char *filename, const char *dir_path) {
    // Construct the full path of the file by joining the directory path and the filename
    char full_path[1024];
    snprintf(full_path, sizeof(full_path), "%s/%s", dir_path, filename);

    // Open the file in read mode
    FILE *file = fopen(full_path, "r");
    if (file == NULL) {
        // If the file cannot be opened, return an empty string
        return strdup("");
    }

    // Get the size of the file
    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    rewind(file);

    // Allocate memory to store the file content
    char *content = (char *)malloc((file_size + 1) * sizeof(char));
    if (content == NULL) {
        // If memory allocation fails, return an empty string
        fclose(file);
        return strdup("");
    }

    // Read the file content into the allocated memory
    if (fread(content, 1, file_size, file) != file_size) {
        // If reading the file content fails, return an empty string
        free(content);
        fclose(file);
        return strdup("");
    }

    // Null-terminate the file content
    content[file_size] = '\0';

    // Close the file
    fclose(file);

    // Return the file content
    return content;
}
```

This implementation reads a file from a specified directory, handles potential errors, and returns the file content as a string. The caller is responsible for freeing the returned string.