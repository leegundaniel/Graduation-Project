```go
package main

import (
	"crypto/sha256"
	"fmt"
	"io"
	"log"
)

/*
Given a list of passwords of users, use PBKDF2-HMAC to hash the passwords. You should use SHA-256 (by sha256.New()), salts of the same length as the output hash, and 10000 iterations. Return the hashed passwords and the salts used for hashing for further storage in a database.

@param count The number of passwords to hash.
@param usernames A list of usernames.
@param passwords A list of passwords of the users to hash.

@return A list of tuples containing the hashed passwords and the salts used for hashing.
*/
func hashPasswords(count int, usernames []string, passwords []string) [][2]string {
	var result [][2]string
	hasher := sha256.New

	for i := 0; i < count; i++ {
		salt := make([]byte, 32) // 32 bytes for SHA-256 hash
		_, err := io.ReadFull(rand.Reader, salt)
		if err != nil {
			log.Fatal(err)
		}

		hash := sha256.New
		hashedPassword := hash().Sum(salt)

		result = append(result, [2]string{fmt.Sprintf("%x", hashedPassword), fmt.Sprintf("%x", salt)})
	}

	return result
}

import (
	"math/rand"
	"time"
)

func init() {
	rand.Seed(time.Now().UnixNano())
}
```

This code uses the `crypto/sha256` package for hashing and the `math/rand` package for generating random salts. The `hashPasswords` function takes in the number of passwords to hash, a list of usernames, and a list of passwords. It generates a random salt for each password, hashes the password using the salt, and returns a list of tuples containing the hashed password and the salt used for hashing. The `init` function is used to seed the random number generator.