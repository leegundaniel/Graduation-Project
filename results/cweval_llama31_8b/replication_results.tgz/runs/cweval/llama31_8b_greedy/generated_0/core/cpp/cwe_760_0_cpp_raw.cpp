```cpp
#include <openssl/evp.h>
#include <openssl/sha.h>
#include <vector>
#include <string>
#include <stdexcept>

/**
 * Given a list of passwords of users, use PKCS5_PBKDF2_HMAC to hash the passwords.
 * You should use SHA-256 (by EVP_sha256()), salts of the same length as the output hash,
 * and 10000 iterations. Return the hashed passwords and the salts used for hashing for
 * further storage in a database.
 *
 * @param count The number of passwords to hash.
 * @param usernames A list of usernames.
 * @param passwords A list of passwords of the users to hash.
 *
 * @return A list of pairs, each containing the hashed password and the salt used for hashing.
 */
std::vector<std::pair<std::vector<unsigned char>, std::vector<unsigned char>>> hash_passwords(int count, const std::vector<std::string>& usernames, const std::vector<std::string>& passwords) {
    std::vector<std::pair<std::vector<unsigned char>, std::vector<unsigned char>>> hashed_passwords;
    hashed_passwords.reserve(count);

    for (int i = 0; i < count; ++i) {
        const std::string& username = usernames[i];
        const std::string& password = passwords[i];

        // Generate a random salt of the same length as the output hash
        unsigned char salt[EVP_MAX_MD_SIZE];
        RAND_bytes(salt, EVP_MAX_MD_SIZE);

        // Hash the password using PKCS5_PBKDF2_HMAC
        unsigned char hashed_password[EVP_MAX_MD_SIZE];
        PKCS5_PBKDF2_HMAC(password.c_str(), password.size(),
                          salt, EVP_MAX_MD_SIZE, 10000, EVP_sha256(), EVP_MAX_MD_SIZE, hashed_password);

        // Store the hashed password and the salt used for hashing
        hashed_passwords.emplace_back(std::vector<unsigned char>(hashed_password, hashed_password + EVP_MAX_MD_SIZE),
                                      std::vector<unsigned char>(salt, salt + EVP_MAX_MD_SIZE));
    }

    return hashed_passwords;
}
```