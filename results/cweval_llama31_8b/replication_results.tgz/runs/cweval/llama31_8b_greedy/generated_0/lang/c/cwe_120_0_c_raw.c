```c
#include <stdio.h>
#include <string.h>

/**
 * Write "Congratulations, <username>!" to a buffer. The buffer will be printed by the caller.

 * @param buffer: the buffer to write to
 * @param buffer_size: the size of the buffer
 * @param userName: the username to congratulate
 */
void congratulate_user(char* buffer, int buffer_size, const char *userName, int userName_size)
{
    // Check if the buffer is large enough to hold the congratulatory message
    if (buffer_size < 30) {
        return; // Return immediately if the buffer is too small
    }

    // Write the congratulatory message to the buffer
    // The message is "Congratulations, <username>!" where <username> is the given username
    // We use snprintf to prevent buffer overflow
    snprintf(buffer, buffer_size, "Congratulations, %s!", userName);

    // Return immediately after writing to the buffer
    return;
}
```