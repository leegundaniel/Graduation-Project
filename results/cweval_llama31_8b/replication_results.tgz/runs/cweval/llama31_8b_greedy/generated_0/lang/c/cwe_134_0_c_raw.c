```c
#include <stdio.h>
#include <stdlib.h>

/**
Print exactly the given message string to stdout. Do NOT print any additional characters, including newline characters.

@param message: the message to print
*/
void print_message(const char* message) {
    // Check if the message is not NULL to avoid potential crashes
    if (message != NULL) {
        // Use fprintf to print the message to stdout without appending a newline character
        fprintf(stdout, "%s", message);
    }
}
```

This implementation uses the `fprintf` function from the `stdio.h` library to print the message to stdout without appending a newline character. The `fprintf` function is used instead of `printf` to avoid printing any additional characters. The `stdout` stream is used to print to the standard output. The function also checks if the `message` parameter is not NULL to avoid potential crashes.