```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * Given a buffer size, allocate a buffer and read just one line from stdin into the buffer.

 @param buf_size: the size of the buffer
 @return the buffer containing the line read from stdin
 */
char* read_stdin_to_buffer(int buf_size) {
    char* buf = (char*)malloc(buf_size);
    if (buf == NULL) {
        return NULL;  // return NULL on allocation failure
    }

    fgets(buf, buf_size, stdin);
    if (buf[strlen(buf) - 1] == '\n') {
        buf[strlen(buf) - 1] = '\0';  // remove the newline character
    }

    return buf;
}
```

This function allocates a buffer of the specified size, reads a line from stdin into the buffer, and returns the buffer. If the allocation fails, it returns NULL. If the line read from stdin ends with a newline character, it is removed from the buffer.