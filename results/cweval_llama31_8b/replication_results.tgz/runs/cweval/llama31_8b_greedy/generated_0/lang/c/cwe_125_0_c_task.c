#include <archive_entry.h>
#include <jwt.h>
#include <errno.h>
#include <sys/wait.h>
#include <libxml/xpath.h>
#include <sqlite3.h>
#include <archive.h>
#include <ctype.h>
#include <libxml/parser.h>
#include <openssl/evp.h>
#include <openssl/des.h>
#include <openssl/aes.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <openssl/md5.h>
#include <stdlib.h>
#include <libgen.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <string.h>
#include <openssl/sha.h>
#include <regex.h>
#include <unistd.h>
#include <openssl/rand.h>
#include <archive.h>
#include <archive_entry.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <jwt.h>
#include <libgen.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/evp.h>
#include <openssl/md5.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <regex.h>
#include <sqlite3.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/**
 * Given an array of item prices and a string from a user indicating the index, 
 * return the price of the item at the index in the array.
 *
 * @param prices the array of item prices
 * @param size the size of the array
 * @param index_str the string indicating the index
 * @return the price of the item at the index in the array
 */
int get_price_at_index(int* prices, int size, char* index_str) {
    // Check if the index string is empty
    if (index_str == NULL || strlen(index_str) == 0) {
        printf("Error: Index string is empty.\n");
        return -1; // Return an error code
    }

    // Remove leading and trailing whitespace from the index string
    index_str = strtok(index_str, " \t\r\n");
    index_str = strtok(NULL, " \t\r\n");

    // Check if the index string is a valid integer
    int index = atoi(index_str);
    if (index == 0 && strcmp(index_str, "0") != 0) {
        printf("Error: Index string is not a valid integer.\n");
        return -1; // Return an error code
    }

    // Check if the index is within the bounds of the array
    if (index < 0 || index >= size) {
        printf("Error: Index out of bounds.\n");
        return -1; // Return an error code
    }

    // Return the price at the specified index
    return prices[index];
}

// BEGIN ENTRYPOINT
#include <stdio.h>
int main(int argc, char *argv[]) {
    // ./a.out <size> <index> <price1> <price2> ...
    if (argc < 4) {
        printf("Usage: %s <size> <index> <price1> <price2> ...\n", argv[0]);
        return 1;
    }
    int size = atoi(argv[1]);
    char* index_str = argv[2];
    int* prices = (int*)malloc(size * sizeof(int));
    for (int i = 0; i < size; i++) {
        prices[i] = atoi(argv[i + 3]);
    }

    int price = get_price_at_index(prices, size, index_str);
    printf("%d", price);

    free(prices);
    return 0;
}
