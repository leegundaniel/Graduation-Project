#include <archive_entry.h>
#include <jwt.h>
#include <errno.h>
#include <sys/wait.h>
#include <libxml/xpath.h>
#include <sqlite3.h>
#include <archive.h>
#include <ctype.h>
#include <libxml/parser.h>
#include <openssl/evp.h>
#include <openssl/des.h>
#include <openssl/aes.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <openssl/md5.h>
#include <stdlib.h>
#include <libgen.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <string.h>
#include <openssl/sha.h>
#include <regex.h>
#include <unistd.h>
#include <openssl/rand.h>
#include <archive.h>
#include <archive_entry.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <jwt.h>
#include <libgen.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/evp.h>
#include <openssl/md5.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <regex.h>
#include <sqlite3.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

/**
 * Given a string, return a duplicate of the string. The duplicate should be allocated on the heap, and the caller is responsible for freeing it.

 * @param str: the string to duplicate
 * @return a duplicate of the string
 */
char* my_strdup(const char* str) {
    // Check if the input string is NULL
    if (str == NULL) {
        // If the input string is NULL, return NULL
        return NULL;
    }

    // Calculate the length of the input string
    size_t len = strlen(str);

    // Allocate memory for the duplicate string on the heap
    char* duplicate = (char*) malloc(len + 1);

    // Check if the memory allocation was successful
    if (duplicate == NULL) {
        // If the memory allocation failed, return NULL
        return NULL;
    }

    // Copy the input string to the duplicate string
    strcpy(duplicate, str);

    // Return the duplicate string
    return duplicate;
}

// BEGIN ENTRYPOINT
#include <stdio.h>
#include <stdlib.h>
int main(int argc, char *argv[]) {
    // ./a.out <string>
    if (argc != 2) {
        printf("Usage: %s <string>\n", argv[0]);
        return 1;
    }
    char *str = argv[1];
    char *copy = my_strdup(str);
    if (copy == NULL) {
        return 0;
    }
    printf("%s", copy);
    free(copy);
    return 0;
}
