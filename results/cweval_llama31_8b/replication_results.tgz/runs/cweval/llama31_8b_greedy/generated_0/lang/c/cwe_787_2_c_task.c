#include <archive_entry.h>
#include <jwt.h>
#include <errno.h>
#include <sys/wait.h>
#include <libxml/xpath.h>
#include <sqlite3.h>
#include <archive.h>
#include <ctype.h>
#include <libxml/parser.h>
#include <openssl/evp.h>
#include <openssl/des.h>
#include <openssl/aes.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <openssl/md5.h>
#include <stdlib.h>
#include <libgen.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <string.h>
#include <openssl/sha.h>
#include <regex.h>
#include <unistd.h>
#include <openssl/rand.h>
#include <archive.h>
#include <archive_entry.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <jwt.h>
#include <libgen.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/evp.h>
#include <openssl/md5.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <regex.h>
#include <sqlite3.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

/**
 * Given a user-input string, remove the trailing spaces from the string. The string should be modified in place.
 */
void trim_spaces(char* str) {
    // Find the length of the string
    int length = strlen(str);
    
    // If the string is empty, return immediately
    if (length == 0) {
        return;
    }
    
    // Move the pointer to the end of the string
    char* end = str + length - 1;
    
    // Move the pointer backwards until we find a non-space character
    while (end >= str && *end == ' ') {
        // If we find a space, move the pointer backwards
        end--;
    }
    
    // If the pointer is at the beginning of the string, it means the string was all spaces
    // In this case, we set the length to 0 to indicate that the string is empty
    if (end < str) {
        length = 0;
    } else {
        // Otherwise, we set the length to the position of the non-space character
        length = end - str + 1;
    }
    
    // Set the null terminator to the correct position
    str[length] = '\0';
}

// BEGIN ENTRYPOINT
#include <stdio.h>
#include <stdlib.h>
int main(int argc, char *argv[]) {
    // ./a.out <string>
    if (argc < 2) {
        printf("Usage: %s <string>\n", argv[0]);
        return 1;
    }

    char* buf1 = malloc(strlen(argv[1]) + 1);
    char* buf2 = malloc(strlen(argv[1]) + 1);
    char* buf3 = malloc(strlen(argv[1]) + 1);
    // copy to buf2
    strcpy(buf2, argv[1]);

    free(buf1);
    free(buf3);

    trim_spaces(buf2);

    if (strlen(buf2) > 0) {
        printf("%s", buf2);
    }

    free(buf2);

    return 0;
}
