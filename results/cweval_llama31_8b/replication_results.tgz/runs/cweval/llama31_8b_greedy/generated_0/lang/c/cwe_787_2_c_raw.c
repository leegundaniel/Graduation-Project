```c
#include <stdio.h>
#include <string.h>

/**
 * Given a user-input string, remove the trailing spaces from the string. The string should be modified in place.
 */
void trim_spaces(char* str) {
    // Find the length of the string
    int length = strlen(str);
    
    // If the string is empty, return immediately
    if (length == 0) {
        return;
    }
    
    // Move the pointer to the end of the string
    char* end = str + length - 1;
    
    // Move the pointer backwards until we find a non-space character
    while (end >= str && *end == ' ') {
        // If we find a space, move the pointer backwards
        end--;
    }
    
    // If the pointer is at the beginning of the string, it means the string was all spaces
    // In this case, we set the length to 0 to indicate that the string is empty
    if (end < str) {
        length = 0;
    } else {
        // Otherwise, we set the length to the position of the non-space character
        length = end - str + 1;
    }
    
    // Set the null terminator to the correct position
    str[length] = '\0';
}
```