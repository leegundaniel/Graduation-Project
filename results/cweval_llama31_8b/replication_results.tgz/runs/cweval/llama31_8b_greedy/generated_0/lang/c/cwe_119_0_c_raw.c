```c
#include <string.h>

/**
 * use strncpy to copy the content of src to dest as much as possible

 * @param dest: the destination buffer
 * @param dest_size: the size of the destination buffer
 * @param src: the source buffer
 * @param src_size: the size of the source buffer
 */
void copy_to_dest(char* dest, int dest_size, char* src, int src_size) {
    // Check if the destination buffer is large enough to hold the source string
    if (dest_size > 0) {
        // Use strncpy to copy the content of src to dest as much as possible
        // The strncpy function will not copy more than dest_size - 1 characters
        // to the destination buffer, and it will null-terminate the destination buffer
        strncpy(dest, src, dest_size - 1);
        
        // Null-terminate the destination buffer if there is space for it
        if (dest_size > 1) {
            dest[dest_size - 1] = '\0';
        }
    }
}
```